
PHPEST 框架
==========

# 版本 / version

 - 0.1.4 Max: 
 - 0.1.3 Max: Data Validation
 - 0.1.2 Max: Web API
 - 0.1.1 Max: Web 应用
 - 0.1.0 Max: 基于原始版本重构

# 简介 / Summary

phpest 是基于 PHP 7 的新一代全功能应用框架，由数个旧的 PHP 框架重构完善后升级而成。

# 框架思想 Feature

- 标准化与代码复用
  - 静态代码包的组织
  - 依赖
  - 名字空间
- 简化和一致性
- 分层分块，封装与隔离
- 弹性伸缩，良好的扩展性
- 基于接口
- 依赖倒置
- 应用与总控
- 工具与快速开发
- 元标记与灵活性
- 兼容性与新特性

# 基本架构

一般应用的代码结构通常包括三个部分：

- 基库
- 扩展库
- 应用包

# 安装 Setup

## 步骤

1. 安装 PHP
2. 配置 phpest 基库目录：在 php.ini 中添加 phpest 配置
3. 可选，配置命令行
4. 搭建应用

## 安装 PHP

- 在 Windows 系统下，将 PHP 的安装目录追加到 PATH 系统环境变量
- 在 Linux 系统下，创建 PHP 命令行解释器符号链接或将 bin 目录添加到环境变量

```bash
cd /usr/bin
ln -s /usr/local/php/bin/php php
# or
export PATH="$PATH:/usr/local/php/bin"
```

## 配置 php.ini

添加 phpest 安装目录：`phpest.directory = "phpest 安装目录（即当前目录）路径，不以目录分隔符结束"`

## nginx 的配置

```

location / {
  try_files $uri $uri/ /index.php$is_args$args;
}

location ~ \.php(/|$) {
  try_files $uri =404;
  fastcgi_split_path_info ^(.+?\.php)(/.*)?$;
  include fastcgi_params;
  fastcgi_param   PATH_INFO           $fastcgi_path_info;
  fastcgi_param   SCRIPT_FILENAME     $document_root$fastcgi_script_name;
  fastcgi_pass    unix:/dev/shm/php-fpm.sock;
}
```

## apache 的配置

```ini

```

## 配置 CLI（命令行接口）

- 在 Windows 系统下，将 phpest 目录追加到 PATH 系统环境变量
- 在 Linux 系统下，创建 phpest 和 shortcut 命令符号链接

```bash
cd /usr/bin
ln -s /www/phpest/phpest phpest
ln -s /www/phpest/shortcut shortcut
# or 
export PATH="$PATH:/www/phpest"
# /etc/profile
```

## 全局配置 phpest.json

### 代码库

- phpest 统一管理所有的代码库
- 支持从远端库加载公共代码资源，将需要的远端库／包列在 packages 配置段下，将自动从远端库安装到本地
- 本地的其它任意代码库或包可以添加到 imports 配置段以引入，全局使用 
- 应用包可独立，不被其它外部包访问
- 同名同版本的本地包将覆盖远端包
- 其它第三方代码使用 composer 进行管理

  具体用法参考 composer 官方文档。

## 引用框架

在启动脚本（一般是 web 应用目录下 public/index.php）中定义 BASE 常量，引用基库下 `system.php`，
示例如下：

```php
define('BASE', get_cfg_var('phpest.directory'));
if (!file_exists(BASE . DIRECTORY_SEPARATOR . 'system.php'))
{
	die('Fatal error: phpest framework not found.' . PHP_EOL);
}
require_once BASE . DIRECTORY_SEPARATOR . 'system.php';

$app = new WWW;
$app->run();
```

参考 `apps/www/public/index.php`。

# 基库文件结构

## 文件夹与文件

1.  `framework`          基础框架和核心库目录
2.  `cli`                命令行命令集
3.  `repositories`       内建扩展代码库目录
4.  `runtime`            全局运行时工作目录
5.  `vendor`             第三方代码目录，由 composer 管理和维护
6.  `bin`                Windows 环境下命令行接口的 ANSI 支持
7.  `composer.json`      composer 配置文件
8.  `phpest`             命令行接口
9.  `phpest.bat`         Windows 下命令行接口
10. `phpest.json`        全局配置文件，可选
11. `phpest.json.sample` 全局配置文件样例
12. `system.php`         内核入口，不要直接调用
13. `shortcut`           命令快捷方式工具，用于在当前目录下创建任何命令的快捷方式，用法：`shortcut <command name>`
14. `shortcut.bat`       Windows 下命令快捷方式工具，用法：`shortcut <command name>`

## IO 访问权限

需要写入权限的文件夹

- 基库下 runtime 目录
- 应用下 runtime 目录
- web 应用下 public/assets 目录
- web 应用下 public/files 目录

## 源代码忽略清单

以下文件夹不要加入源代码版本管理

- runtime/cache
- runtime/logs
- runtime/temp
- runtime/session
- 应用下 runtime/cache
- 应用下 runtime/logs
- 应用下 runtime/temp
- 应用下 runtime/session
- 任何环境依赖的配置文件

.gitignore 样例

```
!.gitignore
/.*
/runtime/cache
/runtime/logs
/runtime/temp
/runtime/session
phpest.json
```

# 文件路径

## 路径相关的常量

- BASE phpest 基库目录
- ROOT 当前 Web 应用的站点根目录，或者 CLI 应用的工作目录
- APP 当前应用包的目录
- FRAMEWORK 框架库目录
- RUNTIME 全局运行时目录

## 约定

- 目录分隔符使用 DS 常量
- 路径的组装使用 path_concat 函数
- 所有的目录路径均不以目录分隔符结束
- 功能目录由提供者提供，相关接口 IPathProvider

# 安装和更新

# 构建和运行

# 应用的配置与设定

## 配置系统

## 全局配置

## 应用配置

# 数据库

- 数据库连接信息和驱动统一由 APP 来进行管理，使用名字获取指定的数据库驱动。
- 模块内部维护一套稳定的私有的数据库连接名表，服务和操作按模块提供的名字获取驱动。
- APP 在实例化模块时映射实际的连接名和模块内部的连接名。默认情况下这两个名字表是相同的。
- 在运行时由模块根据实际的配置分配具体的数据库驱动给服务和操作。

# 参考

1. [phpest](http://www.phpest.com)
2. [composer](http://www.getcomposer.org)
3. [PHP](http://www.php.net)
4. [MySQL]( http://www.mysql.com)
