<?php

/**
 * CLI Shell 字符串加色。主要用于 Linux 的 shell 环境。
 * Windows Shell 环境如果要使用必须确认支持 ANSI 转义码（例如 Windows Shell 下使用 ANSICON 实现）。
 * 颜色代码：'black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'。
 * 效果：light 增亮，underline 下划线，blink 闪烁，blank 消隐，invert 反转。
 * @since 0.1.0
 */
class ShellColor
{
	/**
	 * 前景文本效果：增亮。
	 * @var int
	 */
	const LIGHT = 1;
	/**
	 * 前景文本效果：下划线。
	 * @var int
	 */
	const UNDERLINE = 4;
	/**
	 * 前景文本效果：闪烁。
	 * @var int
	 */
	const BLINK = 5;
	/**
	 * 前景文本效果：消隐。
	 * @var int
	 */
	const BLANK = 8;
	/**
	 * 前景文本效果：颜色翻转，反向。
	 * @var int
	 */
	const INVERT =7;
	/**
	 * 前景文本效果：颜色翻转，反向。
	 * @var int
	 */
	const REVERSE = 7;
	
	/**
	 * 颜色：黑色。
	 * @var string
	 */
	const BLACK = 0;
	/**
	 * 颜色：红色。
	 * @var string
	 */
	const RED = 1;
	/**
	 * 颜色：绿色。
	 * @var string
	 */
	const GREEN = 2;
	/**
	 * 颜色：黄色。
	 * @var string
	 */
	const YELLOW = 3;
	/**
	 * 颜色：蓝色。
	 * @var string
	 */
	const BLUE = 4;
	/**
	 * 颜色：洋红。
	 * @var string
	 */
	const MAGENTA = 5;
	/**
	 * 颜色：蓝绿。
	 * @var string
	 */
	const CYAN = 6;
	/**
	 * 颜色：白色。
	 * @var string
	 */
	const WHITE = 7;
	
	/**
	 * 样式。
	 * @var array
	 */
	public static $styles = array('light' => 1, 'underline' => 4, 'blink' => 5, 'blank' => 8, 'invert' => 7, 'reverse' => 7);
	/**
	 * 颜色代码。
	 * @var array
	 */
	public static $colors = array('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white');
	/**
	 * 颜色和样式别名定义。
	 * @var array
	 */
	public static $aliases = array(
		'lightblack'      =>array('color'=>'black', 				'style'=>array('light')), 
		'lightred'	        =>array('color'=>'red', 				'style'=>array('light')), 
		'lightgreen'      =>array('color'=>'green', 			'style'=>array('light')), 
		'lightyellow'     =>array('color'=>'yellow', 			'style'=>array('light')), 
		'lightblue'       =>array('color'=>'blue', 				'style'=>array('light')), 
		'lightmagenta'    =>array('color'=>'magenta', 		'style'=>array('light')), 
		'lightcyan'       =>array('color'=>'cyan', 				'style'=>array('light')),
		
		'mark'            =>array('color'=>'white', 				'style'=>array('invert')),
		
		'blackmark'       =>array('color'=>'black', 				'style'=>array('invert')), 
		'redmark'         =>array('color'=>'red', 				'style'=>array('invert')), 
		'greenmark'       =>array('color'=>'green', 			'style'=>array('invert')), 
		'yellowmark'      =>array('color'=>'yellow', 			'style'=>array('invert')), 
		'bluemark'        =>array('color'=>'blue', 				'style'=>array('invert')), 
		'magentamark'     =>array('color'=>'magenta', 		'style'=>array('invert')), 
		'cyanmark'        =>array('color'=>'cyan', 				'style'=>array('invert')),
		
		'lightmark'       =>array('color'=>'white', 				'style'=>array('invert', 'light')),
		
		'lightblackmark'  =>array('color'=>'black', 				'style'=>array('invert', 'light')),
		'lightredmark'    =>array('color'=>'red', 				'style'=>array('invert', 'light')),
		'lightgreenmark'	  =>array('color'=>'green', 			'style'=>array('invert', 'light')),
		'lightyellowmark' =>array('color'=>'yellow', 			'style'=>array('invert', 'light')),
		'lightbluemark'   =>array('color'=>'blue', 				'style'=>array('invert', 'light')),
		'lightmagentamark'	=>array('color'=>'magenta', 		'style'=>array('invert', 'light')),
		'lightcyanmark'    =>array('color'=>'cyan', 				'style'=>array('invert', 'light')),
		
		'error'            =>array('color'=>'red', 				'style'=>array('light')),
		'link'             =>array('color'=>'blue', 				'style'=>array('light')),
		'warning'          =>array('color'=>'white', 				'background'=>'yellow', 			'style'=>array('light')),
		'failed'           =>array('color'=>'white', 				'background'=>'red', 				'style'=>array('light')),
	);
	
	/**
	 * 是否支持 ANSI 颜色代码。
	 * @return bool
	 */
	public static function ansi_enabled(){}
	
	/**
	 * 将字符串加颜色。
	 * @param string $string 字符串。
	 * @param int|string $color 颜色。
	 * @param int|string $background 背景色。
	 * @param int|string... $style 可变参数，样式或样式名。
	 * @return string
	 * @example format('string', self::RED, self::WHITE, self::UNDERLINE, self::LIGHT) // 白底红色加下划线增亮
	 */
	public static function format($string, $color=null, $background = null, ... $style){}
	
	/**
	 * 将字符串加颜色。
	 * @param string $string 字符串。
	 * @param array $style 样式，包含：<ol>
	 * <li>color: string|int 前景色。</li>
	 * <li>background: string|int 背景色。</li>
	 * <li>style: array|string|int 样式，包以是 blink, blank, invert, light, underline。</li>
	 * </ol>
	 * @return string
	 */
	public static function style($string, array $style = null){}
	
	/**
	 * CLI 下输出带颜色的文本到控制台。颜色使用宏标记标注，宏的模式分两种，如下：
	 * <ol>
	 * <li>宏模式一：{font:color,background,style1,style2,...}要加颜色或样式的文本{/font}。其中 color, background 以及 style 表示要使用的颜色，背景和样式。
	 * 如果 color 和 background 不指定但需要指定样式时位置须留空。</li>
	 * <li>宏模式二：{tag}要加颜色或样式的文本{/tag}， tag 可以是颜色名或样式名，也可以是别名。</li>
	 * </ol>
	 * 支持的颜色、样式和别名如下：
	 * <ol>
	 * <li>
	 * 支持的颜色（均为基本色，包括RGB ， CMYK以及白色）：black（黑）, red（红）, green（绿）, yellow（黄）, blue（蓝）, magenta（洋红）, cyan（蓝绿）, white（白）。
	 * </li>
	 * <li>
	 * 支持的样式：light（增亮）, underline（强调）, invert/reverse（反显）, blink（闪烁）, blank（消隐）
	 * </li>
	 * <li>
	 * 支持的样式别名（组合的快捷方式）：
	 * <ol type="A">
	 * <li>颜色加亮，在颜色名前加 light 即为加亮的颜色，比如 lightred 表示亮红（特别的：white 直接使用 light 表示亮白）。</li>
	 * <li>颜色标记，在颜色名后加 mark 即为标注的颜色，比如 redmark 表示红色标注（特别的：white 标注直接使用 mark 表示标注）。</li>
	 * <li>颜色加亮标记，在颜色名前加 light 后加 mark 即为加亮标注，比如 lightredmark 表示红色加亮标注（特别的：lightmark 表示白色加亮标注）。</li>
	 * <li>自定义的标记：增加样式定义到 ShellColor 的 静态公共属性 aliases 即可。
	 * 例：ShellColor::$aliases['my']=['color'='red', 'background'='white', 'style'=['light']]，即可使用 {my} 表示白底红字的加亮效果。</li>
	 * </ol>
	 * </li>
	 * <li>特别的，在使用反斜线有歧义的地方使用 {bs/} 或 {backslash/} 代替反斜线 \。</li>
	 * <li>特别的，{tab/} 代表制表符，{br/}代表换行（等价于 PHP_EOL）</li>
	 * </ol>
	 * @param string $args 可变参数，要输出的文本（使用颜色样式宏标记标记要加颜色的文本）。
	 * @example colorize('不加颜色的文本{font:red,yellow,underline,light}红色黄底的文本{/font}其它文本'); // 红色前景，黄色背景，强调，增亮
	 * @example colorize('{font:red,,light}文本{/font}{blank}看不见的文本{/blank}'); // 红色前景，不改变背景，增亮
	 * @example colorize('{font:,,light,underline}增强的文本{/font}'); // 增亮和强调效果
	 * @example colorize('{red}红色文本{/red}', '{lightred}亮红色文本{/lightred}'); // 红色和亮红色
	 * @example colorize('{light}亮白色文本{/light}', '{mark}亮白色标记文本，也就是反白{/mark}');
	 * @return void
	 */
	public static function colorize(... $args){}
	
	public static function __callstatic(string $name, array $args = null){}
}
