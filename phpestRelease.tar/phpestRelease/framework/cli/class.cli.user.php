<?php

namespace cli;

class user extends \UserBase
{
	public function guid(){}
	
	public function title(){}
	
	public function offsetExists($offset){}

	public function offsetGet($offset){}

	public function offsetSet($offset, $value){}

	public function offsetUnset($offset){}

	public function account(){}

}