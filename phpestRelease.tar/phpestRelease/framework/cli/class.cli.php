<?php

/**
 * 命令行接口。
 * @author Max
 */
abstract class cli extends app
{
	/**
	 * 交互方式时读取：一行，默认值。读入字符串，直到按下回车键。
	 * @var int
	 */
	const INTERACTIVE_READ_LINE = 0;
	/**
	 * 交互方式时读取：一个字符。读入一个字符，不需要等待回车键直接返回。
	 * @var int
	 */
	const INTERACTIVE_READ_CHAR = 1;
	/**
	 * 交互方式时读取：静默读取输入的字符，直到按下回车键，不回显键入的字符。
	 * @var int
	 */
	const INTERACTIVE_READ_SILENT = 2;
	
	/**
	 * windows 代码页和字符集转换。
	 * @var array
	 */
	protected $codepages = array(
		65001	=> 'utf-8',
		936		=> 'gbk',
		950		=> 'big5',
		437		=> 'ascii'
	);
	
	public function sapi($sapi) : bool{}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 执行指定的命令。
	 * @param string $cmd 命令。
	 * @param array $args 可选，命令参数。
	 */
	public function for(string $cmd, array $args = null){}
	
	public function run(){}
	
	/**
	 * 从控制台交互的读取指定的用户输入。
	 * @param string $fallback 备用值。
	 * @param int $mode 读取模式。包括：cli::INTERACTIVE_READ_LINE, cli:INTERATIVE_READ_CHAR, cli::INTERACTIVE_READ_SILENT，默认为 cli::INTERACTIVE_READ_LINE。
	 * @param string $prompt 可选，提示文本。
	 * @param int $timeout 可选，超时时间，默认为不指定，则始终不超时。
	 * @return string 返回读取到的字符串。
	 */
	public function read($fallback=null, $mode = self::INTERACTIVE_READ_LINE, $prompt = null, $timeout = 0){}
	
	/**
	 * 从控制台读取，仅支持 LINUX 系统。
	 * @param string $prompt 可选，提示文本。
	 * @param int $length 限定长度，输入指定的字符后自动提交，不用按 Enter 键。
	 * @param bool $silent 可选，是否隐藏键入的字符。
	 * @param int $timeout 可选，超时时间。
	 * @return string
	 */
	protected function console_read($prompt=null, $length = 0, $silent = false, $timeout = 0){}
	
	/**
	 * 获取当前的字符集。
	 * @return string
	 */
	public function charset(){}
	
	/**
	 * 输出当前应用的用法文档。
	 * @return void
	 */
	public function usage(array $args = null){}
	
	/**
	 * 获取所有命令。
	 * @return array 列出所有的命令和手册。
	 */
	public function all(){}
	
	protected function _list($dir, $prefix = null){}
	
	/**
	 * 获取 CLI 应用使用手册内容。
	 * @return array 包括：description, title, cmd, usage 等。
	 */
	protected abstract function manual();
	
	public function shutdown(){}
	
	/**
	 * 直接调用命令。
	 * @param string $cmd 命令。
	 * @param array $args 可选，命令参数。
	 * @return cli
	 */
	public static function invoke(string $cmd, array $args = null){}
}
