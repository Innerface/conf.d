<?php

/**
 * CLI 版权声明。
 * @var string
 */
define('COPYRIGHT_CLI', 'Copyright(c)' . date('Y') . ' phpest ' . FRAMEWORK_VERSION . '. All rights reserved.');

/**
 * CLI 下将字符串加颜色。
 * @param string $string 字符串。
 * @param array $style 样式，包含：<ol>
 * <li>color string 前景色。</li>
 * <li>background string 背景色。</li>
 * <li>其它元素识别为效果：blink, blank, invert, light, underline。</li>
 * </ol>
 * @return string
 */
function colorstring($string, array $style = null){}

/**
 * CLI 下输出带颜色的文本到控制台。颜色使用宏标记标注，宏的模式分两种，如下：
 * <ol>
 * <li>宏模式一：{font:color,background,style1,style2,...}要加颜色或样式的文本{/font}。其中 color, background 以及 style 表示要使用的颜色，背景和样式。
 * 如果 color 和 background 不指定但需要指定样式时位置须留空。</li>
 * <li>宏模式二：{tag}要加颜色或样式的文本{/tag}， tag 可以是颜色名或样式名，也可以是别名。</li>
 * </ol>
 * 支持的颜色、样式和别名如下：
 * <ol>
 * <li>
 * 支持的颜色（均为基本色，包括RGB ， CMYK以及白色）：black（黑）, red（红）, green（绿）, yellow（黄）, blue（蓝）, magenta（洋红）, cyan（蓝绿）, white（白）。
 * </li>
 * <li>
 * 支持的样式：light（增亮）, underline（强调）, invert/reverse（反显）, blink（闪烁）, blank（消隐）
 * </li>
 * <li>
 * 支持的样式别名（组合的快捷方式）：
 * <ol type="A">
 * <li>颜色加亮，在颜色名前加 light 即为加亮的颜色，比如 lightred 表示亮红（特别的：white 直接使用 light 表示亮白）。</li>
 * <li>颜色标记，在颜色名后加 mark 即为标注的颜色，比如 redmark 表示红色标注（特别的：white 标注直接使用 mark 表示标注）。</li>
 * <li>颜色加亮标记，在颜色名前加 light 后加 mark 即为加亮标注，比如 lightredmark 表示红色加亮标注（特别的：lightmark 表示白色加亮标注）。</li>
 * <li>自定义的标记：增加样式定义到 ShellColor 的 静态公共属性 aliases 即可。
 * 例：ShellColor::$aliases['my']=['color'='red', 'background'='white', 'style'=['light']]，即可使用 {my} 表示白底红字的加亮效果。</li>
 * </ol>
 * </li>
 * <li>特别的，在使用反斜线有歧义的地方使用 {bs/} 或 {backslash/} 代替反斜线 \。</li>
 * <li>特别的，{tab/} 代表制表符，{br/}代表换行（等价于 PHP_EOL）</li>
 * </ol>
 * @param string $_ 可变参数，要输出的文本（使用颜色样式宏标记标记要加颜色的文本）。
 * @example colorize('不加颜色的文本{font:red,yellow,underline,light}红色黄底的文本{/font}其它文本'); // 红色前景，黄色背景，强调，增亮
 * @example colorize('{font:red,,light}文本{/font}{blank}看不见的文本{/blank}'); // 红色前景，不改变背景，增亮
 * @example colorize('{font:,,light,underline}增强的文本{/font}'); // 增亮和强调效果
 * @example colorize('{red}红色文本{/red}', '{lightred}亮红色文本{/lightred}'); // 红色和亮红色
 * @example colorize('{light}亮白色文本{/light}', '{mark}亮白色标记文本，也就是反白{/mark}');
 * @return void
 */
function colorize(...$styles){}

/**
 * 当前的 CLI 应用。
 * @return cli
 */
function cli(){}

/**
 * 读取 PHP 脚本的文档注释：在 PHP 脚本首部关于脚本信息的注释内容，允许首行存在一个 #! 指令，注意：键名不区分大小写，统一转化为小写形式。
 * @param string $file 可选，PHP 文件。如果不提供文件路径，则自动使用调用此函数的代码所在的脚本文件。
 * @param bool|array $merged 可选，是否合并条目，默认时重名的条目将被覆盖，如果指定合并则将同名的条目合并为数组。
 * 也可以指定要合并的键名，则只有指定的键才合并，其它键覆盖。
 * @return array 返回文档注释内容，未合并的返回结果形式[['key', 'value'], ['key1', 'value1'], etc. ]，合并的返回形式 ['key'=>'value', 'key1'=>'value1', etc.]
 * 至少包含 description 元素，如果未找到有效注释则返回 null。
 */
function read_doc_comment(string $file=null, $merged = true){}

/**
 * 加载脚本。
 * @param string $file 脚本文件。
 * @param object $newthis 可选，所属的上下文对象。
 * @param array $vars 可选，置入到执行空间的变量表。
 * @param bool|int $error_reporting 可选，是否捕捉错误信息（默认为 false）并指定错误报告的级别（例如 E_ALL，参考 error_reporting 函数）。
 * <strong>注意：false 不捕捉错误，同时不会获取脚本的输出内容。</strong>
 * @param bool $once 可选，是否使用 require_once，默认为 true。
 * @return stdClass|Exception|array
 * <ol>
 * <li>文件不存在或没有读取权限返回 false</li>
 * <li>文件使用 quit 退出则返回 null</li>
 * <li>成功加载返回 stdClass 对象，包含属性
 * <ol type="A">
 * <li>return mixed 返回值，取决于脚本的返回值（特别的：1 视为 null）。</li>
 * <li>vars array 定义的变量表，包含置入的变量。</li>
 * <li>content string 输出的内容文本。</li>
 * </ol>
 * </li>
 * <li>发生异常如果 $error_reporting 参数不为 false 返回 Exception 对象。</li>
 * <li>发生错误如果 $error_reporting 参数不为 false 返回 array，依次是 error, message, file, line, context 元素。</li>
 * </ol>
 * @throws Exception 如果未捕捉错误则可能由加载的脚本引发任意异常。
 */
function load($file, $newthis = null, array $vars = null, $error_reporting = false, $once = true){}

/**
 * 格式化错误信息。
 * @param array $error 标准的 PHP 错误信息。支持使用 $error['trace'] 记录回溯信息。
 * @return string
 */
function format_error_message(array $error = null){}

/**
 * 格式化回溯跟踪信息。
 * @param array $backtrace 回溯数据。
 * @param array $options 可选，选项。可用的选项如下：
 * <ol>
 * <li>args  参数模式：=false 关闭，="summary"  简单摘要信息，="details" 输出参数。</li>
 * <li>sort 排序方式：call_stack（调用顺序）或 back_trace_stack（回溯顺序），默认按回溯顺序。</li>
 * </ol>
 * @param array $style 可选，样式（样式由一对开始和结束标签组成，键名为要格式化的部分的名称，值为开始和结束标签对）。可添加样式的项目为：
 * <ol>
 * <li>默认时 CLI 环境自动添加颜色，Web 环境不加颜色，如下：</li>
 * <li>class 执行操作的对象类名，默认为亮绿。</li>
 * <li>function 调用的指令，即执行的方法、函数或闭包。默认为亮绿。</li>
 * <li>type 调用类型：静态调用为 ::，实例调用为 ->，普通函数为空。默认为亮蓝。</li>
 * <li>ref 参数引用号。默认为红底标记。</li>
 * <li>file 文件名。默认为加亮标记。</li>
 * <li>line 行号。默认为浅黄。</li>
 * <li>string 字符串。默认为强调或下划线。</li>
 * <li>ellipsis 字符串超长被裁掉时的省略号。默认为红色标记。</li>
 * <li>举例：['call'=>['{light}', '{/light}']]，添加 ANSI 加亮颜色效果。</li>
 * </ol>
 * @return string
 */
function format_debug_backtrace(array $backtrace = null,  array $options = null, array $style = [
	'class'=>['{light}', '{/light}'],
	'type'=>['{light}', '{/light}'],
	'function'=>['{lightgreen}', '{/lightgreen}'],
		'line'=>['{light}', '{/light}'],
	'ref'=>['{redmark}', '{/redmark}'],
		'ellipsis'=>['{redmark}', '{/redmark}'],
]){}

/**
 * 获取指定数组元素或对象属性的值。如果是实现了 ArrayAccess 接口的对象，会尝试使用数组形式访问（优先访问属性）。
 * @param array|object $data 引用，源数组或对象。
 * @param string|array $key 键名，支持多个键，则依次测试。
 * @param mixed $fallback 可选，备用值，指定键不存在时返回。
 * @return mixed
 * @example iif($_POST, ['id', 'name', 'key', 'guid'], 0);
 * @example iif($_POST, 'name', '');
 */
function iif(&$data, $key, $fallback = null){}
