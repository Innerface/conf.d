<?php

/**
 * 命令行命令。
 * <ol>
 * <li>默认情况下执行时使用命令的名字进行调用。</li>
 * <li>名字：名字主体是命令文件相对于 cmd 目录的文件路径（不含 php 扩展名），但文件名字符仅限于 0~9, a-z，点(.)，
 * 下划线(_)和连字符(-)，以字母或数字开始或结尾，调用时区分大小写，路径分隔符固定使用 “/”。</li>
 * <li>cmd 文件：定义在当前应用下的 cmd 文件夹或 BASE 下的 cmd 文件夹，使用小写。</li>
 * <li>默认情况下，命令名到名字空间的映射：路径分隔符，点(.) 以及连字符(-) 被转换为名字空间分隔符，形成命令的名字空间。</li>
 * <li>默认的全局命令名字空间前缀为 \cli\cmd，当前应用的命令以应用的完全类名为名字空间前缀。</li>
 * <li>特别的，调用时在命令名前加前缀 ~ 指示全局命令。</li>
 * <li>特别的，可以在 cmd 类文件中返回（return）所使用的（含全部名字空间的）类全名。</li>
 * </ol>
 * @example phpest ~namespace/cmd 调用全局命令：namespace/cmd，其文件定义在：BASE/cmd/namespace/cmd.php，其名字空间为 \cli\cmd\namespace\cmd
 * @example phpest name-space/cmd 调用命令：name-space/cmd，首先查找是否为当前应用下命令，其文件定义可能在 APP/cmd/name-space/cmd.php，其名字空间为 \APP\name\space\cmd。
 * 如果在当前应用下找不到，则尝试在全局命令空间查找：文件定义在 BASE/cmd/name-space/cmd.php，名字空间为 \cli\cmd\name\space\cmd。
 * @author Max
 */
abstract class cmd
{
	/**
	 * 参数表。
	 * @var array
	 */
	const ARGs = null;
	
	/**
	 * 参数表。
	 * @var array
	 */
	protected $args;
	
	public function __construct(){}
	
	/**
	 * 初始化。
	 */
	protected function init(){}
	
	protected function exists($flag){}
	
	/**
	 * 运行命令。
	 * @param array $args 命令行参数，此命令有效的全部参数，不含命令名和入口脚本名。完整参数访问全局变量 $argv。
	 * @return int 返回 0 ~ 254 之间的数值表示执行结果状态。
	 */
	public function run(array $args = null){}
	
	/**
	 * 输出命令的用法。
	 * @param array $args 当前的命令行参数。
	 * @return void
	 */
	public function usage(array $args = null){}
}