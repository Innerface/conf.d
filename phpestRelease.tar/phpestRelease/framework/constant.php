<?php


if (defined('DS'))
{
	return;
}

/**
 * 目录分隔符 DIRECTORY_SEPARATOR 的别名。
 * @var string
 */
define('DS', DIRECTORY_SEPARATOR);
/**
 * 路径分隔符 PATH_SEPARATOR 的别名。
 * @var string
 */
define('PS', PATH_SEPARATOR);

/**
 * 要校正的目录分隔符。
 * @var string
 */
define('DIRECTORY_SEPARATOR_CORRECTION', DIRECTORY_SEPARATOR === '/' ? '\\' : '/');
/**
 * 要校正的目录分隔符，DIRECTORY_SEPARATOR_CORRECTION 别名。
 * @var string
 */
define('DSC', DIRECTORY_SEPARATOR_CORRECTION);
/**
 * 正则表达式模式，用来检测字符串是否是一个有效的正则表达式。
 * @var string
 */
define('PREG_PATTERN', '{^(?:([^\s\w\\\\[:cntrl:]]).*\1|\{.*\})[imsxuADSUXJ]*$}');
/**
 * 是否运行在 CLI 环境。
 * @var boolean
 */
define('IS_CLI', substr(PHP_SAPI, 0, 3)=='cli' && stripos(PHP_SAPI, 'server') === false, true);
/**
 * 是否运行在 windows 环境。
 * @var boolean
*/
define('IS_WIN', strstr(PHP_OS, 'WIN') ? true : false, true);
/**
 * 是否运行在 PHP-fpm 模式。
 * @var boolean
*/
define('IS_FPM', substr_compare(PHP_SAPI, 'fpm', 0, 3, true)===0, true);
/**
 * 是否运行在 CGI 模式。
 * @var boolean
*/
define('IS_CGI', substr(PHP_SAPI, 0, 3)=='cgi', true);
/**
 * 是否运行在 Fast CGI 模式。
 * @var boolean
*/
define('IS_FAST_CGI', stripos(PHP_SAPI, 'fcgi') !== false, true);
/**
 * 是否运行在 CLI Server 模式下。
 * @var boolean
*/
define('IS_CLI_SERVER', strcasecmp(PHP_SAPI, 'cli-server') === 0);

/**
 * JSON 友好格式。
 * @var int
 */
define('JSON_PRETTY_FORMAT', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

/**
 * (BOM: Byte Order Mark) 字符串：由 ASCII 码为 239，187 和 191 的三个字节构成。
 * @var string
 */
define('BOM', "\xEF\xBB\xBF");


/**
 * 应用程序接口类型：不限制。
 * @var int
*/
define('SAPI_ANY', 0);
/**
 * 应用程序接口类型：CLI 命令行，外壳交互环境或其它非 WEB 环境。
 * @var int
*/
define('SAPI_CLI', 1);
/**
 * 应用程序接口类型：Web 服务。
 * @var int
*/
define('SAPI_WEB', 2);

/**
 * 当前的 SAPI 环境：CLI 或 WEB。
 * @var int
*/
define('SAPI',  IS_CLI ? SAPI_CLI : SAPI_WEB, true);


/**
 * 1 秒的微秒数。即 1 秒 = ? 微秒数。
 * @var int
*/
define('SECOND', 1000000, true);

/**
 * 1 分钟的秒数：60 秒。
 * @var int
*/
define('MINUTE', 60, true);

/**
 * 1 小时的秒数：3600 秒。
 * @var int
*/
define('HOUR', 3600, true);
/**
 * 1 天的秒数：86400 秒。
 * @var int
*/
define('DAY', 86400, true);
/**
 * 1 周的秒数：604800 秒。
 * @var int
*/
define('WEEK', 604800, true);

/**
 * 容量单位：1 KB 的字节数。
 * @var int
*/
define('KB', 1024, true);

/**
 * 容量单位：1 MB 的字节数。
 * @var int
*/
define('MB', 1048576, true);

/**
 * 容量单位：1 GB 的字节数。
 * @var int
*/
define('GB', 1073741824, true);

/**
 * 容量单位：1 TB 的字节数。
 * @var int
*/
define('TB', 1099511627776, true);



/**
 * 容量单位：1 KiB 的字节数。
 * @var int
*/
define('KiB', 1000, true);

/**
 * 容量单位：1 MiB 的字节数。
 * @var int
*/
define('MiB', 1000000, true);

/**
 * 容量单位：1 GiB 的字节数。
 * @var int
*/
define('GiB', 1000000000, true);

/**
 * 容量单位：1 TiB 的字节数。
 * @var int
*/
define('TiB', 1000000000000, true);



/**
 * PHP_EOL 别名，行结束符，依赖于平台的不同自动切换合适的行结束符。
 * @var string
*/
define('EOL', PHP_EOL, true);

/**
 * Windows 平台换行符：\r\n。
 * @var string
*/
define('EOL_WIN', "\r\n", true);
/**
 * 类 UNIX 平台换行符：\n。
 * @var string
*/
define('EOL_UNIX', "\n", true);
/**
 * Mac 平台换行符：\r。
 * @var string
*/
define('EOL_MAC', "\r", true);
/**
 * 自动根据平台选择换行符：\r\n。
 * @var string
*/
define('EOL_AUTO', PHP_EOL, true);
/**
 * TAB 符。
 * @var string
*/
define('TAB', "\t", true);




/**
 * 用途或版本：正式发行状态。
 * @var int
 */
const RELEASE = 0;
/**
 * 用途或版本：正式发行状态，RELEASE 别名。
 * @var int
 */
const PRODUCTION = 0;
/**
 * 用途或版本：开发中。
 * @var int
 */
const DEVELOPMENT = 1;
/**
 * 用途或版本：开发中。
 * @var int
 */
const DEV = 1;
/**
 * 用途或版本：测试。
 * @var int
 */
const TEST = 2;
/**
 * 用途或版本：演示。
 * @var int
 */
const DEMO = 4;
/**
 * 用途或版本：设计时。
 * @var int
 */
const DESIGN = 8;
/**
 * 用途或版本：备用。
 * @var int
 */
const STANDBY = 0x10;
/**
 * 用途或版本：备份。
 * @var int
 */
const BACKUP = 0x20;
/**
 * 用途或版本：临时。
 * @var int
 */
const TEMP = 0x40;



/**
 * 选项，忽略空值：未设置或 null。
 * @var int
*/
define('ASSIGN_IGNORE_NULL', 1);
/**
 * 选项，忽略空值：空字符串。
 * @var int
*/
define('ASSIGN_IGNORE_EMPTY_STRING', 2);
/**
 * 选项，忽略空值：0, "0", 0.0, '0.0'。
 * @var int
*/
define('ASSIGN_IGNORE_ZERO', 4);
/**
 * 选项，忽略空值：布尔值 false。
 * @var int
*/
define('ASSIGN_IGNORE_FALSE', 8);
/**
 * 选项，忽略空值：空数组。
 * @var int
*/
define('ASSIGN_IGNORE_EMPTY_ARRAY', 0x10);
/**
 * 选项，忽略空值：空对象。
 * @var int
*/
define('ASSIGN_IGNORE_EMPTY_OBJECT', 0x20);
/**
 * 选项集，忽略任何空值。
 * @var int
*/
define('ASSIGN_IGNORE_EMPTY', 0x3F);

/**
 * 选项：忽略数组。
 * @var int
*/
define('ASSIGN_IGNORE_ARRAY', 0x100);
/**
 * 选项：忽略对象。
 * @var int
*/
define('ASSIGN_IGNORE_OBJECT', 0x200);
/**
 * 选项：忽略资源。
 * @var int
*/
define('ASSIGN_IGNORE_RESOURCE', 0x400);
/**
 * 选项：忽略回调。
 * @var int
*/
define('ASSIGN_IGNORE_CALLABLE', 0x800);

/**
 * 选项：限定为标量类型，忽略非标量类型（字符串视为标量）。
 * @var int
*/
define('ASSIGN_SCALAR', 0xF00);



/**
 * 选项：忽略大小写。
 * @var int
*/
define('ASSIGN_IGNORE_CASE', 0x1000);
/**
 * 选项：只为存在的元素赋值。
 * @var int
*/
define('ASSIGN_EXISTS', 0x2000);
/**
 * 选项：只为公共声明的 public 属性或目标数组中已存在的键赋值，不额外增加新的项目。此标志设置则忽略 ASSIGN_EXISTS 标志。
 * @var int
*/
define('ASSIGN_DECLARED', 0x4000);


/**
 * 选项：检查原值，如果未设置则赋值，否则忽略。
 * @var int
*/
define('ASSIGN_IS_UNSET', 0x8000);

/**
 * 常用选项：忽略任何空值，忽略大小写，仅限标量，仅为存在的属性或键赋值。
 * @var int
*/
define('ASSIGN_NORMAL', 0xFFFF);

/**
 * 全部选项。
 * @var int
*/
define('ASSIGN_ALL', 0x7FFFFFFF);

/**
 * 数组组合标记：追加，将不存在的元素添加到目标数组。
 * @var int
 */
define('MERGE_APPEND', 1);
/**
 * 数组组合标记：覆盖，只修改存在定义的元素。
 * @var int
 */
define('MERGE_OVERRIDE', 2);
/**
 * 数组组合标记：递归，在所有维度上操作，默认为第一维。
 * @var int
 */
define('MERGE_RECURSIVE', 4);
/**
 * 数组组合标记：命名的元素，也即字符串索引的元素才被采用。
 * @var int
 */
define('MERGE_NAMED', 8);
/**
 * 数组组合标记：null 值视为有效值。
 * @var int
 */
define('MERGE_NULL', 0x10);

/**
 * 文件系统类型：目录。
 * @var int
 */
define('FS_DIRECTORY', 1);
/**
 * 文件系统类型：目录， FS_DIRECTORY 别名。
 * @var int
*/
define('FS_DIR', 1);
/**
 * 文件系统类型：文件。
 * @var int
*/
define('FS_FILE', 2);
/**
 * 文件系统类型：符号链接/快捷方式。
 * @var int
*/
define('FS_LINK', 4);

/**
 * WEB 应用公共入口根目录或 CLI 应用工作目录。注意：不以目录分隔符结束。
 * @var string
 */
defined('ROOT') or define('ROOT', IS_CLI ? getcwd() : dirname($_SERVER['SCRIPT_FILENAME']));
/**
 * 当前应用程序目录。注意：不以目录分隔符结束。
 * @var string
 */
defined('APP') or define('APP', dirname(dirname($_SERVER['SCRIPT_FILENAME'])));
/**
 * 启动程序名，当前应用名。
 * @return string
 */
defined('BOOTSTRAP') or define('BOOTSTRAP', basename(APP));
