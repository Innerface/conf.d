<?php


/**
 * 标志位设置测试。
 * @param int $flags 标志集。 
 * @param int $flag 某一个或几个标志位。
 * @return boolean 已设置返回 true，否则为 false。
 */
function flag(int $flags, int $flag) : bool{}

/**
 * 标志位设置测试。
 * @param int $bits 标志位值。 
 * @param int $index 标志位索引：0~63（32位系统为 0~31），从右至左。
 * @param boolean $set 可选，要设置的值，不提供则仅获取当前的值。
 * @return boolean|integer 已设置返回 true，否则为 false。如果 $set 提供，则返回设置后的标志位值。
 */
function bit(int $bits, int $index, bool $set = null){}

/**
 * 把参数当作一个延迟获取值的引用表达式（回调或数组表示的引用），并尝试计算其值（穷尽各种可能）。
 * @param mixed $ref 引用表达式。注意：如果是数组形式的回调，则优先尝试获取属性，再尝试调用方法。
 * @return mixed
 * @example get(function(){...}); // 执行回调并返回值
 * @example get(1); // 标量和资源直接返回
 * @example get([$obj, 'name']) // $obj 是对象，则尝试获取其名为 name 的属性或调用其名为 name 的方法，如果 $obj 实现了 ArrayAccess，还将尝试获取数组值。
 * @example get([$array, 'index', 'sub-index']); // 尝试获取数组的元素，多个索引表示逐层获取。
 */
function get($ref){}

/**
 * 计算机容量单位的可读表示。
 * @param int $size IO 尺寸。
 * @param string $unit 可选，单位，支持（二进制：TB, GB, MB, KB，或十进制：TiB, GiB, MiB, KiB， 注意：区分大小写）。
 * 不指定返回多个单位的表示。如果指定了单位，自动识别十进制与二进制。
 * 特别的，使用 decimal 表示采用十进制单位，binary 表示采用二进制单位。默认为二进制。
 * @param int $precision 可选，精度，单个单位时小数的精度。默认为 2。组合单位时此参数被忽略。
 * @return string 返回字符串表示，类似于 100MB 20KB。如果指定了单位则返回类似于 1.8MB，仅有一个单位。
 * @example echo byte(1024); // output: 1KB
 * @example echo byte(1048); // output: 1KB 24 Byte(s)
 * @example echo byte(1000, 'KiB'); // output: 1KiB
 */
function byte(int $size, $unit=null, int $precision = 2) : string{}

/**
 * 交换变量。
 * @param mixed $v1  引用，第一个变量。
 * @param mixed $v2 引用，第二个变量。
 * @return void
 */
function swap(&$v1, &$v2){}

/**
 * 组装路径。整理路径包括：
 * <ol>
 * <li>整理目录分隔符为标准形式。</li>
 * <li>连接多段路径，清理多余的目录分隔符。</li>
 * <li>空的或无效的路径段将被忽略。</li>
 * <li>路径段前缀或后缀的斜杠或反斜杠将会被清理掉。</li>
 * <li>安全检查，忽略无效或不安全的路径段。</li>
 * </ol>
 * @param string... $args 可变参数，要组装的路径段。
 * @return string 返回组装后的路径，空路径返回 null。
 * @example path_concat('/www', 'sites', 'www.example.com', 'index.php'); // 结果：/www/sites/www.example.com/index.php
 */
function path_concat(... $args){}

/**
 * 使用正则表达式提取子字符串。
 * @param string $pattern 正则表达式。
 * @param string|integer|array $group 正则表达式模式组：组的序号或名字。如果是数组，则返回指定的模式组的捕获结果。
 * @param string $subject 源字符串。
 * @param int $flags 可选，正则选项。
 * @param int $offset 可选，开始的偏移位置。
 * @return string|array 如果使用数组指定组号或组名，则返回所有匹配的内容。
 * @example preg_fetch('/\w+=(\w+)/', 1, 'name=value'); // 返回 'value' 
 * @example preg_fetch('/(\w+)=(\w+)/', array(2, 1), 'name=value'); // 返回 array(2=>'value', 1=>'name') 
 */
function preg_fetch(string $pattern, $group, string $subject, int $flags = 0, int $offset = 0){}

/**
 * 获取对象在继承链上的所有类名（适用于 stdClass 类），包括当前对象或类。
 * @param string|object $obj 对象或类名。
 * @param bool $autoload 可选，是否自动加载。默认为 true。
 * @return array 按继承关系倒序（先子类，后父类）排列，非对象或类返回 null。
 */
function classes($obj, $autoload = true){}

/**
 * 遍历继承链上的所有祖宗类（适用于 stdClass）。
 * @param string|object $obj 对象或类名。如果是类名则会尝试自动加载。
 * @return Generator
 */
function family($obj){}

/**
 * 获取第一个符合回调的数据。
 * @param callable $callback 回调，签名为 bool function (mixed $var) 测试 $var返回  true 或 false。
 * @param mixed $_ 可变参数，数据表。
 * @return mixed 回调错误或未找到任何数据返回 null。
 */
function fit($callback, $_ = null){}

/**
 * 是否为绝对路径。
 * @param string $path 路径。
 * @return bool
 */
function is_absolute_path(string $path){}

/**
 * 转换为一维数据。
 * @param mixed $_ 可变参数，要转换的数据。采用深度优先算法，保持键名有效，重复的键将被覆盖。
 * @return array
 */
function d1(... $_){}

/**
 * 分隔符分隔的字符串转换为数组。
 * @param string $list 分隔符分隔的字符串。
 * @param string $delimiter 可选，分隔符。默认为逗号，分隔符前后的空白将被清理掉。
 * @param boolean $uniqued 可选，是否保持元素去掉重复的值。默认为 true。
 * @param boolean $ignore_empty 可选，是否忽略空元素（长度为0）。默认为 true。
 * @return array
 */
function stringlist($list, string $delimiter = null, $uniqued = true, $ignore_empty = true){}

/**
 * 随机字符串。
 * @param int $length 字符串长度。
 * @param string $chars 可选，字符表，默认为 a-zA-Z0-9 区分大小写的集合。
 * @return string
 */
function randstr($length=16, $chars = 'stOcdWpuFUVw9Eb4eYfgSZ0ykln3jTGa2xKB5zqrPTv7NDXCoMLRh8HIJiQA1m6'){}

/**
 * 层层获取指定数组元素或对象属性的值。如果是实现了 ArrayAccess 接口的对象，会尝试使用数组形式访问（优先访问属性）。
 * @param array|object $data 引用，源数组或对象。
 * @param int|string|array $key 可变参数，后代子孙元素键名，数组指示测试多个键，则依次测试，返回找到的首个。
 * @return mixed 返回引用，任何一层元素不存在或键无效则返回 null。
 * @example peel($_POST, 'parent_id', ['id', 'name', 'key', 'guid']); // 在 $_POST['parent_id'] 下依次测试是否存在 id, name, key, guid 中的任意一个。
 * @example peel($_POST, 'parent_id', 'child_id'); // $_POST['parent_id']['child_id']
 */
function & peel(&$data, ... $keys){}

/**
 * 层层获取指定数组元素或对象属性的值。如果是实现了 ArrayAccess 接口的对象，会尝试使用数组形式访问（优先访问属性）。
 * @param array|object $data 引用，源数组或对象。
 * @param array $keys 后代子孙元素键名，数组指示测试多个键，则依次测试，返回找到的首个。
 * @param mixed $fallback 可选，备用值，指定键不存在时返回。
 * @return mixed 返回引用，任何一层元素不存在或键无效则返回 null。
 * @example peel_off($_POST, ['parent_id', ['id', 'name', 'key', 'guid']]); // 在 $_POST['parent_id'] 下依次测试是否存在 id, name, key, guid 中的任意一个。
 * @example peel_off($_POST, ['parent_id', 'child_id']); // $_POST['parent_id']['child_id']
 */
function & peel_off(&$data, array $keys, $fallback = null){}

/**
 * 宏替换。
 * @param string $string 源字符串。
 * @param array $vars 宏变量表。
 * @param array $args 可变参数，其它更优先的变量表。最后列出的最优先。
 * @return string
 */
function macro($string, array $vars, array ... $args){}

/**
 * 简单输出变量原始值（HTML 格式），便于调试，输出后中断流程。
 * @param mixed $_ 可变参数，要输出的变量。
 * @return void
 */
function print_var(... $_){}

/**
 * 调试用途：获取并输出当前的位置。
 * @param mixed ...$messages 可变参数，要输出的信息，转为字符串。
 * @return array 返回调用位置的文件和行号。
 */
function here(... $messages){}

/**
 * 简洁风格导出变量。将变量输出为 PHP 代码格式。
 * @param mixed $var 变量。注意：递归、循环引用、不可序列化的对象和资源类型被转为 null。
 * @param int $indent 可选，缩进级别。
 * @param string $indention 可选，缩进字符，默认为 \t，即制表符。
 * @param string $newline 可选，新行换行符，默认为 UNIX 风格，即 \n。
 * @return string
 */
function var_export_ex($var, $indent = 0, $indention = "\t", $newline = "\n"){}

/**
 * 影子数组测试，即测试数组是否为相同的引用。
 * @param array $a 引用，数组一。
 * @param array $b 引用，数组二。
 * @return bool
 */
function is_array_shadow(array & $a, array & $b){}

/**
 * 获取某个对象的全部公共数据（以 public 定义的字段，不含静态属性和临时数据项）和实例值。注意：不同于 get_object_vars 函数。
 * @param object $obj 对象。
 * @return array 如果是对象，则返回其公共属性表（包括实例值），否则返回 null。
 */
function vars($obj){}

/**
 * 获取某个对象的全部公共属性（以 public 定义的字段，不含静态属性和临时数据项）表。
 * @param object $obj 对象。
 * @return array 如果是对象且定义了可公共访问的属性，则返回其公共属性表（仅属性名），否则返回 null。
 */
function properties($obj){}

/**
 * 检测指定对象是否具有指定的公共属性。与 has 不同的是仅检查显式 publicn 定义的属性。
 * @param object $obj 要测试的对象。
 * @param string $property 属性名。
 * @return bool 如果对象存在指定的公共且非静态的属性则返回 true，否则（$obj不是对象，或者不具有这样的属性）返回 false。
 */
function exists($obj, $property){}

/**
 * 检测指定对象是否具有指定的公共属性。与 exists 不同的检查包括临时数据项（未显式定义）在内的全部 public 属性。
 * @param object $obj 要测试的对象。
 * @param string $property 属性名。
 * @return bool 如果对象存在指定的公共且非静态的属性则返回 true，否则（$obj不是对象，或者不具有这样的属性）返回 false。
 */
function has($obj, $property){}

/**
 * 为对象的公共属性或数组的元素进行批量赋值。
 * @param array|object $obj 引用，对象或数组，此函数将直接修改此参数变量。
 * @param array|object $data 源数据，使用此参数提供的数据为目标变量赋值。
 * @param int $options 可选，赋值的选项，参考 ASSIGN_ 系列常量定义。
 * @param array $keys 可选，键表，只为指定的元素赋值。
 * @return mixed 返回 $obj 的引用，不需要的时候，可以不必接受返回值，仅为了链式/连锁式调用的方便才返回该对象。
 */
function &assign(&$obj, $data = null, $options = 0, array $keys = null){}

/**
 * 字符串转换为数值。自动识别十进制（包括千分位分隔符），八进制（0为前缀）和十六进制（0x前缀）以及浮点数，包括科学记数法。
 * @param string $str 源字符串，空值视为 0。
 * @param int $fallback 可选，备选值。默认为 0。
 * @return int|float 返回解析值，如果格式不正确则返回 $fallback。
 */
function str2num($str, $fallback = 0){}

/**
 * 获取运行时间，单位：秒。
 * @param string $id 可选，标识。不使用参数获取自执行启动到现在的时间。
 * @return float 返回秒数。
 */
function uptime(string $id=null){}

/**
 * 获取运行耗费的时间，单位：秒。
 * @param string $id 可选，标识。不使用参数获取自执行启动到现在的时间。
 * @return int 秒。
 */
function elapsed(string $id=null){}

/**
 * 确保为整数（bool 值中 false 转换为 0，true 转换为 1，数值字符串转换为整数，浮点数转换为整数，其它值采用备用值），如果数值不在范围内，也返回备用值。
 * @param mixed $value 待确认和转换的值。
 * @param int $fallback 可选，备选值，默认为 0。
 * @param int $min 可选，最小值，指定范围。默认不使用。
 * @param int $max 可选，最大值，指定范围。默认不使用。
 * @return int
 */
function int($value, $fallback=0, $min = null, $max = null){}

/**
 * 确保为无符号整数。
 * @param mixed $value 值。
 * @param int $fallback 备用值。
 * @return int
 */
function unsign($value, $fallback = 0){}

/**
 * 确保为无符号整数。
 * @param mixed $value 值。
 * @param int $fallback 备用值。
 * @return int
 */
function unsigned($value, $fallback = 0){}

/**
 * 确保为浮点数。
 * @param mixed $value 值。
 * @param float $fallback 可选，备用值，默认为 0。
 * @param float $min 可选，最小值，默认不使用。
 * @param float $max 可选，最大值，默认不使用。
 * @return float
 */
function float($value, $fallback = 0, $min = null, $max = null){}

/**
 * 移除字符串中的控制字符。
 * @param string $str 源字符串。
 * @return string
 */
function strip_control_chars($str){}

/**
 * 测试文件是否为当前用户（php 运行时）可以访问的文件。
 * @param string $file 文件名。
 * @return bool
 */
function is_my_file($file){}

/**
 * 扫描目录下的文件或子目录列表。
 * @param callable $call 回调，对找到的每个文件或目录调用一次，签名为：function (DirectoryIterator $di)。
 * @param string $path 目录路径。
 * @param int $type 可选，类型：可以组合 FS_ 系列常量以支持多个类型，也可以使用字符串：* 或 a/all/any表示所有的，
 * d/dir/directory 目录，f/file 文件，l/link 链接。默认为所有，字符串表示多个类型以 ASCII 逗号分隔。
 * @param string $pattern 可选，名字的正则表达式模式。
 * @param string $excluded 可选，要排除的文件项名字模式。如果 $pattern 和 $excluded 均指定则同时测试。
 * @param bool $recursive 可选，是否递归扫描子目录。默认为 false。
 * @return array 返回找到的文件或目录，键为相对路径（以名字空间为前缀，/ 为分隔符，前后无分隔符），值为绝对路径（分隔符为系统分隔符，物理路径）。
 */
function files_callback(callable $call, $path, $type='*', $pattern = null, $excluded = null, $recursive = false){}

/**
 * 实时随机唯一标识符。
 * @param int $lenght 可选，长度，大于 0，默认为 13。
 * @throws LogicException 长度太短。
 * @throws Exception 默认使用 random_bytes 或 openssl_random_pseudo_bytes 生成随机数，如果这两个函数不存在时引发此异常。
 * @return string
 */
function uniqid_real(int $lenght = 13){}

/**
 * 随机唯一标识符(字符表：[0-9a-zA-Z])，勿用于安全用途。
 * @param int $lenght 可选，长度，大于 0 小于等于 60，默认为 13。
 * @return string
 */
function random_string(int $lenght = 13){}

/**
 * web get.
 * @param string $url 基链接。
 * @param string|array $params 可选，POST 数据表，表示使用 POST 提交。
 * 上传文件则在文件名前加 @ 前缀。示例 array('file'=>'@/path/')。也可以使用 CURLFile 实例指定上传文件项。
 * @param array $settings 可选，设置项，包括：
 * <ol>
 * <li>headers array 请求头。示例：array('User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/45.0', 'Accept-Encoding: gzip, deflate')</li>
 * <li>timeout int 超时时间，单位：秒。默认不超时。</li>
 * <li>nobody bool 不包含正文，仅返回响应头信息。默认为 false。</li>
 * <li>onlybody bool 仅返回正文，不包含头和状态信息。默认为 true。如果此选项设置，则 nobody 将被忽略。</li>
 * <li>charset string 字符集，如果返回数据指定的字符集与此处的不兼容则自动转换，默认为 utf-8。如果响应流未指定字符集或非文本则忽略。</li>
 * <li>cookie string，设定HTTP请求中"Cookie: "部分的内容。多个cookie用分号分隔，分号后带一个空格(例如， "fruit=apple; colour=red")。 </li>
 * </ol>
 * @return string|array 返回数组包括：status HTTP 状态，info 请求信息，headers 响应头信息，content 正文流数据，
 * error array 错误信息（如果有错误则包含 code 和 message）。如果指定 onlybody 选项为 true 则直接返回正文流。当超时或出错时返回 false。
 */
function wget($url, $params = null, array $settings = null){}