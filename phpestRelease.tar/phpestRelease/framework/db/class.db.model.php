<?php

namespace DB;

/**
 * 适用于数据库操作的模型。
 * @author Max Wang
 * 
 */
class Model extends \Model
{
	
}