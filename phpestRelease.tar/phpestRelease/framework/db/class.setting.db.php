<?php


namespace Setting;

/**
 * 连接设置。转换为字符串时返回 DSN。
 * @author Max
 * 
 */
class DB extends \Setting
{
	/**
	 * 数据库服务器的版本。
	 * @var string
	 */
	public $version;
	/**
	 * 引擎类型。
	 * @var string
	 * @see \DB::MySQL
	 * @see \DB::PostgreSQL
	 * @see \DB::Orcale
	 */
	public $engine = 'mysql';
	
	/**
	 * 驱动类型名。
	 * @var string
	 */
	public $type;
	/**
	 * 主机（IP，域名或主机名）。
	 * @var string
	 */
	public $host;
	/**
	 * 端口。
	 * @var int
	 */
	public $port;
	/**
	 * 连接的物理架构名（数据库名）。
	 * @var string
	 */
	public $schema;
	/**
	 * 账号。
	 * @var string
	 */
	public $account;
	/**
	 * 访问口令。
	 * @var string
	 */
	public $password;
	/**
	 * 使用 unix socket。
	 * @var string
	 */
	public $socket;
	/**
	 * 客户端使用的字符集。
	 * @var string
	 */
	public $charset = 'utf-8';
	
	/**
	 * 是否使用持久连接。
	 * @var bool
	 */
	public $persistent = false;
	/**
	 * 连接的超时时间设置，单位：秒。
	 * @var int
	 */
	public $timeout;
	
	/**
	 * 初始化 SQL 语句。设置字符集的 SQL 语句不需要添加到此处，设置 $this->charset 属性即可。注意：SQL 不会被映射处理，请使用物理表名。
	 * @var string|array
	 */
	public $sqls;
	
	/**
	 * 选项。
	 * @var array
	 */
	public $options;
	
	/**
	 * 映射定义。
	 * @var array 包括 schemes 架构映射，tables 表映射，prefix 表前缀定义。
	 */
	public $mappings;
	
	/**
	 * 物理表名的前缀。
	 * @var string
	 */
	public $prefix;
	
	/**
	 * 连接信息的来源配置文件，用于出错时定位。
	 * @var string
	 */
	public $file;
	
	/**
	 * 连接信息所在的行，用于出错时定位。
	 * @var int
	 */
	public $line;
	
	/**
	 * 构造数据库驱动的连接信息。
	 * @param string $type 可选，驱动的类名。
	 * @param string $host 可选，主机名。
	 * @param int $port 可选，端口。
	 * @param string $schema 可选，架构或库名。
	 * @param string $account 可选，账号。
	 * @param string $password 可选，口令。
	 * @param array $mappings 可选，名字映射，键为逻辑名，值为物理名。
	 * @param string $prefix 可选，名字前缀。
	 */
	public function __construct(string $type = null, string $host = null, int $port = null, string $schema = null, string $account = null, string $password = null, array $mappings = null, string $prefix = null){}
	
	/**
	 * 设置驱动类型。
	 * @param string $type 驱动类名，可以是任何实现了 \IDBDriver 接口的类。
	 * @return self
	 */
	public function type(string $type){}
	
	/**
	 * 设置驱动主机。
	 * @param string $host 主机名。
	 * @param int $port 可选，端口。
	 * @return self
	 */
	public function host(string $host, int $port = null){}
	/**
	 * 设置 UNIX SOCKET。
	 * @param string $socket UNIX Socket。
	 * @return self
	 */
	public function socket(string $socket){}
	
	/**
	 * 设置驱动端口。
	 * @param string $port 端口。
	 * @return self
	 */
	public function port(int $port){}
	
	/**
	 * 设置数据库架构或库名。
	 * @param string $schema 架构或库名。
	 * @return self
	 */
	public function schema(string $schema){}
	
	/**
	 * 设置登录账号。
	 * @param string $account 账号。
	 * @param string $password 可选，口令。
	 * @return self
	 */
	public function account(string $account, string $password = null){}
	
	/**
	 * 设置名字前缀。
	 * @param string|callable $prefix 前缀。
	 * @return self
	 */
	public function prefix($prefix){}
	
	/**
	 * 设置字符集。
	 * @param string $charset 使用的字符集。
	 * @return self
	 */
	public function charset(string $charset){}
	
	/**
	 * 设置名字映射。
	 * @param array|callable $mappings 映射表或映射方法。键名为逻辑名字，值为物理名字。
	 * 可以使用回调映射所有的名字，签名为：string function (string $name, array $context = null) {} 
	 * 也可以使用回调映射指定的名字，签名为：string function (array $context = null) {}
	 * 注意：两种回调返回的物理名字都不要包含前缀。
	 * @return self
	 * @example mappings(function (string $name, array $context = null){ })
	 * @example mappings(['user'=>function (array $context = null){}])
	 */
	public function mappings($mappings){}
	
	/**
	 * 初始化 SQL 语句。
	 * @param string... $sql 可变参数，初始化时要执行的 SQL 语句组。
	 * @return self
	 */
	public function sqls(string ...$sql){}
	
	/**
	 * 设置选项。
	 * @param int|array $options 选项。
	 * @return self
	 */
	public function options($options){}
	
	/**
	 * 设置查询超时。
	 * @param int $timeout 超时时长，单位：秒。
	 * @return self
	 */
	public function timeout(int $timeout){}
	
	/**
	 * 设置为持久连接。
	 * @return self
	 */
	public function persistent(){}
	
	/**
	 * 设置服务器的类型和版本。
	 * @param string $engine 数据库服务器的类型。参考 DB 类的引擎常量。
	 * @param string $version 数据库服务器的版本。
	 * @return self
	 * @see \DB::MySQL
	 * @see \DB::PostgreSQL
	 * @see \DB::Oracle
	 */
	public function engine(string $engine, string $version = null){}
	
	/**
	 * 设置配置文件和行。
	 * @param string $file 配置文件名。
	 * @param int $line 可选，配置文件行。
	 * @return self
	 */
	public function file(string $file, int $line = 0){}
	
	public function __toString(){}
}