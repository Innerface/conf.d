<?php

namespace
{
	return [
		'use' => ['system.data'],
	];
	
	/**
	 * 获取数据库驱动。要获取数据库管理器，请使用 app()->db();
	 * @param string $name 可选，连接的名字或别名。空表示默认驱动。
	 * @return IDBDriver
	 * @example db(); // 默认驱动
	 * @example db('name');
	 */
	function db(string $name = null, string $app = null){}
	
	/**
	 * 构造 SQL 表达式。
	 * @param string $expression SQL 语句或表达式，参考 format 方法。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * 基于参数位置引用，模式“[?index|modifers]”，注意：序号从 1 开始，不存在的参数默认为 NULL 值。引用位置跟参数位置相同可以省略序号。
	 * 宏的用法参考 format 方法，区别仅在于 format 方法传入数组参数，此处的构造器传入可变参数。
	 * @param mixed $args 可变参数，将被代入 SQL 语句中。使用 pack 方法包装。
	 * @return SQL
	 * @see MySQL::format
	 * @example MySQL('SELECT * FROM `[table]` WHERE `id`=[?] AND `code`=[?]', 1, 'string');
	 * @example MySQL('SELECT * FROM `[table]` WHERE `code`=[?2] AND `id`=[?1]', 1, 'string');
	 * @example MySQL('NOW()');
	 */
	function MySQL(string $expression = null, ... $args){}
}

namespace SQL
{
	const FRAGMENTS = 0;
	const SELECT = 1;
	const INSERT = 2;
	const UPDATE = 3;
	const DELETE = 4;
	const REPLACE = 5;
	const ALTER = 10;
	const DROP = 11;
	const CHANGE = 12;
	
	const FIELD = 0;
	const TABLE = 1;
	const SCHEMA = 2;
	const CATALOG = 3;
	
	const PACK_JSON = 1;
	const PACK_COMPACT = 2;
	
	/**
	 * 数据包装类型：键值对，例如 `k1`=0, `k2`=NULL, `k3`='string'。
	 * @var integer
	 */
	const PAIRS = 0;
	/**
	 * 数据包装类型：值表，例如 0, NULL, 'string'。
	 * @var integer
	 */
	const VALUES = 1;
	/**
	 * 数据包装类型：映射表，例如 (`k1`, `k2`, `k3`) VALUES (0, NULL, 'string')。
	 * @var integer
	 */
	const MAP = 2;
	/**
	 * 数据包装类型：键表，例如 `k1`, `k2`, `k3`。
	 * @var integer
	 */
	const FIELDS = 3;
	
	/**
	 * 日期时间类型：时间戳（UTC）。
	 * @var integer
	 */
	const TIMESTAMP = 0;
	/**
	 * 日期时间类型：日期时间。
	 * @var integer
	 */
	const DATETIME = 1;
	/**
	 * 日期时间类型：时间。
	 * @var integer
	 */
	const TIME = 2;
	/**
	 * 日期时间类型：日期。
	 * @var integer
	 */
	const DATE = 3;
	/**
	 * 日期时间类型：UNIX 时间戳，单位：秒，从 1970-1-1 00:00:00 开始到指定时间的秒数。
	 * @var integer
	 */
	const UNIXTIME = 4;
}