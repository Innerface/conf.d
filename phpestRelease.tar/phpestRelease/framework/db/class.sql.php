<?php

/**
 * SQL 表达式或语句。
 * <ol>
 * <li>名字为小写的方法均为工具方法，返回字符串。</li>
 * <li>名字为大写的方法均为组件方法，将参数结果组装进编写器缓存，返回编写器，实现链式调用。</li>
 * <li>未实现的魔术方法：方法名作为语句连接词，参数作为语句体，语句体长度大于 0 时将语句一起写入编写器缓存，返回编写器，实现链式调用。</li>
 * </ol>
 * @author Max
 * 
 */
abstract class SQL
{
	/**
	 * SQL 片段定义。规则如下：
	 * <ol>
	 * <li>
	 * 如果为 null 则不支持片段，组装 SQL 时简单连接（以空格为分隔符）。
	 * </li>
	 * <li>
	 * 使用键值对定义片段，键为片段名，值为片段特性。可用的片段特性包括：
	 * <ul>
	 * <li>true 表示必要片段，如果未提供则引发异常。</li>
	 * <li>string 表示不存在时使用此定义作为默认内容。</li>
	 * <li>null/false 可忽略。</li>
	 * </ul>
	 * </li>
	 * </ol>
	 * @var array 
	 * @example ['SELECT'=>'*', 'FROM' => '`[table]`', 'WHERE' => null]
	 */
	const SYNTAX = null;
	
	/**
	 * SQL 片段。结构：
	 * <ol>
	 * <li>未定义 SQL 片段时，此数据被视作普通字符串直接连接。</li>
	 * <li>已定义 SQL 片段时根据定义组装。</li>
	 * </ol>
	 * @var array
	 */
	protected $_sql;
	
	/**
	 * 语句锚。
	 * @var string|int|self
	 */
	protected $_anchor;
	
	/**
	 * SQL 编写器。
	 * @var \SQL\Writer
	 */
	protected $_writer;
	
	/**
	 * 构造 SQL 表达式。
	 * @param string $expression SQL 语句或表达式，参考 format 方法。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * 基于参数位置引用，模式“[?index|modifers]”，注意：序号从 1 开始，不存在的参数默认为 NULL 值。引用位置跟参数位置相同可以省略序号。
	 * 宏的用法参考 format 方法，区别仅在于 format 方法传入数组参数，此处的构造器传入可变参数。
	 * @param mixed $args 可变参数，将被代入 SQL 语句中。使用 pack 方法包装。
	 * @see \SQL\Writer::format
	 * @example new MySQL('SELECT * FROM `[table]` WHERE `id`=[?] AND `code`=[?]', 1, 'string'); 
	 * @example new MySQL('SELECT * FROM `[table]` WHERE `code`=[?2] AND `id`=[?1]', 1, 'string'); 
	 * @example new MySQL('NOW()');
	 */
	public function __construct(string $expression = null, ... $args){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 添加一段语句，用括号引用。
	 * @param mixed... $args 可变参数。
	 * @return self
	 */
	public function __invoke(...$args) : self{}
	
	public function __toString(){}
	
	/**
	 * 使用的 SQL 编写器。
	 * @return \SQL\Writer
	 */
	abstract protected function _writer() : \SQL\Writer;
}