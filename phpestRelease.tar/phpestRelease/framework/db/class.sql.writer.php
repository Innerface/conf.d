<?php

namespace SQL;

use SQL\Modifier;

/**
 * SQL 编写器。
 * @author Max
 * 
 */
abstract class Writer
{
	/**
	 * 标识符引号字符。
	 * @var string
	 */
	const ID_QUOTE_CHAR = '`';
	
	/**
	 * SQL 修改器。
	 * @var \SQL\Modifiers
	 */
	protected $modifier;
	
	/**
	 * 构造 SQL 编写器。
	 */
	public function __construct(){}
	
	/**
	 * SQL 构建器。
	 * @param string ... $sql 可变参数，SQL 语句。
	 * @return \SQL\Builder
	 */
	abstract public function builder(... $sql) : \SQL\Builder;
	public function __invoke(...$sql) : \SQL\Builder{}
	
	/**
	 * 获取 SQL 编写器的修改器。
	 * @return \SQL\Modifier
	 */
	public function modifier(){}
	
	/**
	 * 转换为内部使用的标准日期时间格式。
	 * 注意：框架内部始终使用标准化的日期时间格式（Y-m-d H:i:s）。
	 * @param int|string|array $var 日期时间值，支持：int 整形值表示的时间戳，string 文本表示的日期时间（使用strtotime转换，所以支持各种有效的日期时间字符串），
	 * 也可以使用数组定义日期时间，有两种形式（任选一种）：
	 * <ol>
	 * <li>array 使用键定义，可用的键包括 year, month, day, hour, minute, second, microsecond，例如：array('year'=>2015, 'month'=>12, 'day'=>21, 'hour'=>12, 'minute'=>0, 'second'=>0) 表示 2015年12月21日 12:00:00</li>
	 * <li>array 顺序定义，例如：array(2015, 12, 21, 12, 0, 0) 表示 2015年12月21日 12:00:00</li>
	 * <li>注意，除了 microsecond 可以省略，指定类型的各个日期时间部分必须完整，否则视为无效日期时间值。</li>
	 * </ol>
	 * @param int $type 可选，要转换到的日期时间类型（目标格式）。默认为 \SQL::DATETIME。
	 * @return SQL
	 * @example datetime(145802698); // unix 时间戳转换为日期时间
	 * @example datetime('-1 week'); // 上周的今天
	 */
	abstract public function datetime($var, $type = \SQL::DATETIME);
	
	/**
	 * 转换内部使用的标准日期格式。
	 * 注意：框架内部始终使用标准化的日期时间格式（Y-m-d H:i:s）。
	 * @param int|string|array $var 日期时间值，支持：int 整形值表示的时间戳，string 文本表示的日期时间（使用strtotime转换，所以支持各种有效的日期时间字符串），
	 * 也可以使用数组定义日期时间，有两种形式（任选一种）：
	 * <ol>
	 * <li>array 使用键定义，可用的键包括 year, month, day, hour, minute, second, microsecond，例如：array('year'=>2015, 'month'=>12, 'day'=>21, 'hour'=>12, 'minute'=>0, 'second'=>0) 表示 2015年12月21日 12:00:00</li>
	 * <li>array 顺序定义，例如：array(2015, 12, 21, 12, 0, 0) 表示 2015年12月21日 12:00:00</li>
	 * <li>注意，除了 microsecond 可以省略，指定类型的各个日期时间部分必须完整，否则视为无效日期时间值。</li>
	 * </ol>
	 * @return SQL
	 * @example date(145802698); // unix 时间戳转换为日期
	 * @example date('-1 week'); // 上周的今天
	 */
	public function date($var){}
	
	/**
	 * 转换为内部使用的标准时间格式。
	 * 注意：框架内部始终使用标准化的日期时间格式（Y-m-d H:i:s）。
	 * @param int|string|array $var 日期时间值，支持：int 整形值表示的时间戳，string 文本表示的日期时间（使用strtotime转换，所以支持各种有效的日期时间字符串），
	 * 也可以使用数组定义日期时间，有两种形式（任选一种）：
	 * <ol>
	 * <li>array 使用键定义，可用的键包括 year, month, day, hour, minute, second, microsecond，例如：array('year'=>2015, 'month'=>12, 'day'=>21, 'hour'=>12, 'minute'=>0, 'second'=>0) 表示 2015年12月21日 12:00:00</li>
	 * <li>array 顺序定义，例如：array(2015, 12, 21, 12, 0, 0) 表示 2015年12月21日 12:00:00</li>
	 * <li>注意，除了 microsecond 可以省略，指定类型的各个日期时间部分必须完整，否则视为无效日期时间值。</li>
	 * </ol>
	 * @return SQL
	 * @example time(145802698); // unix 时间戳转换为时间
	 * @example time('-1 week'); // 上周的今天
	 */
	public function time($var){}
	
	/**
	 * 转换为内部使用的标准时间格式。
	 * 注意：框架内部始终使用标准化的日期时间格式（Y-m-d H:i:s）。
	 * @param int|string|array $var 日期时间值，支持：int 整形值表示的时间戳，string 文本表示的日期时间（使用strtotime转换，所以支持各种有效的日期时间字符串），
	 * 也可以使用数组定义日期时间，有两种形式（任选一种）：
	 * <ol>
	 * <li>array 使用键定义，可用的键包括 year, month, day, hour, minute, second, microsecond，例如：array('year'=>2015, 'month'=>12, 'day'=>21, 'hour'=>12, 'minute'=>0, 'second'=>0) 表示 2015年12月21日 12:00:00</li>
	 * <li>array 顺序定义，例如：array(2015, 12, 21, 12, 0, 0) 表示 2015年12月21日 12:00:00</li>
	 * <li>注意，除了 microsecond 可以省略，指定类型的各个日期时间部分必须完整，否则视为无效日期时间值。</li>
	 * </ol>
	 * @return SQL
	 * @example timestamp('-1 week'); // 上周的同一个周日的时间戳
	 */
	public function timestamp($var){}
	
	/**
	 * 原生的字符串转义。
	 * @param string $var 源字串。
	 * @return string
	 */
	abstract public function escape($var);
	
	/**
	 * 引用逻辑名。如果已添加则忽略。
	 * @param string|array $id 逻辑名标识符。
	 * @param int $type 可选，逻辑名类型。某些驱动使用有多种名字类型。
	 * @return string 错误返回 null。
	 * @example name(['table.f1', 'table.f2']); => `[table.f1]`, `[table.f2]`
	 * @example name(['table.f1', 'table.f2'=>'alias']); => `[table.f1]`, `[table.f2]` AS `alias` // 使用别名
	 * @example name('table.field'); => `[table.field]`
	 * @example name('`table.field`'); => `[table.field]`
	 * @example name('`[table.field]`'); => `[table.field]`	// 忽略已引用的
	 */
	abstract public function name($id, int $type = 0);
	/**
	 * 引用标识符。如果已添加引号则忽略。
	 * @param string|array $id 标识符。
	 * @return string 错误返回 null。
	 * @example id(['table.f1', 'table.f2']); => `table`.`f1`, `table`.`f2`
	 * @example id(['table.f1', 'table.f2'=>'alias']); => `table`.`f1`, `table`.`f2` AS `alias` // 使用别名
	 * @example id('table.field'); => `table`.`field`
	 * @example id('`table.field`'); => `table.field`	// 忽略已引用的
	 */
	abstract public function id($id);
	/**
	 * 原生的标识符引用和转义方法。
	 * @param string $id 标识符。
	 * @return string 错误返回 null。
	 * @example quote(['table.f1', 'table.f2']); => `table`.`f1`, `table`.`f2`
	 * @example quote(['table.f1', 'table.f2'=>'alias']); => `table`.`f1`, `table`.`f2` AS `alias` // 使用别名
	 * @example quote('table.field'); => `table`.`field`
	 * @example quote('`table.field`'); => `table.field`	// 忽略已引用的
	 */
	abstract public function quote(string $id);
	
	/**
	 * 包装数据，使其可以直接连接进 SQL 语句。
	 * @param mixed $var 数据。
	 * @param string $key 可选，键名。
	 * @param int $options 可选，选项。
	 * @return string
	 * @example pack(0, 'key')	=> `key`=0
	 * @example pack('string', 'key')	=> `key`='string'
	 * @example pack(null)	=> NULL
	 * @example pack(99, 'key')	=> `key`=99
	 * @example pack("I'm max")	=> 'I\'m max'
	 */
	abstract public function pack($var, string $key = null, int $options = 0);
	/**
	 * 包装数据为键值对，例如：`k1`=0, `k2`=NULL, `k3`='string'。
	 * @param array $var 字段表。
	 * @return string
	 */
	abstract public function pairs(array $var);
	/**
	 * 包装数据为键值列表，例如：(`k1`, `k2`, `k3`) VALUES (0, NULL, 'string')。
	 * @param array $var 字段表。
	 * @return string
	 */
	abstract public function map(array $var);
	/**
	 * 包装数据的键表，支持别名。例如：`k1` AS A, `k2`, `k3`。注意：
	 * <ol>
	 * <li>如果使用别名，则字段表数组的值被视为别名，如果不是有效的字符串中则引发异常。</li>
	 * <li>此方法与 id 方法不同：id 方法是将字段表的值视为标识符，此方法始终使用数据的键。</li>
	 * </ol>
	 * @param array $var 字段表。
	 * @param bool $alias 可选，是否使用别名，默认不使用。
	 * @see \SQL\Writer::id()
	 * @return string
	 */
	abstract public function fields(array $var, bool $alias = false);
	/**
	 * 包装数据的值表，例如：0, NULL, 'string'。
	 * @param array $var 字段表。
	 * @return string
	 */
	abstract public function values(array $var);
	
	/**
	 * 将参数带入并自动格式化 SQL 语句。
	 * @param string $sql SQL 语句。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * <ol>
	 * <li>基于参数位置引用，模式“[?序号|modifiers]”，注意：序号从 1 开始，负数表示逆序（从尾部往前），不存在的参数默认为 NULL 值。
	 * 0 表示跟参数位置一致，引用位置跟参数位置一致可以省略序号。</li>
	 * <li>基于参数名称引用，模式“[?键名|modifiers]”，键名中不得包含 ] 括号，竖线和控制字符，不存在的参数默认为 NULL 值。</li>
	 * <li>支持使用修改器 (modifier) 对数据进行处理，包括类型转换和格式化处理，以竖线引入，多个修改器以逗号分隔，按顺序执行。</li>
	 * <li>
	 * 自动识别数据类型，也可以使用 type 强制类型转换，可用的 type （不区分大上写）如下：
	 * <ol type="A">
	 * <li>_, sql									SQL 表达式，原文，不作转换。<strong>注意：慎用，要做好 SQL 注入检查</strong>，对应的参数必须能转换为字符串，无效时转换为 NULL。预置，不可覆盖或重定义。 </li>
	 * <li>注意：sql 包装器之后的修改器将被忽略。</li>
	 * <li>i, int, integer					整数。</li>
	 * <li>u, unsign, unsigned			正整数。</li>
	 * <li>c, f, r, real, float, double, currency, decimal 浮点数/货币。</li>
	 * <li>d, date									日期。</li>
	 * <li>t, time									时间。</li>
	 * <li>dt, datetime						日期时间。</li>
	 * <li>ts, timestamp						时间戳，正整数表示的时间值。</li>
	 * <li>j, json									JSON 编码。</li>
	 * <li>s, string								字符串。</li>
	 * <li>b, bool, boolean				布尔值。</li>
	 * <li>n, null, nil, none			空值，强制为 null 值。</li>
	 * </ol>
	 * 除类型转换外可用的其它修改器：
	 * <ol type="A">
	 * <li>任何整数						用来限定字符串的长度，超长将被截短，任何 html 标记将被移除。这是预置的格式化器 (cut），格式化器: string cut(string $var, int $length)。</li>
	 * <li>任何可用的系统或自定义函数名，签名为 mixed function(mixed $var)，例如：trim, strtolower, md5, serialize, base64_encode, strip_tags, etc.</li>
	 * <li>自定义修改器，注册到 $this->modifiers，例如：$this->modifiers->my=function($var){return do($var);}</li>
	 * <li>定义修改器别名或快捷方式，例如：$this->modifiers->x = 'serialize'; 则可以使用 x 来对数据序列化。</li>
	 * <li>支持多个格式化处理器，以逗号分隔，依序调用。</li>
	 * <li>未定义的格式化器会引发 \SQL\ModifierException 异常。</li>
	 * </ol>
	 * </li>
	 * </ol>
	 * @param array $args 可选，参数表，子元素将被代入 SQL 语句中。子元素：A. 是 SQL 表达式，直接代入，等同于 sql 标志。B. 是对象将尝试转换为字符串，不能转换时作为 NULL 使用。C. 使用 pack 方法包装。
	 * @return string
	 * @example format('SELECT * FROM `[user]` WHERE `id`=[?] AND `code`=[?] AND `password`=[?|20,md5]', [1, 'string', '********']); // password 最长 20 个，使用 md5 作散列处理 
	 * @example format('SELECT * FROM `[sample]` WHERE `code`=[?2] AND `id`=[?1]', [1, 'string']); 
	 * @example format('SELECT * FROM `[table]` WHERE `code`=[?code] AND `id`=[?id]', ['id'=>1, 'code'=>'string']); 
	 * @example format('UPDATE `[table]` SET `data`=[?|json] WHERE `code`=[?code|32] AND `id`=[?id|unsigned]', [array('demo'=>true), 'id'=>1, 'code'=>'string']); 
	 * @example format('UPDATE `[table]` SET `data`=[?|json], `date`=[?|strtoupper,sql,md5] WHERE `code`=[?code|32] AND `id`=[?id|unsigned]', [array('demo'=>true), 'NOW()', 'id'=>1, 'code'=>'string']); 
	 * // 第二个参数的 md5 修改器被忽略，但 strtoupper 修改器有效。
	 * @throws \SQL\ModifierException 未定义的格式化器引发此异常。
	 */
	public function format($sql, array $args = null){}
	
	/**
	 * 圆括号引用的子句。
	 * @param mixed $statements 可变参数，括号内的语句串。
	 * @return string 语句串长度大于0时返回前后带圆括号的语句，否则返回 null。
	 */
	public function sub(... $statements){}
	
	/**
	 * 包裹语句，用前缀和后缀将语句包裹，如果语句为有效的字符串，则连上前缀和后缀一起返回，否则返回 NULL。
	 * @param string $prefix 前缀。
	 * @param string|array $statement 主语句。去掉头尾的空白后长度大于 0 有效，否则返加空。
	 * @param string $suffix 可选，后缀。
	 * @return string $statement 去掉头尾的空白后长度大于 0 返回组合后的字符串，否则返回 null。
	 */
	public function with($prefix, $statement = null, $suffix = null){}
	
	/**
	 * 连接 SQL 语句。
	 * @param mixed... $sql 可变参数，任何数据，将被转换为字符串连接在一起，
	 * 数组将忽略键，其它任何不能转换为字符串的数据视为空，对象的处理：<ol>
	 * <li>如果实现了 __toString 方法则直接字符串化。</li>
	 * <li>如果实现了 Serializable 接口则序列化。</li>
	 * <li>如果实现了 JsonSerializable 接口则 JSON 序列化。</li>
	 * <li>如果实现了 Traversable 接口则遍历数据连接。</li>
	 * <li>其它情况使用 get_object_vars 获取属性数组连接。</li>
	 * </ol>
	 * @return string
	 */
	public function concat(...$sql){}

}
