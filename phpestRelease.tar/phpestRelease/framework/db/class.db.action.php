<?php

namespace DB;

/**
 * 数据库操作基类。
 * @author Max Wang
 * 
 */
abstract class Action
{
	const SCHEMA = null;
	
	/**
	 * 关联的逻辑表。
	 * @var string
	 */
	protected $_schema;
	
	/**
	 * SQL 语句。
	 * @var string|\SQL
	 */
	protected $_sql;
	
	/**
	 * 服务加载器。
	 * @var \Service\Loader
	 */
	protected $_loader;
	/**
	 * 数据库驱动。
	 * @var \IDBDriver
	 */
	protected $_driver;
	/**
	 * 服务。
	 * @var \IService
	 */
	protected $_service;
	/**
	 * 当前的模块。
	 * @var \Module
	 */
	protected $_module;
	/**
	 * 调用的参数表。
	 * @var array
	 */
	protected $_args;
	
	/**
	 * 构造 SQL 操作。
	 * @param Service\Loader|\IService|\IDBDriver $loader 加载器。
	 * @param string $sql 可选， SQL 语句。
	 */
	public function __construct($loader, $sql = null){}
	
	public function __get(string $name){}
	
	public function __invoke(){}
	
	public function __toString(){}
	
	/**
	 * 初始化。
	 * @return void
	 */
	protected function init(){}
	
	/**
	 * 准备。
	 * @return bool
	 */
	protected function ready(){}
	
	/**
	 * 获取 SQL 语句。
	 * @return \SQL|string|array
	 * @see \DB
	 * @see \DB::MySQL
	 * @see \DB::PostgreSQL
	 * @see \DB::Orcale
	 * @see \DB::SQLServer
	 */
	protected function sql(){}
}
