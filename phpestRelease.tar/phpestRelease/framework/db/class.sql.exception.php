<?php

namespace SQL;

/**
 * SQL 异常基类。
 * @author Max Wang
 * 
 */
class Exception extends \Exception
{
	
}