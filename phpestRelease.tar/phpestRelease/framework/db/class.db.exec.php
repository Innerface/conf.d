<?php

namespace DB;

/**
 * 数据库维护（ UPDATE 或 DELETE ）操作。
 * @author Max Wang
 */
abstract class Exec extends \DB\Action
{
	public function __invoke(){}
}