<?php

namespace DB;

/**
 * 数据库异常。
 * @author Max Wang
 * 
 */
class Exception extends \Exception
{
	/**
	 * 操作异常。
	 * @var integer
	 */
	const EXEC = 0;
	/**
	 * 连接异常。
	 * @var integer
	 */
	const CONNECT = 1;
	
	/**
	 * 类型。
	 * @var int
	 */
	public $type;
	/**
	 * SQL 语句。
	 * @var string
	 */
	public $sql;
	
	public function __construct(string $sql = null, int $type = 0, $message = null, $code = 0, $previous = null){}
}