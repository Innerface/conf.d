<?php

namespace DB;

/**
 * 数据库查询支持。
 * @author Max Wang
 */
class Query extends Action
{
	public function __invoke(){}
	
	/**
	 * 转换结果数据。
	 * @param array $data 引用，查询结果数据。
	 * @return self
	 */
	protected function cast(&$data){}
}
