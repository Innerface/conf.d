<?php

namespace DB;

/**
 * 支持数据库迁移／自适应的操作，仅服务自动加载的操作才适用此 TRAIT。
 * 此特性尝试在定义文件同目录下查找以驱动类型命名的文件夹，在文件夹中查找与当前操作同名的 .php 文件
 * 作为操作的 sql 方法的代替，文件的上下文环境为当前操作对象。
 * @author Max Wang
 * @example 将尝试为 ./demo.php 的 mysql 驱动查找 ./mysql/demo.php
 */
trait Migratable
{
	/**
	 * 实现了支持数据库迁移和自适应的 SQL 语句。
	 * @throws \RuntimeException
	 * @return string|\SQL
	 */
	protected function sql(){}
}