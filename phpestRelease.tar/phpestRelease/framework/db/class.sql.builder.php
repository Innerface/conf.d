<?php

namespace SQL;

use SQL\Writer;

/**
 * SQL 语句构造器。构造器特性：<ol>
 * <li>构造器的所有方法都可以链式调用，返回构造器本身。</li>
 * <li>不为空的方法结果追加到 SQL 语句，返回构造器，可以继续链式调用。</li>
 * <li>不存在的其它任何方法调用则作为以方法名(可以为特殊字符或 PHP 保留字)
 * 为前缀(自动前置空格)的 SQL 语句追加，如果参数为空则忽略。</li>
 * <li>如果方法名为单双引号或反勾号则将以这些符号作为引号引用参数构成的字符串，如果参数为空，则引号也忽略。</li>
 * </ol>
 * @author Max Wang
 * @example <pre>
 * $AND='AND';
 * $OR='OR';
 * echo (new SQL\Builder)->WHERE('`id`>0')->$AND('`id`<100')->$OR(''); 
 * // 输出 WHERE `id`>0 AND `id`<100
 * echo (new SQL\Builder)->WHERE('`id`>0')->$AND('`id`<100')->$OR('`id`=-1'); 
 * // 输出 WHERE `id`>0 AND `id`<100 OR `id`=-1
 * </pre>
 */
class Builder implements \JsonSerializable
{
	/**
	 * SQL 缩写器。
	 * @var \SQL\Writer
	 */
	protected $writer;
	/**
	 * SQL 语句段。
	 * @var array
	 */
	protected $sql = [];
	
	/**
	 * 构造 SQL 语句构造器。
	 * @param \SQL\Writer $writer SQL 编写器。
	 * @param string ... $sql SQL 语句段，任何能转换为字符串的数据。
	 */
	public function __construct(Writer $writer, ... $sql){}
	
	public function __toString(){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 追加 SQL 语句。
	 * @param mixed ... $sql 可变参数，任何可以转换为字符中的数据。
	 * @return self
	 */
	public function add(...$sql){}
	
	/**
	 * 追加 SQL 语句。
	 * @param mixed ... $sql 可变参数，任何可以转换为字符中的数据。
	 * @return self
	 */
	public function append(...$sql){}
	
	/**
	 * 如果参数连接后不是空白字符串，则用圆括号引用后追加到 SQL 语句。
	 * @param mixed ... $sql 可变参数，可以转换为字符串的数据。
	 * @return self
	 */
	public function __invoke(...$sql){}
	
	/**
	 * 追加空格前导的 SQL 语句。如果参数为空则空格也不会追加。
	 * @param mixed... $sql 任何可转换为字符串的数据。
	 * @return self
	 */
	public function _(...$sql){}
	
	/**
	 * 追加带字符串定界符的字符串。注意，如果均为无效参数，不会追加任何内容，如果为空字符串，则添加为空字符串。
	 * @param mixed... $sql 可变参数，任何可转换为字符串的数据。
	 * @return self
	 */
	public function string(...$sql){}
	
	/**
	 * 追加 SQL 语句及前缀。
	 * @param string $prefix 前缀。
	 * @param mixed ... $sql 可变参数，任何可以转换为字符中的数据。
	 * @return self
	 */
	public function prefix($prefix, ...$sql){}

	public function jsonSerialize(){}
}
