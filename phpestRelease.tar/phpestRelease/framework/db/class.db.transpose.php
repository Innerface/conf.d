<?php

namespace DB;

/**
 * 将数据的行和列进行转换。
 * 注意，宿主类必须定义常量指示语义列的列名，未指定使用默认值：
 * const TRANSPOSED = [
 * 	'key' => 'field name', 
 * 	'value' => 'field name',
 * 	'type' => 'field name',
 * 	'namespace' => 'field name',
 *  'comment' => 'field name',
 * ]。
 * @author Max Wang
 */
trait Transpose
{
	/**
	 * 将结果数据的行和列进行转换。
	 * @param array $data 引用，查询结果数据。
	 * @return self
	 */
	protected function cast(&$data){}
}