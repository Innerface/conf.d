<?php

namespace DB;

/**
 * 获取单行。
 * @author Max Wang
 * 
 */
trait Row
{
	protected function cast(&$data){}
}