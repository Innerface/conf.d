<?php

namespace SQL;

/**
 * SQL 修改器异常。
 * @author Max Wang
 *
 */
class ModifierException extends \Exception
{
	/**
	 * SQL 编写器。
	 * @var \SQL
	 */
	public $sql;
	/**
	 * SQL 修改器。
	 * @var \SQL\Modifiers
	 */
	public $modifier;
	/**
	 * 修改器名。
	 * @var string
	 */
	public $name;
	
	public function __construct(\SQL $sql, Modifier $modifiers, string $name, string $message = null){}
}