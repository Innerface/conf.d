<?php

namespace DB;

/**
 * 获取行集。
 * @author Max Wang
 * 
 */
trait Rowset
{
	protected function cast(&$data){}
}