<?php


namespace SQL;

use SQL\Writer;

/**
 * SQL 语句修改器。
 * @author Max Wang
 * 
 */
class Modifier
{
	/**
	 * 修改器或别名。
	 * @var array
	 * @example $this->modifiers['cut'] 	=> function ($str, $length) {return substr($str, 0, $length);}
	 * @example $this->modifiers['hash'] => function ($str) {return md5($str);}
	 * @example $this->modifiers['x'] 	=> 'cut'; // 指定 x 为 cut 修改器的别名。
	 */
	protected $modifiers = [
		'i'					=> 'integer',
		'int'				=> 'integer',
		'u'					=> 'unsigned',
		'unsign'			=> 'unsigned',
		'c'					=> 'float',
		'f'					=> 'float',
		'r'					=> 'float',
		'real'				=> 'float',
		'double'			=> 'float',
		'currency'		=> 'float',
		'decimal'		=> 'float',
		'd'					=> 'date',
		't'					=> 'time',
		'dt'					=> 'datetime',
		'ts'					=> 'timestamp',
		'j'					=> 'json',
		'b'					=> 'boolean',
		'bool'				=> 'boolean',
		'n'					=> 'null',
		'nil'				=> 'null',
		'none'				=> 'null',
	];
	
	/**
	 * 修改器所依赖的 SQL 编写器。
	 * @var \SQL\Writer
	 */
	protected $writer;
	
	/**
	 * 构造器。
	 * @param \SQL $writer SQL 编写器。
	 */
	public function __construct(Writer $writer){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $value){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 预置的字符串截取处理器。
	 * @param string $var 源字符串。
	 * @param int $length 限定的长度。
	 * @return string
	 */
	public function cut(string $var, int $length = 0){}
	
	public function integer($var){}
	
	public function unsigned($var){}
	
	public function float($var){}
	
	public function bool($var){}
	
	public function time($var){}
	
	public function date($var){}
	
	public function datetime($var){}
	
	public function timestamp($var){}
	
	public function string($var){}
	
	public function json($var, int $options = null){}
	
	public function null($var){}
}