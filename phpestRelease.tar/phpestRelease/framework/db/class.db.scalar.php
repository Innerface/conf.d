<?php

namespace DB;

/**
 * 获取单值。定义 INDEX 常量指定结果集的索引，可以是整型或字符串键，默认为首行首列。
 * @author Max Wang
 * 
 */
trait scalar
{
	protected function cast(&$data){}
}