<?php

namespace DB;

use DB\Action;

/**
 * 数据库插入操作。
 * @author Max Wang
 */
abstract class Insert extends Action
{
	public function __invoke(){}
}
