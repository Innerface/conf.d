<?php

namespace DB;

use TSetter;
use TGetter;
use IteratorAggregate;

/**
 * 选项。
 * @author Max Wang
 * 
 */
class Options implements \IteratorAggregate
{
	use TSetter, TGetter;
	
	protected $_;
	
	public function __construct(){}
	
	public function getIterator(){}
}
