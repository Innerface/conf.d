<?php

namespace SQL;

/**
 * SQL 执行日志记录。
 * @author Max Wang
 * 
 */
class Log extends \Log
{
	/**
	 * 时间戳。
	 * @var int
	 */
	public $time;
	/**
	 * SQL 语句。
	 * @var string
	 */
	public $sql;
	/**
	 * 耗时。
	 * @var float
	 */
	public $elapsed;
	/**
	 * 错误信息。
	 * @var array|string
	 */
	public $error;
	/**
	 * 警告信息。
	 * @var array
	 */
	public $warnings;
	
	/**
	 * 设置 SQL 执行的时间戳。
	 * @param int $time 时间戳。
	 * @return \SQL\Log $this
	 */
	public function time(int $time){}
	
	/**
	 * 设置 SQL 语句。
	 * @param string|SQL $sql SQL 语句。
	 * @return \SQL\Log $this
	 */
	public function sql($sql){}
	
	/**
	 * 设置耗费的时间。
	 * @param float $elapsed 时间。
	 * @return \SQL\Log
	 */
	public function elapsed(float $elapsed){}
	
	/**
	 * 设置错误。
	 * @param array|Exception|string $error 错误。
	 * @return \SQL\Log
	 */
	public function error($error){}
	
	/**
	 * 设置警告。
	 * @param string|array... $warnings 可变参数，多个警告信息。
	 * @return \SQL\Log
	 */
	public function warnings(...$warnings){}
}
