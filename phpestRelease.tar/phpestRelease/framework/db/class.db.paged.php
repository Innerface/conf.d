<?php

namespace DB;

/**
 * 分页的查询，返回 Data\Paged。
 * @author Max Wang
 * 
 */
class Paged extends Query
{
	/**
	 * 分页尺寸。
	 * @var int
	 */
	public $size = 10;
	/**
	 * 基于 1 的页号。
	 * @var int
	 */
	public $page;
	
	/**
	 * 找到的总行数。
	 * @var int
	 */
	protected $_total;
	
	/**
	 * 构造数据库查询。
	 * @param Service\Loader|IService|\IDBDriver $loader 服务操作加载器。
	 * @param string $sql 可选，SQL 语句。
	 * @param string $count 可选，SQL 数量查询 SQL。对于 MySQL，如果主查询使用了 SQL_CALC_FOUND_ROWS，此语句可以省略。
	 */
	public function __construct($loader, string $sql = null, string $count = null){}
	
	public function __invoke(){}
	
	protected function cast(&$data){}
}