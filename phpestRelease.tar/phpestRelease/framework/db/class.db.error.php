<?php

namespace DB;

/**
 * 数据库错误。
 * @author Max Wang
 * 
 */
class Error
{
	const CONNECT = 1;
	
	public $message;
	public $error;
	public $sql;
	public $level;
	public $trace;
	
	public function __construct(string $message, $error, $sql, int $level = 0, $trace = null){}
}