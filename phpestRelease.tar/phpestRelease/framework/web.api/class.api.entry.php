<?php

namespace API;

/**
 * API 入口。使用类常量定义入口架构。
 * @author Max
 * 
 */
abstract class Entry
{
	/**
	 * 支持的 HTTP 方法列表和映射的对象方法。
	 * 注意：空数组表示不支持任何 HTTP 请求方法，null 表示只要 HTTP 方法名对应的对象方法存在即支持。
	 * 
	 * @var array
	 * @example ['GET'=>'method']
	 */
	const METHODs = null;
	
	/**
	 * 定义 HTTP 方法架构。
	 * @var array
	 */
	const GET = [
		'TITLE' => '入口标题',
		'DESCRIPTION' => '描述',
		'HINT' => '开发提示',
		'ACLs' => null,
		'STATE' => \API::STABLE,
		/**
		 * 输入参数定义。
		 */
		'TYPE' => null,
		'PARAMs' => [
			'id'	=> ['type' => 'int'],
			''
		],
		
		/**
		 * 数据架构。
		 * @var array|string
		 */
		'SCHEMAs' => [
			'200' => 'User',
			'404' => [],
			'403' => []
		],
	];
	
	/**
	 * 类别。
	 * @var string
	 */
	const CATEGORY = '接口类别';
	/**
	 * 标题。
	 * @var string
	 */
	const TITLE = '接口标题';
	/**
	 * 意义，代表的业务意义。
	 * @var string
	 */
	const DESCRIPTION = '意义，接口代表的业务意义。';
	/**
	 * 用法，面向开发者的技术提示。
	 * @var string
	 */
	const HINT = '用法，面向开发者的技术提示。';
	
	/**
	 * 所属的 APP。
	 * @var \API
	 */
	protected $_api;
	/**
	 * 当前的响应。
	 * @var \API\Response
	 */
	protected $_res;
	/**
	 * 当前的请求。
	 * @var \API\Request
	 */
	protected $_req;
	
	/**
	 * 当前的加载器。
	 * @var \Loader
	 */
	protected $_;
	
	/**
	 * 构造入口。
	 * @param \API|\Loader $owner 宿主。
	 */
	public function __construct($owner = null){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 当前的 API。
	 * @return \API
	 */
	public function __invoke(){}
}
