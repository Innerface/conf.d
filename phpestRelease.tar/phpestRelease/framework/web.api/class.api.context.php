<?php

namespace API;

use API;
use API\Request;
use API\Response;

/**
 * API 上下文环境。
 * @author Max
 * 
 */
class Context extends \Context
{
	/**
	 * 请求。
	 * @var \API\Request
	 */
	public $request;
	/**
	 * 响应。
	 * @var \API\Response
	 */
	public $response;
	/**
	 * 当前处理器的文档信息。
	 * @var \API\Doc
	 */
	public $doc;
	/**
	 * 当前的操作。
	 * @var \API\Action|array[\API\Entry, string]
	 */
	public $action;
	
}