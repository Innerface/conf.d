<?php

namespace API;

/**
 * JSON web token.
 * @author Max Wang
 * 
 */
class JWT
{
	public $iss;
	public $iat;
	public $nbf;
	public $exp;
	public $aud;
	public $sub;
	
	public $jti;
	
	public $typ;
	public $alg;
	
	protected $key;
	protected $host;
	protected $origin;
	
	protected $payload = [];
	
	public function __construct(string $key, string $host = null, string $origin = null){}
}