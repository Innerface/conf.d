<?php

namespace Setting;

/**
 * API 应用设置。
 * @author Max Wang
 * @method self ignoreCase() 允许路由忽略大小写。
 * @method self strict() 启用严格模式。
 * @method self cookieless(bool $cookieless) 设置无 cookie 模式。
 * @method self origin(string $origin) 设置允许的跨域访问源。
 */
class API extends APP
{
	public $cookieless;
	public $ignoreCase;
	public $strict;
	public $origin;
	
}