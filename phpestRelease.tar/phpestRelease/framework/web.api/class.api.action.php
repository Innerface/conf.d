<?php

namespace API;

use API;
use API\Entry;

/**
 * 操作。
 * @author Max
 * 
 */
abstract class Action
{
	/**
	 * 运行方法。
	 * @var string
	 */
	const INVOKE = 'run';
	
	/**
	 * 操作依赖的模块。
	 * @var array
	 */
	const USE = null;
	/**
	 * 接口状态：
	 * <ol>
	 * <li>API::DRAFT 草案，正在开发中，不稳定。</li>
	 * <li>API::REVIEW 评审阶段，接近稳定状态。</li>
	 * <li>API::STABLE 稳定。</li>
	 * <li>API::DEPRECATED 已过时，建议采用新的版本。</li>
	 * <li>API::CLOSED 已关闭。</li>
	 * </ol>
	 * @var int
	 */
	const STATE = API::STABLE;
	/**
	 * 操作标题。
	 * @var string
	 */
	const TITLE = null;
	/**
	 * 操作的业务描述。
	 * @var string
	 */
	const DESCRIPTION = null;
	/**
	 * 操作的开发技术提示。
	 * @var string
	 */
	const HINT = null;
	/**
	 * 提交数据的格式：默认为自动判断。
	 * @var string
	 */
	const TYPE = null;
	/**
	 * 查询的数据架构定义。
	 * @var string|array
	 */
	const QUERY = null;
	/**
	 * 提交的数据架构定义：仅 POST 和 PUT 方法允许提交数据。
	 * @var string|array
	 */
	const PARAMs = null;
	/**
	 * 响应的数据架构定义。
	 * @var array 一维数组，键为 HTTP 响应码，值为数据类型（类名，反斜线可以使用点代替）或架构名，也可直接定义数据架构。
	 * @example [200=>'Demo.Sample', 404=>null, ] // Demo.Sample 为示例的 Schema 类名，也可以直接定义数据架构。
	 */
	const SCHEMAs = null;
	/**
	 * 接口的关联接口的链接。
	 * @var array
	 */
	const LINK = null;
	/**
	 * 接口被迁移到新的接口。
	 * @var string
	 */
	const REDIRECT = null;
	
	/**
	 * 所属的 APP。
	 * @var \API
	 */
	protected $_api;
	/**
	 * 当前的响应。
	 * @var \API\JSON
	 */
	protected $_res;
	/**
	 * 当前的请求。
	 * @var \API\Request
	 */
	protected $_req;
	/**
	 * 所属的入口。
	 * @var \API\Entry
	 */
	protected $_entry;
	
	/**
	 * 当前的加载器。
	 * @var \Loader
	 */
	protected $_;
	
	/**
	 * 构造操作。
	 * @param \Loader|\API $owner 宿主。
	 */
	public function __construct($owner = null){}
}