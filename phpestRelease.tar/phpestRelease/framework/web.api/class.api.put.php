<?php

namespace API;

abstract class PUT extends Action
{
	public function data(){}
}