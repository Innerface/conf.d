<?php

namespace API;

use API\Text;

/**
 * API 响应数据结构体。
 * @author Max
 * @property-read array $attributes 数据的特性表。 
 * @property-read int $options JSON 输出的选项。
 */
class JSON extends Text
{
	const FIELDS = [
		'state' => 0,
		'message' => null,
		'type' => null,
		'attributes' => null,
		'data' => null,
		'debug' => null,
		'link' => null,
	];
	
	protected $options = 0;
	
	/**
	 * 设置 JSON 输出的选项标志。
	 * @param int $options 选项，参考 json_encode 格式常量。
	 * @link http://www.php.net/manual/zh/function.json-encode.php 
	 * @return self
	 */
	public function options(int $options = 0){}
	
	/**
	 * 设置不转义反斜线。
	 * @return self
	 */
	public function unescapedSlashes(){}
	
	public function __invoke(bool $return = false){}
	
	protected function file(){}
	
	protected function cache($data){}
	
	protected function queryId(){}
	
	/**
	 * 获取调试信息。
	 * @return array
	 */
	protected function debugInfo(){}
	
	/**
	 * 包装数据。
	 * @param mixed $var 数据。
	 * @return \stdClass 返回数据包装，包含三个属性：attributes, data, type
	 */
	protected function pack(&$var){}
}
