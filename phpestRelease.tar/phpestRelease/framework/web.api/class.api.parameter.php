<?php

namespace API;

/**
 * 参数定义。
 * @author Max
 * 
 */
class Parameter
{
	/**
	 * 数据类型。
	 * @var string
	 */
	public $type;
	/**
	 * 默认值。
	 * @var mixed
	 */
	public $default;
	/**
	 * 标签。
	 * @var string
	 */
	public $label;
	/**
	 * 是否必要项。
	 * @var bool
	 */
	public $required;
	/**
	 * 意义。
	 * @var string
	 */
	public $description;
	/**
	 * 输入提示。
	 * @var string
	 */
	public $hint;
	/**
	 * 定义的验证器。
	 * @var array
	 */
	public $validators;
	/**
	 * 定义的规范化器。
	 * @var array
	 */
	public $normalizers;
	/**
	 * 定义的过滤器。
	 * @var array
	 */
	public $filters;
}