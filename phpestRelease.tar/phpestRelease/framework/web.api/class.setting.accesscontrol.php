<?php

namespace Setting;

class AccessControl extends \Setting
{
	public $maxAge;
	public $origin;
	public $headers;
	public $method;
}