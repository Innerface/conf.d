<?php

/**
 * 符合 RESTful 标准的 API 接口应用基类。
 * @author Max
 * 
 */
abstract class API extends web
{
	/**
	 * 版本状态：已关闭。
	 * @var integer
	 */
	const CLOSED = 5;
	/**
	 * 版本状态：草案，正在开发中。
	 * @var integer
	 */
	const DRAFT = 1;
	/**
	 * 版本状态：开发完成，正在评审和测试中。
	 * @var integer
	 */
	const REVIEW = 2;
	/**
	 * 版本状态：过时，不建议采用，有可能被移除。
	 * @var integer
	 */
	const DEPRECATED = 3;
	/**
	 * 版本状态：稳定。
	 * @var integer
	 */
	const STABLE = 4;
	/**
	 * 版本状态：未实现。
	 * @var integer
	 */
	const NOT_IMPLEMENT = 0;
	
	/**
	 * 文档接口方法：默认为 VIEW。
	 * @var string
	 */
	const DOC = 'VIEW';
	/**
	 * 调试接口方法：默认为 TRACE。
	 * @var string
	 */
	const TRACE = 'TRACE';
	
	/**
	 * 接口支持的方法。
	 * @var array
	 */
	const METHODs = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'TRACE'];
	
	/**
	 * 定义自定义的请求头。
	 * @var array
	 */
	const REQUESTs = [
		'*'     => [
			'Authorization', 
			'X-Requested-With', 
			'X-Version',
		],
		'PUT'   => ['Content-Type'], 
		'POST'  => ['Content-Type'], 
		'PATCH' => ['Content-Type'],
	];
	
	/**
	 * 定义自定义的响应头。
	 * @var array
	 */
	const RESPONSEs = [
		'*' => [
			'X-Powered-By',
			'X-Request-Id',
			'X-XSS-Protection',
			'X-Version',
		],
	];
	
	/**
	 * 全局响应的数据架构，其中 200 由接口定义，其它统一定义。
	 * @var array
	 */
	const DATAs = [
		400 => [],
	];
	
	/**
	 * 目录和标题。
	 * @var array
	 */
	const CATALOG = [];
	
	/**
	 * 版本状态，序号为版本号，值为版本状态。控制版本列表，不在此处列出的版本不能访问。
	 * @var array
	 */
	const VERSION = [
		1 => self::DRAFT, 
	];
	
	/**
	 * 接口说明。
	 * @var string
	 */
	const DESCRIPTION = null;
	/**
	 * 接口标题。
	 * @var string
	 */
	const TITLE = null;
	/**
	 * 开发提示。
	 * @var string
	 */
	const HINT = null;
	/**
	 * 版权声明。
	 * @var string
	 */
	const COPYRIGHT = null;
	/**
	 * 全局的 state 定义。
	 * @var array
	 */
	const STATE = [
		'OK',
		'Warnings',
		'Fail',
		'Error',
	];
	
	/**
	 * 严格模式：严格模式下禁止自定义结构数据，必须使用强类型的数据架构。
	 * @var bool
	 */
	const STRICT = true;
	/**
	 * 数据架构声明。
	 * @var array
	 */
	const SCHEMAs = null;
	/**
	 * API 实现的级别。
	 * @var integer
	 */
	const LEVEL = 0;
	
	/**
	 * 当前的版本，默认为 1。
	 * @var int
	 */
	public $version = 1;
	/**
	 * 调试模式。
	 * @var bool
	 */
	public $debug;
	
	/**
	 * 严格路由模式。
	 * @var bool
	 */
	public $strict = true;
	/**
	 * 路由检测时是否忽略大小写，默认大小写敏感，不忽略。单条路由也可以独立控制。
	 * @var bool
	 */
	public $ignoreCase;
	/**
	 * 访问频率限制。
	 * @var array
	 */
	public $rates;
	/**
	 * 访问控制允许的来源。
	 * @var string
	 */
	public $origin;
	
	/**
	 * 已定义的验证器（单字符，区分大小写）：d 数字，w 单词，s 整数表（逗号分隔，支持 - 号），S 无符号整数表（逗号分隔）。
	 * 验证器扩展定义：定义宏变量的数据验证器（在模式定义段中以正斜线引入的符号，指定该段的模式，单字母，a-zA-Z，区分大小写）。
	 * @var array
	 */
	public $validators = [
				'd'	=> 'ctype_digit',
	];
	
	/**
	 * 上下文环境。
	 * @var \API\Context
	 */
	protected $context;
	/**
	 * 路由表。
	 * @var array
	 * @example
	 * $this->routes[] = (object)['method'=>'GET|POST', 'pattern'=>'/user/:id\d/abc', 'entry'=>function(){}];
	 */
	protected $routes = [];
	/**
	 * 全部入口。
	 * @var array
	 */
	protected $entries;
	/**
	 * 当前的响应操作。
	 * @var \API\JSON
	 */
	protected $res;
	/**
	 * 当前的请求。
	 * @var API\Request
	 */
	protected $req;
	
	/**
	 * 映射 GET 请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 */
	public function GET(string $pattern, $entry){}
	
	/**
	 * 映射 POST 请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 */
	public function POST(string $pattern, $entry){}
	
	/**
	 * 映射 PUT 请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 */
	public function PUT(string $pattern, $entry){}
	
	/**
	 * 映射 DELETE 请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 */
	public function DELETE(string $pattern, $entry){}
	
	/**
	 * 映射 PATCH 请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 */
	public function PATCH(string $pattern, $entry){}
	
	/**
	 * 映射请求，模式中捕获的命名变量会做为入口或闭包的属主对象的属性，序号变量会作为入口或闭包的参数依序代入。
	 * @param string $method HTTP 方法或列表，多个方法使用竖线 "|" 分隔，如 "GET|POST"。
	 * @param string $pattern 请求模式，用于匹配请求的路径信息。
	 * @param string|callable $entry 映射到的入口。
	 * @return self
	 * @example map('GET|POST', '/user/?id\d', '/user'); // 捕捉到的 $id 变量会赋值给 user 入口的同名属性
	 * @example map('GET|PUT', '/user/?\d', function($id){}); // 捕捉到的序号（匿名）变量会作为参数依次传给闭包
	 */
	public function map(string $method, string $pattern, $entry){}
	
	/**
	 * 配置路由表。
	 * @param string $routes 路由表。
	 * @return self
	 */
	public function routes(string $routes){}
	
	/**
	 * 启用 COOKIE。默认为无 COOKIE 模式。
	 * @return self
	 */
	public function enableCookie(){}
	
	/**
	 * 当前的响应对象。
	 * @return \API\JSON
	 */
	public function response(){}
	
	/**
	 * 当前的请求。
	 * @return \API\Request
	 */
	public function request(){}
	
	public function debugInfo(){}
	
	/**
	 * 当前的调用频率限制。
	 * @return number[]
	 */
	public function rateLimited(){}
	
	public function authorizer(){}
	
	public function methods(){}
	
	/**
	 * 获取当前请求的操作（Action/Entry），仅当请求已加载时有效。
	 * @return \API\Doc
	 */
	public function getRequestDoc(){}
	
	protected function initialize(){}
	
	/**
	 * 解析路由表。
	 * @param array $routes 路由表。
	 * @return int|bool 成功解析返回 true，否则返回出错的行号。
	 */
	protected function parseRoutes(array & $routes){}
	
	/**
	 * 列出定义的全部入口。
	 * @param int $version 可选，版本。
	 * @return array
	 */
	protected function list(int $version = null){}
	
	/**
	 * 提取路由定义的数据。
	 * @param string $pathinfo 请求路径信息。
	 * @param string $entry 入口信息。
	 * @param array $args 匿名变量表。
	 * @param array $vars 命名变量表。
	 * @return boolean 是否存在重写定义。
	 */
	protected function extract(string & $pathinfo, string & $entry, array $args = null, array $vars = null){}
	
	/**
	 * 匹配。
	 * @param string $method 请求的方法。
	 * @param string $pathinfo 请求的路径信息。
	 * @return stdClass 返回：entry 入口名或回调，vars 宏变量，找不到返回 null。
	 */
	protected function match(string $method, string $pathinfo){}
	
	protected function pathpass(){}
	
	protected function route(){}
	
	/**
	 * 请求转发。
	 * @param string $method 请求的方法。
	 * @param string $pathinfo 请求的链接。
	 * @param int $version 请求的版本。
	 * @return bool 如果请求已经处理则返回 true，则中止后续操作。
	 */
	protected function forward(string $method, string $pathinfo, int $version = null){}
	
	protected function xmlParse(string $xml){}
	
	protected function jsonParse(string $raw){}
	
	/**
	 * 解析 POST, PUT 和 PATCH 方法提交的数据。
	 * @return void
	 */
	protected function postData(){}
	
	protected function dispatch(){}
	
	protected function group(string $method, array $index){}
	
	/**
	 * 调用接口。
	 * @param string $method 请求的方法。
	 * @param string|Closure $index 入口。
	 * @param mixed $data 引用，输出入口返回的数据。 
	 * @return bool
	 */
	protected function invoke(string $method, $index, & $data = null){}
	
	/**
	 * 处理文档请求。
	 * @param string $method 请求的方法。
	 * @param string $pathinfo 请求的链接。
	 * @param int $version 请求的版本。
	 * @return bool 如果请求已经处理则返回 true，则中止后续操作。
	 */
	protected function manual(string $method, string $pathinfo, int $version = null){}
	
	/**
	 * 获取 API 入口资源定义的相对目录。
	 * @param int $version 版本号。
	 * @return string 返回相对于当前应用目录的子目录。注意：不能为空，也不能以目录分隔符开始或结束。
	 */
	protected function getEntryDirectory(int $version){}
	
	/**
	 * 加载接口。
	 * @param string $index 接口。
	 * @param string $method 方法。
	 * @param int $version 版本。
	 * @return \API\Entry
	 */
	protected function load(string $index, string $method, int $version){}
	
	/**
	 * 测试路径段。
	 * @param string $pattern 模式。
	 * @param string $path 路径段。
	 * @param bool $ignoreCase 可选，是否忽略大小写。
	 * @return bool
	 */
	protected function test(string $pattern, string $path, bool $ignoreCase = false){}
	
	/**
	 * 版本状态名转换。
	 * @param int $state 版本状态值。
	 * @return string 状态名。
	 */
	protected function version_state(int $state){}
	
	protected function index(int $version){}
	
	protected function entry($file){}
	
	protected function docs($index, $version){}
}
