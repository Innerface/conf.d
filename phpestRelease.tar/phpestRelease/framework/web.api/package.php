<?php

return [
	'use' => ['system.web'],
];

/**
 * 获取当前的 API 应用。
 * @return API 未创建 API 应用实例则返回 null。
 */
function api(){}