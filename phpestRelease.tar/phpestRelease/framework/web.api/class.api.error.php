<?php

namespace API;

class Error extends Response
{
	/**
	 * 错误代码。
	 * @var int
	 */
	public $code;
	/**
	 * 错误消息。
	 * @var string
	 */
	public $error;
	
	public function __construct(int $code = 0, $error = null){}
	
	protected function main(){}
}