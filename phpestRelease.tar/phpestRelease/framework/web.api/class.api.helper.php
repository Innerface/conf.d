<?php

namespace API;

/**
 * API 工具类。
 * @author Max Wang
 * 
 */
class Helper
{
	protected $entry;
	protected $method;
	
	public function __construct($entry, string $method){}
	
	/**
	 * 准备请求对象。
	 * @param Request $req 请求对象。
	 * @return \API\Helper
	 */
	public function ready(Request $req){}
	
	/**
	 * 获取入口文档。
	 * @return array
	 */
	public function docs(){}
}