<?php

namespace API;

abstract class POST extends Action
{
	/**
	 * 构造 POST 操作。
	 * @param \Loader|\API $owner 宿主。
	 */
	public function __construct($owner){}
}