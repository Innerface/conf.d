<?php

namespace API;

/**
 * API 接口服务。
 * 
 */
abstract class Server implements \IEventHost
{
	use \TEventHost;
	
	const EVENT = [
		'init' => null,
	];
		
	/**
	 * 接口定义文件夹的名字。
	 * @var string
	 */
	const DIRECTORY = 'api';
	/**
	 * 默认的接口调用超时时间。
	 * @var int
	 */
	const TIMEOUT = 600;
	
	protected $client;
	protected $redis;
	
	/**
	 * 伙伴（接口调用相关方）配置。
	 * @var array
	 */
	public $parters;
	
	/**
	 * 账号设置。
	 * @var array 每个元素为一个账号，键为账号名。
	 */
	public $settings;
	
	/**
	 * 构造器。
	 * @param array $settings 可选，设置项。
	 * @param string|IHttpClient $client 可选，HTTP 请求客户端。
	 * @param \Redis $redis 可选，Redis。 
	 * @throws RuntimeException
	 */
	public function __construct(\Redis $redis, \IHttpClient $client = null){}
	
	/**
	 * 初始化。
	 */
	protected function init(){}
	
	/**
	 * API 接口定义文件存放的目录。
	 * @return string
	 */
	public function directory(){}
	
	/**
	 * 获取合作伙伴配置项。
	 * @param string $parter 合作伙伴名。
	 * @return object 属性至少包括  token, method, timeout 等，未找到返回 null。
	 */
	public function parter(string $parter){}
	
	public function __call($name, array $args = null){}
	
	/**
	 * 获取 Redis。
	 * @return \Redis
	 */
	public function redis(){}
	
	/**
	 * 返回全局标识符。
	 * @return string
	 */
	public abstract function guid();
	
	/**
	 * 加载请求定义。
	 * @param string $name API 请求定义名称。将被映射到对应的类。
	 * @return string|boolean
	 */
	protected function load(string $name){}
	
	protected function setError($code = 0, $message = 'success'){}
	
	/**
	 * 调用一个指定的请求：调用 API 目录下的请求定义，格式类似于 [API].[NAME].php。
	 * @param string $name 请求名。
	 * @param array $data 可选，请求的数据。
	 * @return array|string|boolean 如果成功，返回解析后的请求结果或错误信息，否则返回 null。
	 */
	public function call($name, array $data = null){}
	
	/**
	 * 发起一个指定的请求：调用 API 目录下的请求定义，格式类似于 api.name.php。
	 * @param string $name 请求名。
	 * @param array $data 可选，请求的数据。
	 * @return \API\Request 如果成功，返回请求可继续调用，否则返回 null。
	 */
	public function request($name, array $data = null){}
	
	/**
	 * 响应请求。
	 */
	public abstract function response();
	
	/**
	 * 错误。
	 * @return array
	 */
	public function error(){}
	
	/**
	 * 默认请求处理。
	 * @param string $name 可选，请求名。
	 * @param array $data 可选，请求参数。
	 */
	public abstract function main($name = null, array $data = null);
	
	/**
	 * 附加事件处理器。
	 * @param string $event 事件名。
	 * @param callable $handler 处理器。
	 */
	public function attach($event, callable $handler){}
	
	/**
	 * 引发事件。
	 * @param string $event
	 * @param array $data
	 */
	protected function raise($event, array $data = null){}
	
	/**
	 * 一般的事件调用。
	 * @param string $event 事件名。
	 * @param array $args 事件参数。
	 * @return void 可返回 true 中止后续事件触发。
	 */
	protected function on($event, array $args = null){}
	
	/**
	 * GET 请求。
	 * @param string $url 请求的链接。
	 * @param string|array $params 可选，请求的参数。
	 * @return string 返回响应内容，错误返回 null。
	 */
	public function get($url, $params = null){}
	
	/**
	 * POST 请求。
	 * @param string $url 请求的链接。
	 * @param string|array $params 可选，请求的参数。上传文件在参数表里的数据前加 @ 符号。例如：'name' => '@/full/path/filename.ext'。
	 * @return string 返回响应内容，错误返回 null。
	 */
	public function post($url, $params = null){}
}
