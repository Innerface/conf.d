<?php

namespace API;

/**
 * 接口文档。
 * @author Max Wang
 * 
 */
class Doc implements \JsonSerializable
{
	/**
	 * 接口引用的模块。
	 * @var array
	 */
	public $USE = null;
	/**
	 * 接口状态：
	 * <ol>
	 * <li>API::DRAFT 草案，正在开发中，不稳定。</li>
	 * <li>API::REVIEW 评审阶段，接近稳定状态。</li>
	 * <li>API::STABLE 稳定。</li>
	 * <li>API::DEPRECATED 已过时，建议采用新的版本。</li>
	 * <li>API::CLOSED 已关闭。</li>
	 * </ol>
	 * @var int
	 * @see \API::DRAFT
	 * @see \API::REVIEW
	 * @see \API::STABLE
	 * @see \API::DEPRECATED
	 */
	public $STATE = \API::STABLE;
	/**
	 * 操作标题。
	 * @var string
	 */
	public $TITLE = null;
	/**
	 * 操作的业务描述。
	 * @var string
	 */
	public $DESCRIPTION = null;
	/**
	 * 操作的开发技术提示。
	 * @var string
	 */
	public $HINT = null;
	/**
	 * 查询的数据架构定义。
	 * @var string|array
	 */
	public $QUERY = null;
	/**
	 * 提交数据的格式：默认为自动判断，仅在 POST 和 PUT 方法下有效。
	 * @var string
	 */
	public $TYPE = null;
	/**
	 * 提交的数据架构定义：仅 POST 和 PUT 方法允许提交数据。
	 * @var string|array
	 */
	public $PARAMs = null;
	/**
	 * 响应的数据架构定义。
	 * @var array 一维数组，键为 HTTP 响应码，值为数据类型（类名，反斜线可以使用点代替）或架构名，也可直接定义数据架构。
	 * @example [200=>'Demo.Sample', 404=>null, ] // Demo.Sample 为示例的 Schema 类名，也可以直接定义数据架构。
	 */
	public $SCHEMAs = null;
	/**
	 * 被重定向到的位置。
	 * @var string
	 */
	public $REDIRECT = null;
	/**
	 * 相关操作的链接。
	 * @var array
	 */
	public $LINK = null;
	/**
	 * 样本数据。
	 * @var array
	 */
	public $SAMPLES = null;
	
	public function jsonSerialize(){}
}
