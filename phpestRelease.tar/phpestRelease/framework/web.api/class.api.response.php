<?php

namespace API;

/**
 * API 响应数据结构体。
 * @author Max Wang
 */
class Response extends \Response
{
	/**
	 * 正常。
	 * @var integer
	 */
	const OK = 0;
	/**
	 * 有警告，但不影响程序逻辑正常进行。
	 * @var integer
	 */
	const WARNINGS = 1;
	/**
	 * 失败。
	 * @var integer
	 */
	const FAIL = 2;
	/**
	 * 出错。
	 * @var integer
	 */
	const ERROR = 3;
	
	protected $state;
	protected $message;
	protected $options;
	protected $error;
	protected $warnings;
	protected $debug;
	/**
	 * 所有者。
	 * @var \API
	 */
	protected $_owner;
	
	/**
	 * 要输出的主体数据项目。
	 * @param \API $owner 属主。
	 */
	public function __construct(\API $owner){}
	
	/**
	 * 返回所属的 API。
	 * @return API
	 */
	public function owner(){}
	
	/**
	 * 设置 HTTP 状态码。
	 * @param int $status HTTP 状态码。
	 * @param string $reason 可选，HTTP 状态原因。
	 * @return self
	 */
	public function status(int $status = 200, string $reason = null, int $versoin = 0){}
	
	/**
	 * 设置自定义的状态。
	 * @param int $state 状态值。
	 * @return self
	 */
	public function state(int $state = 0){}
	
	/**
	 * 输出面向终端用户友好的消息。
	 * @param string $message 消息。
	 * @return self
	 */
	public function message(string $message = null){}
	
	/**
	 * 设置文件来源。
	 * @param string $file 文件名。
	 * @return self
	 */
	public function source(string $file = null){}
	
	/**
	 * 输出调试信息。
	 * @param string $name 调试信息名称。
	 * @param mixed $vars 要输出的调试信息。无参数输出调试回溯跟踪。
	 * @return self
	 */
	public function debug(string $name = null, $vars = null){}
	
	/**
	 * 输出错误信息。
	 * @param mixed $error 错误。
	 * @return self
	 */
	public function error($error){}
	
	/**
	 * 追加警告。
	 * @param string... $warnings 可变参数，警告信息。
	 * @return self
	 */
	public function warning(string ... $warnings){}
	
	public function __invoke(bool $return = false){}
	
	/**
	 * 获取所有的头设置。
	 * @return array
	 */
	public function headers(){}
	
	/**
	 * 输出响应头。
	 * @return self
	 */
	public function send(){}
}
