<?php

namespace API;

abstract class HEAD extends Action
{
	public function run(Request $req, Response $res){}
}