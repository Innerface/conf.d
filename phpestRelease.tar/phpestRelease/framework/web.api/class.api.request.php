<?php

namespace API;

use API;
use obj;

/**
 * API 请求。包含路由请求中提交的宏变量。
 * @author Max
 * 
 */
class Request extends obj
{
	protected $owner;
	
	/**
	 * 构造请求。
	 * @param API $owner 属主。
	 * @param array $vars 可选，宏变量表。
	 */
	public function __construct(API $owner, array $vars = null){}
}
