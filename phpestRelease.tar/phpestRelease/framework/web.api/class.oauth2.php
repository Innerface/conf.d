<?php

/**
 * OAuth 2.0 验证管理器。
 * @author Max Wang
 * 
 */
class OAuth2 extends AuthManager
{
	protected $api;
	
	public function authenticate($token = null){}
	public function authorize(string $entry, $token = null){}
	public function token(){}
	public function user($token = null){}
	public function timeout($token = null){}
	public function refresh($token = null){}
	
	public function revoke($token = null){}
	
	public function isSingleton() : bool{}
	
	public function debugInfo(){}
}