<?php

namespace API;

use API\Response;

/**
 * API 响应数据结构体。
 * @author Max Wang
 */
abstract class Text extends Response
{
	protected $type;
	protected $data;
	protected $error;
	protected $docs;
	protected $prettyFormat;
	protected $unescapedUTF8;
	
	/**
	 * 要输出的主体数据项目。
	 * @param object $owner 属主。
	 */
	public function __construct($owner){}
	
	/**
	 * 设置输出的数据架构类型名。
	 * @param string $type 架构类型名。
	 * @return self
	 */
	public function type(string $type){}
	
	/**
	 * 设置输出的数据。一般不要直接使用此方法设置数据。
	 * @param mixed $data 数据。
	 * @return self
	 */
	public function data($data){}
	
	/**
	 * 输出格式可读的友好格式。
	 * @return self
	 */
	public function prettyFormat(){}
	/**
	 * 格式控制：不转义 UTF8 字符为编码，原文输出。
	 * @return self
	 */
	public function unescapedUTF8(){}
}
