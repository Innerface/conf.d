<?php

namespace Validator;

/**
 * 长度验证器。用于字符串（支持字符集）和数组的长度验证。
 * @version 1.0
 * @since 1.0
 */
class Length extends \Validator
{
	const GUID = 'length';
	
	/**
	 * 错误。
	 * @var array
	 */
	const ERROR = [
		0 => 'successful',
		1 => '输入的内容太长或太短，不符合要求。',
		2 => '输入的内容太短。',
		3 => '输入的内容太长。',
	];
	
	/**
	 * 最小长度。默认不限制。
	 * @var int
	 */
	public $min;
	/**
	 * 最大长度。默认不限制。
	 * @var int
	 */
	public $max;
	
	/**
	 * 如果是字符串，则指定字符串的字符集。默认是 UTF8。
	 * @var string
	 */
	public $charset;
	
	/**
	 * 构造长度验证器。
	 * @param int $max 最大长度，0 表示不限制。
	 * @param int $min 最小长度，0 表示不限制。
	 * @param string $charset 字符集。
	 */
	public function __construct(int $max = 0, int $min = 0, string $charset = 'utf-8'){}
	
	public function __toString(){}
	
	public static function correct(& $min, & $max){}
	
	protected function try($var){}
	
	/**
	 * 支持编码方式的字符串长度测试。
	 * @param string $str 字符串。
	 * @param string $charset 字符集，默认是 utf-8。
	 * @return int 返回字符串长度。
	 */
	public static function strlen($str, $charset = 'utf-8'){}
}