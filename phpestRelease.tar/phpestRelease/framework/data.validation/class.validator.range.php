<?php

namespace Validator;

/**
 * 数值（整数，浮点数）、日期（日期必须转换为标准格式yyyy-MM-dd）和时间范围验证器，不进行类型检查，如果类型不符，将简单忽略。
 * @version 1.0
 * @since 1.0
 */
class Range extends \Validator
{
	const GUID = 'range';
	
	/**
	 * 范围。
	 * @var \range
	 */
	public $range;
	
	public function __construct(\range $range = null){}
	
	public function __toString(){}
	
	protected function try($var){}
	
}

