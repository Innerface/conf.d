<?php

namespace Validator;

/**
 * 文本集合验证器。
 * @author Max
 * 
 */
class Collection extends \Validator
{
	const GUID = 'collection';
	
	const ERROR = [
		1 => '',
	];
	
	/**
	 * 值的选项。
	 * @var array
	 */
	public $options;
	
	/**
	 * 构造选项验证器。
	 * @param array $options 可用的选项，选项不能为空。
	 */
	public function __construct(array $options){}
	
	public function __toString(){}
	
	protected function try($var){}
}