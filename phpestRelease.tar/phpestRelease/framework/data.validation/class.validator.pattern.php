<?php

namespace Validator;

/**
 * 命名的模式验证器。
 * @version 1.0
 * @since 1.0
 */
class Pattern extends \Validator
{
	const GUID = 'pattern';
	
	const INVALID_PATTERN = 2;
	
	const ERROR = [
		'OK',
		'Failed',
		'Invalid pattern',
	];
	
	/**
	 * 区域无关的命名模式。
	 * @var array
	 */
	const PATTERNS = [
		'telephone' => '/^\+\d+(-\d+)*$/',
		'chinese' => '/^[\x{4E00}-\x{9FA5}]+$/iu', 
		'id' => '/^[a-z]\w*([\.-]\w+)*$/i',
	];
	
	/**
	 * 全局的命名模式。
	 * 默认包括：domain, ip, ipv4, ipv6, public_ip, url, email, mac
	 * @var array
	 */
	public static $PATTERNS = [];
	
	/**
	 * 模式名。
	 * @var string
	 */
	public $name;
	
	/**
	 * 构造器。
	 * @param string $name 模式名。
	 */
	public function __construct(string $name = null){}
	
	public function __toString(){}
	
	protected function try($var){}
}

Pattern::$PATTERNS = [
	'domain' => function (string $domain){},
	'ipv4' => function (string $ip){},
	'ipv6' => function (string $ip){},
	'ip' => function (string $ip){},
	'public_ip' => function (string $ip){},
	'email' => function (string $email){},
	'url' => function (string $uri){},
	'mac' => function (string $mac){},
];
