<?php

namespace Validator;

/**
 * 自定义验证器。
 */
class Custom extends \Validator
{
	const GUID = 'custom';
	
	/**
	 * 回调，签名为 bool function(mixed $value)，返回值将被强制转换为 bool 类型。
	 * @var callable
	 */
	public $callback;
	
	/**
	 * 自定义验证构造器。
	 * @param callback|Expression $callback 回调或表达式（值作为 $Value 变量传递）， 回调签名为 boolean function(mixed $value)，返回值将被强制转换为 boolean 类型。 
	 * @param string $message 可选，验证错误的消息。
	 */
	public function __construct(callable $callback = null, string $message=null, string $locale = null){}
	
	public function __toString(){}
	
	protected function try($var){}
}
