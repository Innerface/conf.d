<?php

namespace Validator;

/**
 * 正则表达式验证。模式无效将引发运行时异常。
 * @version 1.0
 * @since 1.0
 */
class Regexp extends \Validator 
{
	const GUID = 'regexp';
	
	const ERROR = [
		'OK',
		'Failed',
	];
	
	/**
	 * 正则模式。
	 * @var string
	 */
	public $pattern;
	
	/**
	 * 构造正则表达式验证。
	 * @param string $pattern 正则表达式。
	 */
	public function __construct(string $pattern = null){}
	
	public function __toString(){}
	
	protected function try($var){}
}
