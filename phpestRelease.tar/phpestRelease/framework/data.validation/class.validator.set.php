<?php

namespace Validator;

/**
 * 集合验证器。
 * @author Max
 * 
 */
class Set extends \Validator
{
	const GUID = 'set';
	
	/**
	 * 集合选项。
	 * @var array 键必须为2的幂，值为集合项文本。元素数量不要超过系统限制（CPU位数）。
	 */
	public $options;
	
	/**
	 * 构造选项验证器。
	 * @param array $options 可用的选项，选项不能为空，注意：键必须为2的幂，值为集合项文本。元素数量不能超过系统限制（CPU位数）。
	 * @param string $message 可选，消息。
	 * @param string $locale 可选，区域代码。
	 * @throws \RuntimeException 选项为空，或者集合选项元素数量太大引发此异常。
	 */
	public function __construct(array $options, string $message = null, string $locale = null){}
	
	public function __toString(){}
	
	protected function try($var){}
}