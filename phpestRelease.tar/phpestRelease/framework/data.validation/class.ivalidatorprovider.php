<?php

/**
 * 命名的验证器提供者。
 * @author Max
 * 
 */
interface IValidatorProvider
{
	/**
	 * 获取验证器。
	 * @param string $name 名字。
	 * @param mixed... $args 可变参数。
	 * @return Validator 返回验证器。
	 */
	public function validator(string $name, ... $args);
	
	/**
	 * 获取命名模式。
	 * @param string $name 模式名。
	 * @return string|callable
	 */
	public function pattern(string $name);
}