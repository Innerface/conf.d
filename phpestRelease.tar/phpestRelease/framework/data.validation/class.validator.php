<?php

/**
 * 数据验证器基类。
 * @author Max
 * 
 */
abstract class Validator implements IValidator
{
	const OK = 0;
	const FAILED = 1;
	
	/**
	 * 错误代码和意义。
	 * @var array
	 */
	const ERROR = [
		'OK', 
		'Failed',
	];
	
	/**
	 * 验证器的全局标识号。
	 * @var string
	 */
	const GUID = null;
	
	/**
	 * 验证前的回调，用于对源数据进行预处理。
	 * @var array
	 */
	protected $handlers;
	/**
	 * 错误代码。
	 * @var int
	 */
	protected $error = 0;
	
	public function validate($var){}
	
	public function error(){}
	
	/**
	 * 重置状态。
	 * @return self $this
	 */
	public function reset(){}
	
	/**
	 * 最近一次验证是否失败。
	 * @return bool
	 */
	public function failed(){}
	
	/**
	 * 附加预处理器。
	 * @param callable $handler 预处理器。签名为：mixed function(mixed $var)。
	 * @return self $this 返回当前验证器。
	 */
	public function attach(callable $handler){}
	
	abstract public function __toString();
	
	/**
	 * 基本验证之空值（null，0 长度字符串，无元素的数组，注意：0 或 '0' 是非空值）判断。
	 * @param mixed $var 值。
	 * @return bool 是空值返回 true，否则返回 false。
	 */
	public function empty($var){}
	
	/**
	 * 使用回调对待验证数据的值进行预处理。
	 * @param mixed $var 待验证的值。
	 * @return mixed 返回处理后的值。
	 */
	protected function prepare($var = null){}
	
	/**
	 * 尝试验证。
	 * @param mixed $var 待验证的数据。已经过 handler 处理。
	 * @return bool 如果验证通过则返回 true，否则返回 false。
	 */
	protected abstract function try($var);
	/**
	 * 根据验证结果设置错误代码。
	 * @param bool $result 验证结果。
	 * @param int $error 可选，错误代码。
	 * @return bool 返回验证结果
	 */
	protected function setError(bool $result, int $error = 1){}
}
