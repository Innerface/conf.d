<?php

namespace Validator;

/**
 * 枚举验证器。
 * @author Max
 * 
 */
class Enum extends \Validator
{
	const GUID = 'enum';
	
	/**
	 * 枚举的选项：一维自然数组，值为所有有效的选项的列表。
	 * @var array
	 */
	public $options;
	
	/**
	 * 构造选项验证器。
	 * @param array $options 可用的选项，选项不能为空。
	 */
	public function __construct(array $options){}
	
	public function __toString(){}
	
	protected function try($var){}
}