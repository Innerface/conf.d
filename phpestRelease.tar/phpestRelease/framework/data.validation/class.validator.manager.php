<?php

namespace Validator;

/**
 * 验证管理器。
 * @author Max Wang
 * 
 */
class Manager
{
	protected $owner;
	protected $context;
	protected $data;
	
	public function __construct($owner, $data, $context){}
	
}