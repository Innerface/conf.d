<?php

/**
 * 验证器接口。
 * @author Max Wang
 * 
 */
interface IValidator
{
	/**
	 * 验证。
	 * @param mixed $var 待验证的数据。
	 * @return bool 验证通过返回 true。
	 */
	public function validate($var);
	/**
	 * 获取错误代码。
	 * @return int 返回错误码。
	 */
	public function error();
}