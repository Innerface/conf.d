<?php

namespace Validator;

/**
 * 必要项验证器。
 * @version 1.0
 * @since 1.0
 */
class Required extends \Validator
{
	const GUID = 'required';
	
	public function __toString(){}
	
	protected function try($var){}
}
