<?php

namespace Validator;

/**
 * 比较验证器，跟其它参照对象的属性比较。如果参照对象属性值为空则不验证。
 * @version 0.1.0
 * @since 0.1.0
 */
class Compare extends \Validator
{
	const GUID = 'compare';
	
	/**
	 * = 相等。
	 * @var string
	 */
	const EQUAL = '=';
	/**
	 * < 小于。
	 * @var string
	 */
	const LESSTHAN = '<';
	/**
	 * > 大于。
	 * @var string
	 */
	const GREATERTHAN = '>';
	/**
	 * != 不等。
	 * @var string
	 */
	const NOEQUAL = '!=';
	/**
	 * <= 小于或等于。
	 * @var string
	 */
	const LESSTHAN_EQUAL = '<=';
	/**
	 * >= 大于或等于。
	 * @var string
	 */
	const GREATERTHAN_EQUAL = '>=';
	/**
	 * 完全相同，包括类型。
	 * @var string
	 */
	const IDENTICAL = '===';
	/**
	 * 不相等，或者类型不同。
	 * @var string
	 */
	const NOT_IDENTICAL = '!==';
	/**
	 * 元素测试（in），包含指定的键或属性。
	 * @var string
	 */
	const IN = 'in';
	/**
	 * 元素存在（has|exists），包含指定的元素值。
	 * @var string
	 */
	const HAS = 'has';
	
	/**
	 * 操作符。支持的操作符包括：<ol>
	 * <li>相等（=|eq|==）。</li>
	 * <li>不等（!=|ne|<>）。</li>
	 * <li>大于（>|gt）。</li>
	 * <li>小于（<|lt）。</li>
	 * <li>大于或等于（>=|gte）。</li>
	 * <li>小于或等于（<=|lte）。</li>
	 * <li>完全相等（===）。</li>
	 * <li>不完全相等（!==）。</li>
	 * <li>元素测试（in），包含指定的键或属性。</li>
	 * <li>元素存在（has），包含指定的元素值。</li>
	 * </ol>
	 * 用待验证的值与参照值比较。如：待期待待验证的值比参照值大，应选用 > 操作符。
	 * @var string
	 */
	public $operator = self::EQUAL;
	/**
	 * 宿主或参照值。
	 * @var mixed
	 */
	public $reference;
	
	/**
	 * 比较验证构造器。
	 * @param object|callable $reference 参照值。参考 get 函数用法。
	 * @param string $operator 可选，操作符类型，默认为相等判断。<ol>
	 * <li>相等（=|eq|==）。</li>
	 * <li>不等（!=|ne|<>）。</li>
	 * <li>大于（>|gt）。</li>
	 * <li>小于（<|lt）。</li>
	 * <li>大于或等于（>=|gte）。</li>
	 * <li>小于或等于（<=|lte）。</li>
	 * <li>完全相等（===）。</li>
	 * <li>不完全相等（!==）。</li>
	 * <li>元素测试（in），包含指定的键或属性。</li>
	 * <li>元素存在（has|exists），包含指定的元素值。</li>
	 * </ol>
	 */
	public function __construct($reference, string $operator = self::EQUAL){}
	
	public function __toString(){}
	
	protected function try($var){}
	
}
