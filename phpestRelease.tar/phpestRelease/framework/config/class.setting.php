<?php

/**
 * 设置项。技巧：
 * <ol>
 * <li>使用常量定义属性的类型和验证规则。</li>
 * <li>要设置属性值可以使用同名的方法设置以实现链式调用。例如：$setting->id('guid')->name('name')</li>
 * <li>配合使用非公共的属性，验证器和转化器来操作数据项。</li>
 * <li>函数式调用返回数组形式的数据。</li>
 * </ol>
 * @author Max Wang
 */
class Setting
{
	use TSetter, TGetter;
	
	/**
	 * 设置器规则：以属性名为键的一维数组，数组中包含验证器用于验证数据，
	 * 回调（数据将作为首个参数）用于转换和过滤数据。
	 * @var array
	 * @example ['property'=>[new Validator\Length(100), new Validator\Required]]
	 */
	protected $_;
	
	/**
	 * 返回数据。
	 * @param array|Setting $setting 可选，数据。
	 * @return self|array 注意：如果未提供数据则将当前设置的属性转为数组返回，否则使用数据进行设置并返回self
	 */
	public function __invoke($setting = null){}
}