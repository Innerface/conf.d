<?php

namespace Config\Host;

use Config\Loader;

/**
 * 基于域名的文件型配置数据加载器。
 * @author Max Wang
 * 
 */
class File extends Loader
{
	/**
	 * @param array $mappings 可选，域名映射。
	 * @param bool $wildcard 可选，域名映射是否使用 shell 通配符模式匹配。
	 * @param string $directory 可选，配置文件的目录。默认在 APP 下的 runtime/config/hosts 子目录。
	 */
	public function __construct(array $mappings = null, bool $wildcard = false, string $directory = null){}
	
	protected function match(string $host, array $mappings = null, bool $wildcard = false){}
	
	/**
	 * 返回当前的域名标识符。
	 * @return string 包含 https 及端口定义。
	 */
	protected function host(){}

	protected function load(){}
}