<?php

/**
 * 配置数据的层叠模式：不使用层叠，只使用找到的首个配置。
 * @var integer
 */
define('CASCADE_NONE', 0);
/**
 * 配置数据的层叠模式：层叠，先找到的配置优先，覆盖后续配置数据中的同名配置。
 * @var integer
 */
define('CASCADE_NORMAL', 1);
/**
 * 配置数据的层叠模式：倒序层叠，后找到的配置优先，覆盖已经找到的配置数据中的同名配置。
 * @var integer
 */
define('CASCADE_INVERT', 2);

/**
 * 构造器。
 * @param string $type 类名。
 * @param mixed ... $args 参数，传递给要构造的对象的构造器的参数，注意：如果参数不匹配对象的构造函数会引发异常。
 * @return Creator
 */
function creator(string $type, ... $args){}

/**
 * 加载配置。
 * @param string|array $guid 可选，全局唯一标识符或标识符组。如果不提供则返回配置管理器。
 * @param int $mode 可选，层叠模式。默认为 CASCADE_NORMAL，可用选项：CASCADE_NONE, CASCADE_NORMAL 和 CASCADE_INVERT。
 * @return IConfigProvider|array
 */
function config($guid = null, int $mode = CASCADE_NORMAL){}
