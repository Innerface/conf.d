<?php

namespace Config;

/**
 * 配置加载器。
 * @author Max Wang
 * 
 */
interface ILoader
{
	/**
	 * 获取指定 ID 的数据项。
	 * @param string $guid 标识符。
	 * @return mixed
	 */
	public function read(string $guid);
	/**
	 * 是否存在指定 ID 的数据项。
	 * @param string $guid 标识符。
	 * @return bool
	 */
	public function has(string $guid);
}