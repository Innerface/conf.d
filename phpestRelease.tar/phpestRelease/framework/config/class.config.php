<?php

use Config\Loader;

/**
 * 配置管理器。
 * @author Max
 */
class Config implements IConfigProvider
{
	/**
	 * 实际加载配置模式名。
	 * @var string
	 */
	protected $mode;
	/**
	 * 加载器。
	 * @var \Config\ILoader
	 */
	protected $loader;
	
	/**
	 * @param array $mode 可选，候选模式组名，默认依次加载找到的配置文件：dev 和 prod。
	 * @param string $directory 可选，配置文件的目录。默认在 APP 下的 runtime/config 子目录。
	 */
	public function __construct(array $mode = ['dev', 'prod'], string $directory = null){}
	
	public function read($namespace, int $mode = CASCADE_NORMAL){}
	
	public function mode(){}
	
	public function loader(){}
}