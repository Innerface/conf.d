<?php

namespace Config;

/**
 * 配置数据加载器。
 * @author Max Wang
 * 
 */
class Loader implements ILoader
{
	protected $data;
	protected $file;
	
	/**
	 * @param string $file 配置文件。
	 */
	public function __construct(string $file){}
	
	/**
	 * 获取指定 ID 的数据项。
	 * @param string $guid 标识符。
	 * @return mixed
	 */
	public function read(string $guid){}
	
	/**
	 * 是否存在指定 ID 的数据项。
	 * @param string $guid 标识符。
	 * @return bool
	 */
	public function has(string $guid){}
	
	protected function load(){}
}