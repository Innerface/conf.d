<?php

class ConfigException extends Exception
{
	
}