<?php

/**
 * 设置集。
 * @author Max Wang
 */
class Settings implements IteratorAggregate
{
	/**
	 * 元素。
	 * @var array
	 */
	protected $_;
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	public function __call(string $name, array $args = null){}
	
	public function __invoke(){}
	
	public function getIterator(){}
}