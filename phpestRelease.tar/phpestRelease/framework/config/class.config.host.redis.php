<?php

namespace Config\Host;

/**
 * 基于主机域名选择存储于 redis 的配置加载器。
 * @author Max Wang
 */
class Redis extends File
{
	/**
	 * 构造 Redis 加载器。
	 * @param \Redis $redis redis 客户端。
	 * @param array $mappings 可选，域名映射。
	 * @param bool $wildcard 可选，域名映射是否使用 shell 通配符模式匹配。
	 */
	public function __construct(\Redis $redis, array $mappings = null, bool $wildcard = false){}
}