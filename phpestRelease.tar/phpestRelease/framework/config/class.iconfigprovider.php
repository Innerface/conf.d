<?php

/**
 * 配置提供者。
 * @author Max
 * 
 */
interface IConfigProvider
{
	/**
	 * 读取配置。当提供多个名字空间时，层叠方式会加载所有名字空间的配置数据，
	 * @param string|array $namespace 名字空间。
	 * @param int $mode 可选，层叠模式。默认为 CASCADE_NORMAL，可用选项：CASCADE_NONE, CASCADE_NORMAL 和 CASCADE_INVERT。
	 * @return array 
	 */
	public function read($namespace, int $mode = CASCADE_NORMAL);
	/**
	 * 当前实际使用的配置加载器。
	 * @return \Config\Loader 如果不是由配置加载器加载的返回 null。
	 */
	public function loader();
	/**
	 * 实际加载的配置文件名：一般为 dev 或 prod。
	 * @return string
	 */
	public function mode();
}