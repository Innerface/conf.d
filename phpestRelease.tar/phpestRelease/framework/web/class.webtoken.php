<?php

namespace API;

/**
 * Web Token
 * @author Max Wang
 * 
 */
class WebToken
{
	public $iss;
	public $iat;
	public $nbf;
	public $exp;
	public $aud;
	public $sub;
	
	public $jti;
	
	public $typ;
	public $alg;
	
	protected $key;
	protected $host;
	protected $origin;
	
	protected $payload = [];
	
	public function __construct(string $key, string $host = null, string $origin = null){}
	
	public function __get(string $name){}
	public function __isset(string $name){}
	public function __set(string $name, $var){}
	public function __unset(string $name){}
	
	public function __toString(){}
	
	public function __invoke(string $token){}
	
	protected function encode(string $raw, string $key){}
	
	protected function decode(string $raw, string $key){}
}