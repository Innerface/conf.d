<?php

/**
 * 操作接口。
 * @author Max
 * 
 */
interface IAction
{
	/**
	 * 初始化操作。
	 * @param IController $controller 所属的控制器。
	 * @return IAction $this
	 */
	public function init(IController $controller);
	
	/**
	 * 运行。
	 * @return void
	 */
	public function run();
}