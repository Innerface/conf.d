<?php


/**
 * Web 应用基类。
 * @author Max
 * @property-write callable $onready 准备阶段事件，参数类型：EventArgs。
 * @property-write callable $onfinish 完成阶段事件，参数类型：EventArgs。
 * @property-write callable $onfly FAST CGI 后台事件，参数类型：EventArgs。
 * @property-write callable $onauthorize 授权事件，参数类型：AuthorizeEventArgs。
 */
abstract class web extends app
{
	/**
	 * 运行模式：维护中，普通用户无法使用，但授权人员可以使用。
	 * @var int
	 */
	const MAINTAINING = 8;
	/**
	 * 运行模式：离线停止，完全关闭，所有人都无法使用。
	 * @var int
	 */
	const OFFLINE = 9;
	
	const EVENT = [
		'authorize' => 'AuthorizeEventArgs',
		'ready'  => null,
		'finish' => null,
		'fly'    => null,
		'finally'=> null,
	];
	
	/**
	 * 接口支持的方法。
	 * @var array
	 */
	const METHODs = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'TRACE'];
	
	/**
	 * 定义自定义的请求头。
	 * @var array
	 */
	const REQUESTs = [
		'*'     => [
			'Authorization',
			'X-Requested-With',
			'X-Version',
		],
		'PUT'   => ['Content-Type'],
		'POST'  => ['Content-Type'],
		'PATCH' => ['Content-Type'],
	];
	
	/**
	 * 定义自定义的响应头。
	 * @var array
	 */
	const RESPONSEs = [
		'*' => [
			'X-Powered-By',
			'X-Request-Id',
			'X-XSS-Protection',
			'X-Version',
		],
	];
	
	/**
	 * 默认的 HTTP 响应状态码及消息定义。
	 * @var array
	 */
	const STATUS = [
		200 => 'OK',
		400 => 'Bad Request',
		401 => 'Unauthorized',
		402 => 'Request Failed',
		403 => 'Forbidden',
		404 => 'Not Found',
		405 => "Method Not Allowed",
		406 => "Not Acceptable",
		407 => "Proxy Authentication Required",
		408 => "Request Time-out",
		409 => "Conflict",
		410 => "Gone",
		411 => "Length Required",
		412 => "Precondition Failed",
		413 => "Request Entity Too Large",
		414 => "Request-URI Too Large",
		415 => "Unsupported Media Type",
		416 => "Requested range not satisfiable",
		417 => "Expectation Failed",
		420 => 'Version Undefined',
		500 => "Internal Server Error",
		501 => "Not Implemented",
		502 => "Bad Gateway",
		503 => "Service Unavailable",
		504 => "Gateway Time-out",
		505 => "HTTP Version not supported",
		510 => 'Version Error',
		554 => 'Under Maintenance',
		555 => 'Server Offline',
	];
	
	/**
	 * 请求来源定义：默认仅支持同源，可以定义为 * 表示任意请求来源，或者用数组形式列出允许的来源域。
	 * @var string|array
	 */
	public $origin;
	/**
	 * 启用无 COOKIE 环境。
	 * @var bool
	 */
	public $cookieless = true;
	public $cache;
	
	/**
	 * 上下文环境。
	 * @var Context
	 */
	protected $context;
	protected $default;
	protected $notFound;
	protected $accessDenied;
	protected $error;
	
	public function sapi($sapi) : bool{}
	
	/**
	 * Web 应用的 GUID 增加域名（含端口）。
	 * @see app::guid()
	 */
	public function guid(){}
	
	/**
	 * 获取当前的请求 ID。
	 * @return string 如果不支持则返回 null。
	 */
	public function requestId(){}
	
	/**
	 * 设置默认的入口。
	 * @param string|callable $entry 入口。
	 * @return self
	 */
	public function default($entry){}
	
	/**
	 * 设置禁止访问的入口。
	 * @param string|callable $entry 入口。
	 * @return self
	 */
	public function accessDenied($entry){}
	
	/**
	 * 设置错误处理入口。
	 * @param string|callable $entry 入口。回调签名：void function(array|Throwable $error = null) 参数 $error 为错误。
	 * @return self
	 */
	public function error($entry){}
	
	/**
	 * 获取当前上下文内容。
	 * @return Context
	 */
	public function context(){}
	
	/**
	 * 响应 400 错误。
	 * @param string $body 可选，输出的内容。
	 * @param string $contentType 可选，内容类型。
	 * @param string $charset 可选，字符集。
	 * @return void
	 */
	public function X400(string $body = null, string $contentType = null, string $charset = null){}
	
	/**
	 * 响应 401 错误。
	 * @return void
	 */
	public function X401(){}
	
	/**
	 * 响应 403 错误。
	 * @return void
	 */
	public function X403(){}
	
	/**
	 * 响应 404 错误。
	 * @return void
	 */
	public function X404(){}
	
	/**
	 * 响应 405 错误。
	 * @return void
	 */
	public function X405(){}
	
	/**
	 * 响应 420 错误。
	 * @return void
	 */
	public function X420(){}
	
	/**
	 * 响应 500 错误。
	 * @param string $msg 可选，要输出的消息。
	 * @param string $contentType 可选，输出内容的类型，默认为纯文本。
	 * @param string $charset 输出内容的字符集，默认为 utf-8。
	 * @return void
	 */
	public function X500(string $msg = null, string $contentType = 'text/plain', string $charset = 'utf-8'){}
	
	/**
	 * 响应 510 错误。
	 * @return void
	 */
	public function X510(){}
	
	/**
	 * 响应 554。
	 * @return void
	 */
	public function X554(){}
	
	/**
	 * 响应 555。
	 * @return void
	 */
	public function X555(){}

	/**
	 * 获取当前接口支持的所有方法。
	 * @return string[]
	 */
	public function methods(){}
	
	protected function run(){}
	
	/**
	 * 始终。注意：仅用于特殊用途。
	 * @return void
	 */
	protected final function finally(){}
	
	/**
	 * CORS 时判断来源和主机。
	 * @param string $method 请求的方法。
	 * @param string $origin 发起请求的来源链接。
	 * @return boolean|string 允许访问时返回允许的源链接或 *，否则返回 falase。
	 */
	protected function origin(string $method, string $origin = null){}
	
	/**
	 * 响应 HTTP 预请求。
	 * @return void
	 */
	protected function preflight(){}
	
	/**
	 * 预处理。
	 * @return void
	 */
	protected function ready(){}
	
	/**
	 * 身份识别，处理用户信息。
	 * @return void
	 */
	protected function identify(){}
	
	/**
	 * 鉴权，访问控制。
	 * @return void
	 */
	protected function authorize(){}
	
	/**
	 * 路径信息处理。
	 * @return array 路径信息。
	 */
	protected abstract function pathpass();
	
	/**
	 * 路由。
	 * @return void
	 */
	protected abstract function route();
	
	/**
	 * 请求分发。
	 * @return void
	 */
	protected abstract function dispatch();
	
	/**
	 * 完成请求。
	 * @return void
	 */
	protected function finish(){}
	
	/**
	 * FAST CGI 模式下终止用户请求后会继续执行。只在应用环境支持时才会被调用。并且任何输出都被清空。
	 * @return void
	 */
	protected final function fly(){}
	
	protected function initialize(){}
	
	/**
	 * 获取原始的路径信息。
	 * @return string
	 */
	public static function pathinfo(){}
	
	/**
	 * 获取请求的 URI。
	 * @param bool $withQueryString 可选，是否包含查询字符串，默认为 false。
	 * @return string
	 */
	public static function requestedUri(bool $withQueryString = false) : string{}
	
	/**
	 * 获取请求的根链接。
	 * @return string
	 */
	public static function rootUrl(): string{}
	
	/**
	 * 获取请求的主机头。
	 * @param bool $port 可选，是否包含端口，默认为 false，如果是默认端口将始终不包含。
	 * @return string
	 */
	public static function host(bool $port=false): string{}
	
	/**
	 * 请求的端口。
	 * @return int 默认端口则返回 null。
	 */
	public static function port(){}
	
	/**
	 * 当前请求的基链接。
	 * @return string
	 */
	public static function baseUri() : string{}
	
	/**
	 * 是否为 https 请求。
	 * @return boolean
	 */
	public static function https() : bool{}
	
	/**
	 * 获取客户端 IP 地址（IPv4 或 IPv6），格式已验证。
	 * @param bool 是否仅返回首个 IP（当通过代理转发时可能是一组 IP 地址）。
	 * @return string|array 可能是一组 IP，除非指定仅返回第一个。如果IP地址有问题返回 null。
	 */
	public static function ip(bool $first=true){}	
	
	/**
	 * 向浏览器发送基本验证对话框并中止进程。
	 * @param string $realm 可选，验证对话框的提示内容，注意：仅支持 US-ASCII 文本，其它文本会显示乱码。
	 * @param string $unauthorized 可选，用户点击取消按钮后输出到页面的文本内容。
	 * @throws RuntimeException $realm 包含无效字符。
	 * @return void
	 */
	public static function sendBasicAuth(string $realm = null,  $unauthorized = null){}
	
	/**
	 * 获取基本验证信息。
	 * @return array 返回数值索引的数组，包含两个元素：首个为 user，第二个为 password。如果未提交基本验证信息则返回 null。
	 */
	public static function getBasicAuth(){}
	
	/**
	 * 向浏览器发送 Digest 摘要验证并中止进程。
	 * @param string $realm 验证提示短语，注意：仅支持 US-ASCII 文本，其它文本会显示乱码。
	 * @param string $unauthorized 可选，用户点击取消按钮后输出到页面的文本内容。
	 * @throws RuntimeException $realm 包含无效字符。
	 * @return void
	 */
	public static function sendDigestAuth(string $realm,  $unauthorized = null){}
	
	/**
	 * 获取摘要验证信息。
	 * @return array 未正确提交返回 null。
	 */
	public static function getDigestAuth(){}
	
	/**
	 * 计算摘要验证的身份摘要。
	 * @param string $username 用户名。
	 * @param string $realm 验证提示短语，注意：仅支持 US-ASCII 文本，其它文本会显示乱码。
	 * @param string $password 密码。
	 * @return string
	 */
	public static function digestHash(string $username, string $realm, string $password){}
	
	/**
	 * 摘要认证验证。
	 * @param string $A1 身份验证的摘要：=md5("$username:$realm:$password")
	 * @return bool 验证通过返回 true。未提交验证信息或未通过验证返回 false。
	 */
	public static function digestAuth(string $A1){}
	
	/**
	 * 发送指定的文件内容到浏览器/客户端，支持大文件断点续传。
	 * @param string $file 文件。
	 * @param string $mime MIME 类型。
	 * @param string $rename 新的文件名，注意：仅文件名，不要包含路径。默认使用原文件名。
	 * @param boolean|integer $breakpoint 可选，是否使用断点续传，默认不使用，一般仅在文件较大时使用。可以使用正整数表示使用断点的文件尺寸，即大于此值使用断点。
	 * @return boolean 是否成功发送。
	 */
	public static function sendfile($file, $mime='application/octet-stream', $rename = null, $breakpoint = false){}
	
	/**
	 * 发送重定向头。
	 * @param string $url 可选，重定向的链接，省略则重定向到当前的请求。
	 * @param int $code 可选，HTTP 响应 300 段的代码。默认为 302。
	 * @param string $description 可选，一句话的重定向消息。
	 * @return bool 成功发送重定向头消息。
	 */
	public static function location($url = null, $code = 302, $description = null){}
	
	/**
	 * 浏览器端基本信息。
	 * @return stdClass 属性：ip, method, request, useragent, lang, accept
	 */
	public static function browser(){}
	
	/**
	 * 获取原始的 POST 数据。
	 * @return string
	 */
	public static function httpRawPostData(){}
	
	/**
	 * 请求方法。
	 * @return string 返回请求的 HTTP 方法，如 GET, POST 或其它 HTTP 请求方法名。
	 */
	public static function httpRequestMethod(){}
	
	/**
	 * XSS 保护选项。
	 * @param string $options 选项，默认为："1; mode=block"，表示启用保护。
	 * @return void
	 */
	public function xssProtection(string $options = '1; mode=block'){}

	/**
	 * 内容安全策略。
	 * @param string $policy 安全策略。
	 * @return void
	 */
	public static function contentSecurityPolicy($policy = "default-src 'none'"){}
	
	/**
	 * 限制在浏览器的 frame 内调用，选项：deny。
	 * @param string $options 选项，默认为：deny。
	 * @return void
	 */
	public static function frameOptions(string $options = 'deny'){}
	
	/**
	 * 内容类型嗅探的选项，设置为 nosniff 则禁止嗅探。
	 * @param string $options 选项，默认为：nosniff。
	 * @return void
	 */
	public static function contentTypeOptions(string $options = 'nosniff'){}
	
	/**
	 * 接口版本。
	 * @param string $version 版本号。
	 * @return void
	 */
	public static function xVersion(string $version){}
	
	/**
	 * HTTP 访问控制。
	 * @param string $allowOrigin 允许的来源。
	 * @param string $allowMethods 允许的方法。
	 * @param string $allowHeaders 允许的头。
	 * @param int $maxAge 授权生命期。
	 * @return void
	 */
	public static function httpAccessControl(string $allowOrigin, string $allowMethods, string $allowHeaders, int $maxAge = null){}
	
	/**
	 * 访问控制允许的来源。
	 * @param string $origin 来源（域名），可用：* 表示任意来源或者指定允许的域名。
	 * @return void
	 */
	public static function accessControlAllowOrigin(string $origin){}
	
	/**
	 * 访问控制允许的请求方法。
	 * @param string $methods 方法列表，以逗号分隔多个方法。
	 * @return void
	 */
	public static function accessControlAllowMethods(string $methods){}
	
	/**
	 * 访问控制允许的请求头。
	 * @param string|array $headers 头，字符串或数组，以逗号分隔。
	 * @return void
	 */
	public static function accessControlAllowHeaders($headers){}
	
	/**
	 * 访问控制预请求的有效期。。
	 * @param int $age 有效期，单位：秒。
	 * @return void
	 */
	public static function accessControlMaxAge(int $age){}
	
	/**
	 * 告知客户端,当请求的credientials属性是true的时候,响应是否可以被得到.
	 * 当它作为预请求的响应的一部分时,它用来告知实际的请求是否使用了credentials.
	 * 注意,简单的GET请求不会预检,所以如果一个请求是为了得到一个带有credentials的资源,
	 * 而响应里又没有Access-Control-Allow-Credentials头信息,那么说明这个响应被忽略了.
	 * @param bool $allow 是否允许。
	 * @return void
	 */
	public static function accessControlAllowCredentials(bool $allow){}
	
	/**
	 * 访问控制：服务器响应头中暴露的自定义头。
	 * @param string|array $headers 头，字符串或数组，逗号分隔。
	 * @return void
	 */
	public static function accessControlExposeHeaders($headers){}
	
	/**
	 * 访问频率限制。
	 * @param int $limit 调用频率限制：单位时间(一秒)内的次数。默认不限制。
	 * @param int $remaining 可选，调用频率限制：剩余次数。
	 * @param int $reset 可选，调用频率限制：重置限制的时间戳(UTC 时间)。
	 * @return void
	 */
	public static function rateLimit(int $limit = 0, int $remaining = -1, int $reset = 0){}
	
	/**
	 * 请求的编号。
	 * @param string $id 发送当前请求的编号。
	 * @return void
	 */
	public static function xRequestId(string $id){}
	
	/**
	 * 接口程序名。
	 * @param string $name 名字。
	 * @return void
	 */
	public static function poweredBy(string $name){}
	
	/**
	 * 设置内容类型。
	 * @param string $mime 输出的内容类型。
	 * @param string $charset 可选，默认不设置。
	 * @return void
	 */
	public static function contentType(string $mime, string $charset = null){}
	
	/**
	 * 根据设置发送头信息。
	 * @param int $status 状态码。
	 * @param string $reason 可选，原因短语。
	 * @param string $version 可选，HTTP 版本。
	 * return void
	 */
	public static function http(int $status, string $reason, string $version = null){}
	
	/**
	 * 禁止浏览器缓存。
	 * @return void
	 */
	public static function disableCache(){}
	
	/**
	 * 获取请求的区域代码。
	 * @param bool $first 可选，是否返回最优先的。
	 * @param array $filters 可选，筛选列表，不在此列表中的区域代码无效，区分大小写。
	 * @return string|string[]|null 如果返回的是列表，则按优先级排列，最前面的最优先。
	 */
	public static function acceptLanguage(bool $first = false, array $filters = null){}
	
	/**
	 * 获取请求的内容类型代码。
	 * @param bool $first 可选，是否返回最优先的。
	 * @param array $filters 可选，筛选列表，不在此列表中的内容类型无效，区分大小写。
	 * @return string|string[]|null 如果返回的是列表，则按优先级排列，最前面的最优先。
	 */
	public static function accept(bool $first = false, array $filters = null){}
}