<?php

/**
 * 用户。
 * @author Max
 */
abstract class User extends UserBase
{
	public function locale(){}
}