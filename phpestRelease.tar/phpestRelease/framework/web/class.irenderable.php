<?php

/**
 * 可呈现内容接口。
 * @author Max
 * 
 */
interface IRenderable extends ArrayAccess
{
	/**
	 * 呈现。
	 * @return IRenderable $this
	 */
	public function render();
	/**
	 * 绑定数据宿主。
	 * @param object|array $host
	 */
	public function bind($host);
}