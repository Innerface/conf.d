<?php

if (!function_exists('getallheaders'))
{
	function getallheaders(){}
}
