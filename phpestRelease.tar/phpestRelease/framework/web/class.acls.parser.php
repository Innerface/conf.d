<?php


namespace ACLs;

use ACLs;

/**
 * 访问控制列表解析器。
 * @author Max
 * 
 */
class Parser
{
	const TRUE = ['allow', 'true', 'on', 'yes', 'enabled', 'active'];
	
	/**
	 * 错误。
	 * @var array
	 */
	public $error;
	
	/**
	 * 解析。
	 * @param string $text 源文本。
	 * @return array 返回解析后的访问控制列表（元素为数组，键为行号），
	 * 元素为 null 的为注释或指令占位行。
	 */
	public function parse($text){}
	
	/**
	 * 未命名段解析。
	 * @param array $data 引用，段数据。
	 * @param bool $follow 条目跟随状态。
	 * @param string $line 当前行文本内容。
	 * @param int $first 首字符代码点。
	 * @return void
	 */
	protected function options(array & $data, & $follow, $line, $first){}
	
	/**
	 * IP 段解析。
	 * @param array $data 引用，段数据。
	 * @param bool $follow 条目跟随状态。
	 * @param string $line 当前行文本内容。
	 * @param int $first 首字符代码点。
	 * @return void
	 */
	protected function ip_section(array & $data, & $follow, $line, $first){}
	
	/**
	 * 普通段解析。
	 * @param array $data 引用，段数据。
	 * @param bool $follow 条目跟随状态。
	 * @param string $line 当前行文本内容。
	 * @param int $first 首字符代码点。
	 * @return void
	 */
	protected function section(array & $data, & $follow, $line, $first){}
	
	/**
	 * 入口段解析。
	 * @param array $data 引用，段数据。
	 * @param bool $follow 条目跟随状态。
	 * @param string $line 当前行文本内容。
	 * @param int $first 首字符代码点。
	 * @return void
	 */
	protected function entries_section(array & $data, & $follow, $line, $first){}
	
	/**
	 * 解析列表。
	 * @param string $var 值。
	 * @return array
	 */
	protected function parse_list($var = null){}
	
	/**
	 * 解析标识符列表。
	 * @param string $var 值。
	 * @return array 返回支持（元素 0）和禁止的标识符列表（元素 1）
	 */
	protected function parse_ids($var = null){}
	
	/**
	 * 解析入口段的选项值。
	 * @param string $name 选项名。
	 * @param string $var 选项值。
	 * @return mixed
	 */
	protected function parse_value($name, $var){}
}
