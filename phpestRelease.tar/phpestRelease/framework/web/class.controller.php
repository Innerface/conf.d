<?php

/**
 * Web 应用的控制器基类。
 * 控制器提供操作（ACTION）供应用调用。通常，操作分两类。
 * <ol>
 * <li>内联操作（Inline Action）：控制器所有的公开方法默认为有效的内联操作，路由捕捉到的索引型参数将作为其参数在调用时依序传入。</li>
 * <li>独立操作（Standalone Action）：由独立定义的操作类（实现 IAction 接口的类）实现，路由捕捉到的索引型参数将作为其参数在调用时依序传入。</li>
 * <li><strong>特别的</strong>：名字以下划线开始的任何公共方法不被视为操作。</li>
 * <li>可以使用 __map 方法将某个操作映射为另一个。</li>
 * <li>可以使用 __support 方法检测是否支持一个指定的操作。</li>
 * <li>独立操作的规则：
 * <ol type="A">
 * <li>操作(Action)类不可独立使用，附加于控制器调用。</li>
 * <li>文件位置：{app}/controllers/{controller name}/action.{action name}.php</li>
 * <li>操作的类名以控制器的类名作为根名字空间，<strong>特别的</strong> 如果使用不同的名字空间，要在定义文件中返回（return）它。</li>
 * <li>例如：
 * <ol type="a">
 * <li>控制器名为 ctrl</li>
 * <li>操作名为 actionname</li>
 * <li>则操作的文件路径为（相对于控制器目录）controllers/{ctrl}/action.{actionname}.php</li>
 * <li>则操作的类名为 \app\demo\ctrl\action。</li>
 * </ol>
 * </li>
 * <li>操作的构造器的形参：首个参数为当前控制器，其它参数依次为路由参数。形式为：__construct(IController $controller, $arg1, $arg2, $_)</li>
 * <li>由控制器的 __load 方法负责加载。</li>
 * </ol>
 * </li>
 * </ol>
 * @author Max
 */
abstract class Controller implements IController
{
	public function __call($name=null, array $args = null){}
	
	public function __map(string $name){}
	
	public function __support(string $name){}
	
	/**
	 * action 目录。
	 * @return string
	 */
	protected function __directory(){}
	
	/**
	 * 加载 action。
	 * @param string $action 操作名。
	 * @return IAction|callable 回调或 IAction 实例。
	 */
	protected function _($action){}
}