<?php

/**
 * Web 应用插件。
 * @author Max
 * 
 */
interface IWebPlugIns extends IPlugIn
{
	public function begin();
	public function load();
	public function setup();
	public function dispatch();
	public function invode();
	public function unload();
	public function error();
	public function done();
	public function end();
	
	/**
	 * FastCGI 模式下在用户请求完成后当前进程的其它后续操作，注意：仅在 PHP 作为 FastCGI 网关时被执行。
	 * @return void
	 */
	public function fastcgi_finish_request();
}