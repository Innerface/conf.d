<?php

namespace HTTP;

/**
 * 访问控制。
 * @author Max Wang
 * 
 */
class AccessControl
{
	public $maxAge;
	public $allowHeaders;
	public $allowMethods;
	public $allowCredentials;
	public $exposeHeaders;
	
	protected $api;
	protected $setting;
	
	public function __construct(\API $api, $setting){}
	
	public function run(string $method, string $pathinfo){}
}
