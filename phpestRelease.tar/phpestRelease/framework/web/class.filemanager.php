<?php

/**
 * 文件管理器。
 * @author Max
 */
class FileManager
{
	/**
	 * 所有支持的方法。
	 * @var string
	 */
	const ACTIONS = 'grant,revoke,ll,url,rename,mv,info,rm,mkdir,chown,chmod,put,get';
	
	/**
	 * 基目录表。
	 * @var array
	 */
	public $directories;
	/**
	 * 访问控制列表。
	 * @var array
	 */
	public $acls;
	/**
	 * 目录到链接的映射。
	 * @var string
	 */
	public $mappings;
	
	/**
	 * 下载：是否支持断点续传。
	 * @var boolean
	 */
	public $breakpoint;
	/**
	 * 最后的错误信息。
	 * @var array
	 */
	public $error;
	
	/**
	 * 授权。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param string $action 操作名。
	 * @param string|User $user 可选，用户或通配符。
	 * @param mixed $extra 可选，额外的参数。比如上传的时候需要指定检查上传文件安全。
	 * @return bool 授权通过返回 true
	 */
	public function authorize($dir, $path, $action, $user = null, $extra = null){}
	
	protected function upload_verify($dir, $path, $name, $user){}
	
	public function path($dir, $path){}
	
	public function grant($dir, $path, $acls, $user = nul){}
	
	public function revoke($dir, $path, $acls, $user = nul){}
	
	/**
	 * 列出目录。
	 * @param string $dir 基目录名。
	 * @param string $path 可选，相对路径。
	 * @param string $filters 可选，筛选器。
	 * @return array
	 */
	public function ll($dir, $path = null, $filters = null){}
	
	/**
	 * 将文件映射为公共链接。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @return string 无效返回 false。
	 */
	public function url($dir, $path = null){}
	
	/**
	 * 重命名目录或文件。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param string $newname 新名称。
	 * @return bool
	 */
	public function rename($dir, $path, $newname){}
	
	/**
	 * 移动目录或文件。
	 * @param string $dir 基目录名。
	 * @param string $oldpath 相对路径。
	 * @param string $newpath 相对路径。
	 * @return bool
	 */
	public function mv($dir, $oldpath, $newpath){}
	
	/**
	 * 文件或目录信息。
	 * @param 基目录名 $dir
	 * @param string $path 相对路径。
	 * @return array 文件或目录信息，包括当前用户所拥有的权限。
	 */
	public function info($dir, $path){}
	
	/**
	 * 删除目录或文件。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param bool $force 可选，是否强制。
	 * @param bool $recursive 可选，是否递归。
	 * @return bool
	 */
	public function rm($dir, $path, $force=false, $recursive = false){}
	
	/**
	 * 删除文件或目录。
	 * @param string $path 目录或文件。
	 * @param bool $force 是否强制删除。
	 * @param bool $recursive 是否递归。
	 * @return bool
	 */
	protected function remove($path, $force = false, $recursive = false){}
	
	/**
	 * 创建子目录。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param unsigned $mode 可选，目录访问权限配置。默认为 0777。
	 * @param bool $force 可选，是否强制。
	 * @param bool $recursive 可选，是否递归。
	 * @return bool
	 */
	public function mkdir($dir, $path, $mode = 0777, $force=false, $recursive = false){}
	
	/**
	 * 改变目录或文件的所有者。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param string|int $own 新的所有者。
	 * @return bool
	 */
	public function chown($dir, $path, $own){}
	
	/**
	 * 改变目录或文件的访问权限。
	 * @param string $dir 基目录名。
	 * @param string $path 相对路径。
	 * @param unsigned $mode 权限模式，仅支持整数值，不支持字符串设置，例如 0777。
	 * @return bool
	 */
	public function chmod($dir, $path, $mode){}
	
	/**
	 * 保存文件到目录下。
	 * @param string $dir 基目录名。
	 * @param string $name 上传文件键名。
	 * @param string $path 文件要存储到的相对位置的路径名，包含文件名。
	 * @return boolean
	 */
	public function put($dir, $name, $path){}
	
	/**
	 * 发送文件到客户端。
	 * @param string $dir 基目录名。
	 * @param string $path 文件。
	 * @param string $mime MIME 类型定义。
	 * @param string $rename 重命名，仅文件名，不要包含路径。
	 * @param bool $breakpoint 可选，是否使用断点续传，默认不使用，一般仅在文件较大时使用。
	 * @return bool
	 */
	public function get($dir, $path, $mime = 'application/octet-stream', $rename = null, $breakpoint = false){}
}