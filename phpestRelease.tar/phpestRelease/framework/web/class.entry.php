<?php

/**
 * Web 应用入口。
 * @author Max
 *
 */
class Entry
{
	/**
	 * 索引。
	 * @var string
	 */
	public $index;
	/**
	 * 指向的操作。
	 * @var string
	 */
	public $action;
	/**
	 * 类型。
	 * @var string
	 */
	public $type;
	/**
	 * 版本。
	 * @var int
	 */
	public $version;
	/**
	 * 全局唯一标识符。
	 * @var string
	 */
	public $guid;
	/**
	 * 附加的参数段。
	 * @var array
	 */
	public $args;
	/**
	 * 路由宏变量表。
	 * @var array
	 */
	public $vars;
}