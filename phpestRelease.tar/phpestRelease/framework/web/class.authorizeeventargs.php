<?php

/**
 * 授权审核事件参数。
 * @author Max
 * 
 */
class AuthorizeEventArgs extends BreakEventArgs
{
	/**
	 * 用户。
	 * @var IUser
	 */
	public $user;
	/**
	 * 请求的入口。
	 * @var string
	 */
	public $entry;
	/**
	 * 审核结果。
	 * @var bool
	 */
	public $authorized;
	
	/**
	 * 构造事件参数。
	 * @param string $entry 可选，操作。
	 * @param IUser $user 可选，用户。
	 * @param bool $authorized 可选，默认的审核结果。
	 */
	public function __construct(string $entry = null, IUser $user = null, bool $authorized = true){}
}