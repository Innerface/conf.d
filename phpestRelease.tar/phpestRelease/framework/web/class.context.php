<?php


/**
 * 上下文环境。
 * @author Max
 * 
 */
class Context
{
	/**
	 * 访问令牌。
	 * @var string
	 */
	public $token;
	
	/**
	 * 授权审核，授权审核事件前的值作为默认值。
	 * @var bool
	 */
	public $authorized = true;
	
	/**
	 * 会话标识号。
	 * @var string
	 */
	public $session;
	
	/**
	 * 请求的入口。
	 * @var \Entry
	 */
	public $entry;
	
	/**
	 * 附加的错误信息。
	 * @var string|array|Throwable
	 */
	public $error;
	
	/**
	 * 原始请求路径信息。
	 * @var string
	 */
	public $raw;
	/**
	 * 路径信息。
	 * @var string
	 */
	public $pathinfo;
	/**
	 * 请求的方法。
	 * @var string
	 */
	public $method;
	/**
	 * 强制的 HTTP 状态码。
	 * @var int
	 */
	public $status;
	/**
	 * 请求的版本。
	 * @var int
	 */
	public $version;
	
	protected $web;
	
	public function __construct(web $web){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
}

