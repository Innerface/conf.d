<?php

/**
 * 路径信息。
 * @author Max
 * @property-read string $extension 只读，扩展名。
 * @property-write callable $extension 只写，扩展名处理器。
 */
class PathInfo
{
	/**
	 * 路径信息。
	 * @var string
	 */
	public $pathinfo;
	
	public function __construct(string $pathinfo){}
	
	public function __get(string $name){}
	public function __set(string $name, $var){}
	public function __unset(string $name){}
	public function __isset(string $name){}
	
	/**
	 * 映射路径信息。
	 * @param array $mappings 固定的路径映射处理，在路由转换前的处理。由正则模式和回调组成。模式如下：
	 * [
	 * '/正则表达式/',
	 * '/正则表达式/' => function (array $matches, array & $mappings){return '替换内容';},
	 * function ($pathinfo){return '新的 pathinfo';},
	 * ]
	 * <ol>
	 * <li>模式一：元素值为正则表达式则直接测试路径信息，正则表达式匹配结果中的命名组的数据被提取出来，源文本被移除</li>
	 * <li>模式二：键为正则表达式， 值为回调，则将匹配结果和映射表的引用传给回调，用回调的返回值替换源文本</li>
	 * <li>模式三：键不是正则表达式，值为回调，则直接处理路径信息</li>
	 * </ol>
	 * @var array
	 * @example $router->mappings = [
	 * '{^(?<locale>(zh|en)(\-\w+)*)/}',
	 * '{^((zh|en)(\-\w+)*)/}' => function (array $matches, array & $mappings){$mappings['locale']=$matches[1];},
	 * function (string $pathinfo){}];
	 * @return array
	 */
	public function map(array $mappings){}
	
	/**
	 * 原路径信息。
	 * @return string
	 */
	public function raw(){}
	
	public function __toString(){}
}

