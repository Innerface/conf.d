<?php

/**
 * 安全保护检查接口。
 * @author Max
 * 
 */
interface IGuard extends IComponent
{
	const PATHINFO = 1;
	const HTTP_METHOD = 2;
	const QUERY_STRING = 3;
	const IP = 4;
	const HEADER = 5;
	const COOKIE = 6;
	const FILE = 7;
	
	/**
	 * 验证。
	 * @param mixed $var 要验证的内容。
	 * @param int $type 类型，参考 IGuard 接口常量定义，或者接口支持的任意类型。
	 * @return bool
	 */
	public function validate($var, int $type);
	/**
	 * 规范化。
	 * @param mixed $var 要规范的内容。
	 * @param int $type 类型，参考 IGuard 接口常量定义，或者接口支持的任意类型。
	 * @return mixed
	 */
	public function normalize($var, int $type);
}