<?php

/**
 * 上传文件管理器。
 * @author Max Wang
 * 
 */
class Uploads extends obj
{
	
}