<?php

/**
 * 验证管理器。
 * @author Max Wang
 * 
 */
class AuthManager implements IAuthManager
{
	/**
	 * 当前 WEB 应用。
	 * @var web
	 */
	protected $web;
	
	public function __construct(web $web){}
	public function authenticate($token = null){}
	public function authorize(string $entry, $token = null){}
	public function token(){}
	public function user($token = null){}
	public function timeout($token = null){}
	public function refresh($token = null){}
	
	public function revoke($token = null){}
	
	public function grant($token, string $entry, int $timeout){}
}