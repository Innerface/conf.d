<?php

/**
 * 资源处理器。
 * @author Max
 * 
 */
abstract class ResourceHandler extends Controller
{
	public function __invoke($action, array $args = null){}
}