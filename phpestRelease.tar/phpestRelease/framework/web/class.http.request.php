<?php

/**
 * HTTP 请求信息的快照。
 * @author Max
 * @property bool $https 只读，是否为 HTTPS 安全连接。
 * @property string $domain 只读，请求的域名。不含端口。
 * @property string $host 只读，请求的主机名和端口。
 * @property int $port 只读，端口，默认端口为 null。
 * @property string $uri 只读，原始的请求。
 * @property string $method 只读，HTTP 请求方法名，大写。
 * @property string $user 只读，基本验证时提交的用户名。
 * @property string $password 只读，基本验证时提交的口令。
 * @property string $pathinfo 只读，路径信息。
 * @property array $headers 只读，HTTP 请求头信息。
 * @property string $query 只读，查询字符串。
 */
class Request
{
	/**
	 * 是否为安全连接。
	 * @var bool
	 */
	protected $https;
	/**
	 * 请求的域名。
	 * @var string
	 */
	protected $domain;
	/**
	 * 请求的主机名和端口。
	 * @var string
	 */
	protected $host;
	/**
	 * 端口，默认端口为 null。
	 * @var int
	 */
	protected $port;
	/**
	 * 原始的请求。
	 * @var string
	 */
	protected $uri;
	/**
	 * HTTP 请求方法名，大写。
	 * @var string
	 */
	protected $method;
	/**
	 * 基本验证时提交的用户名。
	 * @var string
	 */
	protected $user;
	/**
	 * 基本验证时提交的口令。
	 * @var string
	 */
	protected $password;
	/**
	 * 路径信息。
	 * @var string
	 */
	protected $pathinfo;
	/**
	 * HTTP 请求头信息。
	 * @var array
	 */
	protected $headers;
	
	public function __get($name){}
	
	public function __isset($name){}
	
	/**
	 * 获取指定的 HTTP 头信息。
	 * @param string $name 名称。
	 * @param string $fallback 可选，备选值。
	 * @return string
	 */
	public function header($name, $fallback = null){}
	
	/**
	 * 当前请求是否被标记为 XMLHttpRequest。
	 * @return bool
	 */
	public function isXMLHttpRequest(){}
	
	/**
	 * 获取 GET 数据。
	 * @param string $name GET 数据项名。
	 * @param string $fallback 可选，备用值。
	 * @return string
	 */
	public function GET($name, $fallback = null){}
	
	/**
	 * 获取 POST 数据。特别的，无参数调用返回原始的 POST 数据。
	 * @param string $name POST 数据项名。
	 * @param string $fallback 可选，备选值。
	 * @return string
	 */
	public function POST($name = null, $fallback = null){}
	
	/**
	 * 获取指定的上传文件。
	 * @param string $name 文件请求域。
	 * @return array
	 */
	public function FILE($name){}
	
	/**
	 * 获取 COOKIE 数据。
	 * @param string $name 键名。
	 * @param string $fallback 可选，备用值，当键不存在或为 null 时的备用值。
	 * @return string
	 */
	public function COOKIE($name, $fallback = null){}
	
	/**
	 * 路径信息。路径前的 / 被移除。
	 * @return string
	 */
	public function pathinfo(){}
	
	public function locale(){}
}