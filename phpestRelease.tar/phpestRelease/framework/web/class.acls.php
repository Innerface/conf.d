<?php

/**
 * 访问控制列表。
 * @author Max
 * 
 */
class ACLs
{
	const NORMAL = 0;
	const PREFIX = 1;
	const PATTERN = 2;
	const DETECT = 3;
	
	/**
	 * 访问控制列表。
	 * @var array
	 */
	public $items;
	/**
	 * 默认规则。
	 * @var array
	 */
	public $default;
	/**
	 * 访客角色名。
	 * @var string
	 */
	public $guest = 'guest';
	
	protected $cache;
	
	/**
	 * 授权。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。未指定用户则默认为访问（guest）。
	 * @return bool 允许访问返回 true，拒绝访问返回 false。
	 */
	public function authorize(string $entry, IUser $user = null){}
	
	/**
	 * 测试用户的特定访问列表。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return int 返回 0 表示不匹配入口，1 表示匹配成功且允许访问，-1 表示匹配成功且禁止访问。
	 */
	protected function user(string $entry = null, IUser $user = null){}
	
	/**
	 * 根据入口的特定设置测试用户的访问资格。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return int 返回 0 表示不匹配入口，1 表示匹配成功且允许访问，-1 表示匹配成功且禁止访问。
	 */
	protected function entries(string $entry = null, IUser $user = null){}
	
	/**
	 * 测试用户的角色、组或标签的访问列表。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return int 返回 0 表示不匹配入口，1 表示匹配成功且允许访问，-1 表示匹配成功且禁止访问。
	 */
	protected function role(string $entry, IUser $user = null){}
	
	/**
	 * 测试用户等级的访问列表。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return int 返回 0 表示不匹配入口，1 表示匹配成功且允许访问，-1 表示匹配成功且禁止访问。
	 */
	protected function ranking(string $entry, IUser $user = null){}
	
	/**
	 * 测试。
	 * @param array $acls 访问控制列表。$acls 的键为模式字符串，值为 stdClass 对象，包含 type 或/和 deny 属性。
	 * @param string $entry 入口。
	 * @return int 返回 0 表示不匹配入口，1 表示匹配成功且允许访问，-1 表示匹配成功且禁止访问。
	 */
	protected function test(array $acls = null, string $entry = null){}
	
	/**
	 * 默认的访问控制。
	 * @param string $entry 入口。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return bool 允许访问返回 true。
	 */
	protected function default(string $entry, IUser $user = null){}
	
	/**
	 * 对比模式和入口。
	 * @param int $type 模式类型。
	 * @param string $pattern 模式。
	 * @param string $entry 入口。
	 * @return bool 匹配返回 true。
	 */
	protected function match(int $type, string $pattern, string $entry){}
	
	/**
	 * 根据入口规则验证身份。
	 * @param object $rule 规则。
	 * @param IUser $user 可选，用户。默认为访客。
	 * @return bool 有访问权限返回 true。
	 */
	protected function validate($rule = null, IUser $user = null){}
	
}