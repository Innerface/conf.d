<?php

/**
 * 文件管理器。
 * @author Max Wang
 * 
 */
abstract class Files extends web
{
	const METHODs = ['GET', 'POST', 'PUT', 'DELETE', 'MOVE', 'COPY', 'OPTIONS'];
	
	protected function pathpass(){}
	/**
	 * CORS 时判断来源和主机。
	 * @param string $method 请求的方法。
	 * @param string $origin 发起请求的来源链接。
	 * @param array $origins 主机设置的允许访问的来源表。
	 * @return boolean|string 允许访问时返回允许的源链接或 *，否则返回 falase。
	 */
	protected function originMatch(string $method, string $origin = null, $origins = null){}
	
	protected function preflight(){}
	
	protected function route(){}
	protected function identify(){}
	protected function authorize(){}
	protected function dispatch(){}
	
	/**
	 * 处理 GET 请求：如果请求的是一个文件，则返回文件的信息，包含外部访问链接。如果请求的是一个目录，则返回目录列表和目录信息。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function GET(string $pathinfo, & $res){}
	
	/**
	 * 处理 POST 请求。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function POST(string $pathinfo, & $res){}
	
	/**
	 * 处理 PUT 请求。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function PUT(string $pathinfo, & $res){}
	
	/**
	 * 处理 DELETE 请求。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function DELETE(string $pathinfo, & $res){}
	
	/**
	 * 处理 MOVE 请求。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function MOVE(string $pathinfo, & $res){}
	
	/**
	 * 处理 COPY 请求。
	 * @param string $pathinfo 请求路径。
	 * @param object $res 引用，响应数据。包含 state, message, data, debug, link 五个元素。
	 * @return int 返回 HTTP 状态码。默认为 200。
	 */
	protected function COPY(string $pathinfo, & $res){}
}
