<?php

/**
 * 独立操作基类。
 * @author Max
 * 
 */
abstract class Action implements IAction
{
	/**
	 * 所属的控制器。
	 * @var IController
	 */
	protected $controller;
	
	/**
	 * 构造操作。
	 * @param IController $controller 所属的控制器
	 */
	public function __construct(IController $controller = null){}
	
	public function init(IController $controller){}
	
	public abstract function run();
}