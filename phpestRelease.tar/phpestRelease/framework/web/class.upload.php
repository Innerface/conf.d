<?php

/**
 * 上传文件。
 * @author Max Wang
 */
class Upload
{
	/**
	 * 上传文件数组。
	 * @var array
	 */
	protected $file;
	
	/**
	 * 构造上传文件。
	 * @param array $file POST 上传文件的信息数组，即来自于 $_FILES。
	 */
	public function __construct(array $file){}
	
	/**
	 * 获取文件尺寸。
	 * @return int
	 */
	public function size(){}
	
	/**
	 * 获取错误号。
	 * @return int
	 */
	public function error(){}
	
	/**
	 * 获取文件类型。
	 * @return string
	 */
	public function type(){}
	
	/**
	 * 验证上传文件是否有效。
	 * @return bool
	 */
	public function validate(){}
	
	/**
	 * 保存文件到指定路径。
	 * @param string $file
	 * @return boolean
	 */
	public function save(string $file){}
}