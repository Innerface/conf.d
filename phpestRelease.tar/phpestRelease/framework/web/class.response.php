<?php

/**
 * HTTP 头信息。
 * @author Max
 * @property-read string $contentType 只读，内容类型。通过方法 contentType 设置。
 * @property-read string $charset 只读，字符集。通过方法 contentType 设置。
 * @property-read string $version 只读，字符集。通过方法 version 设置。
 * @property-read int $status 只读，当前设置的 HTTP 状态码，通过 http 方法设置的。
 * @property-read string $reason 只读，当前设置的 HTTP 原因短语，通过 http 方法设置的。
 * 
 */
class Response
{
	/**
	 * 内容类型。
	 * @var string
	 */
	protected $contentType;
	/**
	 * 字符集。
	 * @var string
	 */
	protected $charset;
	/**
	 * 版本号。
	 * @var string
	 */
	protected $version;
	/**
	 * HTTP 状态码(200 ~ 599)。
	 * @var int
	 */
	protected $status;
	/**
	 * HTTP 原因短语。
	 * @var string
	 */
	protected $reason;
	protected $httpProtocolVersion = "1.1";
	/**
	 * 头。
	 * @var array
	 */
	protected $_headers;
	
	public function __get(string $name){}
	
	/**
	 * XSS 保护选项。
	 * @param string $options 选项，默认为：deny。
	 * @return self
	 */
	public function xssProtection(string $options = '1; mode=block'){}
	
	/**
	 * 内容安全策略。
	 * @param string $policy 安全策略。
	 * @return self
	 */
	public function contentSecurityPolicy($policy = "default-src 'none'"){}
	
	/**
	 * 限制在浏览器的 frame 内调用，选项：deny。
	 * @param string $options 选项，默认为：deny。
	 * @return self
	 */
	public function frameOptions(string $options = 'deny'){}
	
	/**
	 * 内容类型嗅探的选项，设置为 nosniff 则禁止嗅探。
	 * @param string $options 选项，默认为：nosniff。
	 * @return self
	 */
	public function contentTypeOptions(string $options = 'nosniff'){}
	
	/**
	 * 版本。
	 * @param string $version 版本号。
	 * @return self
	 */
	public function version(string $version){}
	
	/**
	 * 设置内容类型。
	 * @param string $mime
	 * @param string $charset 可选，默认不设置。
	 * @return self
	 */
	public function contentType(string $mime, string $charset = null){}
	
	/**
	 * 设置内容类型为 HTML。
	 * @param string $charset 可选，字符集。
	 * @return self
	 */
	public function html(string $charset = null){}
	
	/**
	 * 设置内容类型为 XML。
	 * @param string $charset 可选，字符集。
	 * @return self
	 */
	public function xml(string $charset = null){}
	
	/**
	 * 设置内容类型为 JSON。
	 * @param string $charset 可选，字符集。
	 * @return self
	 */
	public function json(string $charset = null){}
	
	/**
	 * 设置内容类型为 JavaScript。
	 * @param string $charset 可选，字符集。
	 * @return self
	 */
	public function javascript(string $chatset = null){}
	
	/**
	 * 设置内容类型为 CSS。
	 * @param string $charset 可选，字符集。
	 * @return self
	 */
	public function css(string $chatset = null){}
	
	/**
	 * 设置内容类型为 PNG 图片。
	 * @return self
	 */
	public function png(){}
	
	/**
	 * 设置内容类型为 JPG 图片。
	 * @return self
	 */
	public function jpg(){}
	
	/**
	 * 设置内容类型为字节流。
	 * @return self
	 */
	public function stream(){}
	
	/**
	 * 根据设置发送头信息。
	 * @param int $status 状态码。
	 * @param string $reason 可选，原因短语。
	 * @param string $version 可选，HTTP 版本。
	 * @return self
	 */
	public function http(int $status, string $reason = null, string $version = null){}
	
	/**
	 * 禁止浏览器缓存。
	 * @return self
	 */
	public function disableCache(){}
	
	/**
	 * 设置头，用法同 header 函数。
	 * @param string $content 头的内容。
	 * @param bool $replace 可选，是否替换掉已存在的头，默认为 true。
	 * @param int $responseCode 可选，响应码。
	 * @return self
	 * @link http://php.net/manual/zh/function.header.php
	 */
	public function header(string $content, bool $replace = null, int $responseCode = null){}
	
}
