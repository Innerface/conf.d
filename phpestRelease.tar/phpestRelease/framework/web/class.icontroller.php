<?php

/**
 * 控制器。
 * @author Max
 */
interface IController
{
	public function __call($name, array $args = null);
	/**
	 * 映射名字。
	 * @param string $name 请求的 action 名。
	 * @return string 源 action 名。无映射则返回 null。
	 */
	public function __map(string $name);
	/**
	 * 检测是否支持指定的扩展操作（公共的方法或者 __map 被映射的方法始终支持）。
	 * @param string $name 请求的 action 名。
	 * @return bool 支持返回 true，否则返回 false。
	 */
	public function __support(string $name);
}