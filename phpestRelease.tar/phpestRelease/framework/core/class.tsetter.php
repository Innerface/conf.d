<?php

/**
 * 设置器特性：使用魔术方法为同名的属性赋值，并支持验证器和链式调用。
 * <strong>注意：名字以下划线开始的属性不能使用设置器进行设置。</strong>
 * <ol>
 * <li>将验证器赋值给非公开属性添加验证规则：$xyz->pro1 = new Validator\Type('int');
 * <strong>注意：公共属性不能使用此方法添加验证器。</strong>
 * 公共属性可以使用方法调用 $xyz->pro1(new Validator\Type('int')) 添加验证器。
 * </li>
 * <li>如果对象 $xyz 存在属性 pro1 和 pro2，则可以使用同名的方法
 * 为其赋值并链式调用：
 * <pre><code>$xyz->pro1('pro1 value')->pro2('pro2 value');
 * </code></pre></li>
 * <li>将闭包／回调赋值给属性可以设置转换／过滤器，需要配合使用属性获取器使用。
 * 例：$obj->pro1 = function($var){} 
 * 或者 $obj->pro1(function($var, $arg1){}, $arg1, ...) 
 * // $arg1 等后续参数将在调用时代入回调。</li>
 * </ol>
 * @author Max Wang
 */
trait TSetter
{
	public function __set(string $name, $var){}
	public function __unset(string $name){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 属性设置器。
	 * @param string $name 属性名，不支持名字以下划线开始的属性。
	 * @param mixed $var 属性值。
	 * @param mixed... $args 可变参数，传递给转换器的参数。
	 * @return void
	 */
	protected function __setter(string $name, $var, ... $args){}
}