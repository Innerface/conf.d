<?php

/**
 * 终止异常。
 * @author Max
 *
 */
class TerminateException extends Exception
{
}