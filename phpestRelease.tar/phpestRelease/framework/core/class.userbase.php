<?php

/**
 * 用户基类。
 * @author Max
 */
abstract class UserBase implements IUser, ArrayAccess
{
	/**
	 * 当前应用。
	 * @var app
	 */
	protected $app;
	
	/**
	 * 构造用户。
	 */
	public function __construct(){}
	
	public function namespace(){}
	
	public abstract function guid();
	public abstract function title();
	
	public function role(){}
	
	public function group(){}
	
	public function tags(){}
	
	public function ranking(){}
	
	public function acls(){}
	
	public function profile(){}
	
	public function settings(){}
	
	public function locale(){}
}