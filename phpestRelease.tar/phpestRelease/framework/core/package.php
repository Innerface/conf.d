<?php

/**
 * 获取 app 的实例。同类的 app 只会保存最后一个实例。
 * @param string $type 可选，应用程序的类名。默认为首个应用。
 * @return app
 */
function app(string $type = null){}

/**
 * 加载数据文件，尝试先从缓存文件加载，如果不存在缓存则读取源文件并解析，然后缓存。
 * @param string|array $cache 缓存文件路径，PHP 脚本文件。支持文件组，将依次尝试。
 * @param string|array $source 源文件路径。支持文件组，将依次尝试加载，成功后使用 $parser 解析。
 * @param callable $parser 解析器回调，加载并解析源文件内容并返回数据，签名为 mixed function (string $file)。
 * @param callable $writer 可选，脚本编写器。签名为 string function ($data) 参数为 $parser 返回的数据，返回的字符串将做为 PHP 脚本的内容写入缓存文件。$data 参数可以使用引用方式在编写器里改写。
 * @return mixed 返回数据。如果数据没有被缓存或过期，会被缓存到现在的缓存文件，如果没有缓存文件，则缓存到指定的首个文件。
 * @throws InvalidArgumentException 无效参数引发此异常。
 */
function datafile($cache, $source, callable $parser, callable $writer = null){}

/**
 * 获取全局运行时文件管理器。全局运行时路径也可以直接使用类名方式，例：runtime::cache('index.php');
 * @param string $args 可变参数，路径片段。
 * @return string|runtime 无参数调用时返回全局运行时管理器，否则返回路径。
 * @example runtime()->cache; // 获取路径形式一：获取 cache 目录
 * @example runtime('cache', 'index.php'); // 获取路径形式二：获取 cache/index.php 路径
 * @example runtime()->cache('index.php'); // 获取路径形式三：获取 cache/index.php 路径
 * @example runtime()->{'cache/index.php'}; // 获取路径形式四：获取 cache/index.php 路径
 * @example runtime::{'cache/index.php'}('text');
 * @example runtime::cache('text');
 */
function runtime(... $args){}

/**
 * 退出应用。
 * @param int|string $exitcode  可选，退出码或消息。
 * @return void
 * @throws TerminateException 始终引发应用中止异常。
 */
function quit($exitcode=0){}

/**
 * 设置器快捷函数。
 * @param mixed $host 引用，属主对象、数组或任意其它变量。注意：此参数必须是变量。
 * @return setter
 */
function setter(&$host = null){}

/**
 * 将类名转为驼峰样式的名字。
 * @param string $class 类名。
 * @return string
 * @example name('\Name\Space\class') // => nameSpaceClass
 */
function name(string $class){}

/**
 * 将不规范的类名转换为标准的 PHP 类名。
 * @param string $name 用点作为名字空间分隔符的类名。
 * @return string
 * @example name('ns.name') // = \ns\name
 * @example name('ns.class::name') // = \ns\class::name
 */
function classname(string $name){}