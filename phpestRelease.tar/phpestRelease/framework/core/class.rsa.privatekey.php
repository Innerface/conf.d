<?php

namespace RSA;

/**
 * 私钥。
 * @author Max Wang
 * 
 */
class PrivateKey
{
	protected $key;
	
	public function __construct(string $key){}
	
	/**
	 * 加密。
	 * @param string $data 原文数据。
	 * @param bool $raw 可选，是否原文输出。默认为作 BASE64 编码。
	 * @return string
	 */
	public function encrypt(string $data, bool $raw = false){}
	
	/**
	 * 解密。
	 * @param string $data 密文数据。
	 * @param bool $raw 可选，密文是否为原文或 base64 编码结果。默认为已编码。
	 * @return string|null
	 */
	public function decrypt(string $data, bool $raw = false){}
}