<?php

/**
 * 包的清单。
 * @author Max Wang
 * 
 */
class Package
{
	/**
	 * 普通代码包。
	 * @var integer
	 */
	const NORMAL = 0;
	/**
	 * 第三方非标准代码包。
	 * @var integer
	 */
	const VENDOR = 1;
	/**
	 * 资源包。
	 * @var integer
	 */
	const RESOURCE = 2;
	/**
	 * 应用包。
	 * @var integer
	 */
	const APP = 3;
	/**
	 * 已加载的应用包。
	 * @var integer
	 */
	const BOOTSTRAP = 4;
	
	/**
	 * 代码包类型。
	 * @var int
	 * @see Package::NORMAL
	 * @see Package::VENDOR
	 * @see Package::RESOURCE
	 * @see Package::APP
	 */
	public $type;
	/**
	 * 适用的最小 PHP 版本。
	 * @var string
	 */
	public $php;
	/**
	 * 引用的其它代码包。
	 * @var array|string
	 */
	public $use;
	/**
	 * 依赖的 PHP 扩展库。
	 * @var array|string
	 */
	public $requires;
	/**
	 * 包使用的名字空间。指定后代码类文件的文件名中可以省略此处列出来的名字空间。
	 * @var array|string
	 */
	public $namespace;
	/**
	 * 指示包中定义的所有类，推荐列出，可以提升代码加载时间。
	 * @var array
	 */
	public $classes;
	/**
	 * 适用的 SAPI 环境。
	 * @see SAPI_CLI
	 * @see SAPI_WEB
	 * @see SAPI_ANY
	 * @var int
	 */
	public $sapi;
}