<?php



/**
 * 应用程序基类。
 * @author Max
 * @property-write callable $oninit 初始化事件，参数类型：EventArgs。
 * @property-write callable $ondispose 销毁事件，参数类型：EventArgs。
 */
abstract class app implements IPathProvider, IEventHost
{
	use PathProvider, TEventHost;
	
	/**
	 * 应用的使用的模块。
	 * @var array
	 */
	const MODULEs = [];
	
	/**
	 * 运行模式：在线。
	 * @var int
	 */
	const ONLINE = 0;
	/**
	 * 运行模式：维护中。
	 * @var int
	 */
	const MAINTAIN = 1;
	/**
	 * 运行模式：离线。
	 * @var int
	 */
	const OFFLINE = 2;
	
	/**
	 * 事件及参数定义。
	 * @var array
	 */
	const EVENT = [
		'init'	=> null,
		'dispose' => null,
	];
	
	/**
	 * 调试。
	 * @var bool
	 */
	public $debug;
	/**
	 * 开启演示。
	 * @var bool
	 */
	public $demo;
	/**
	 * 运行模式。
	 * @var int
	 */
	public $mode;
	
	/**
	 * 配置管理器。
	 * @var IConfigProvider
	 */
	protected $config;
	/**
	 * 插件包。
	 * @var array
	 */
	protected $plugins = [];
	/**
	 * 数据库管理器。
	 * @var DB
	 */
	protected $db;
	
	
	/**
	 * 构造器。
	 * @param IConfigProvider $config 配置管理器。
	 */
	public final function __construct(IConfigProvider $config){}
	
	public final function __destruct(){}
	
	/**
	 * 调用插件。
	 * @param string $type 接口或类名。
	 * @param callable $call 回调。签名：function(IPlugIn $plugin, $index = null):bool，返回 true 继续。
	 * @return app
	 */
	public function apply(string $type, callable $call){}
	
	/**
	 * 遍历插件。
	 * @param string $type 类型或接口名。
	 * @return Generator
	 */
	public function next(string $type){}
	
	/**
	 * 插件。
	 * @param string $type 接口或类名。
	 * @return IPlugin 返回首个插件。
	 */
	public function plugin(string $type){}
	
	/**
	 * 获取模块。
	 * @param string $name 模块名。
	 * @param array $properties 可选，模块的属性。
	 * @return Module
	 */
	public function module(string $name, array $properties = null){}
	
	/**
	 * 获取数据库管理器。
	 * @return DB
	 */
	public function db(){}
	
	/**
	 * 注入插件。
	 * @param IPlugIn $plugin 插件。
	 * @param string|array $tags 可选，标签，一个或一组标签。
	 * @return app
	 */
	public function inject(IPlugIn $plugin, $tags = null){}
	
	/**
	 * 清除插件。
	 * @param string $plugin 接口名、类名或对象。注意，所有相关的都被移除，尽量使用对象。
	 * @return app
	 */
	public function clear($plugin){}
	
	/**
	 * 级联运行应用。
	 * @param callable... $callalbe 任何可调用的回调。注意：任何应用被延迟到当前应用运行以后运行。非应用的回调在当前应用之前运行。
	 * @throws RuntimeException 应用被多次运行引发此异常。
	 * @return int
	 */
	public final function __invoke(callable ... $callalbe){}
	
	/**
	 * 应用的 GUID。默认为当前 APP 的类名和父类类名的映射（名字空间分隔符转换为点）。
	 * @return array 反向返回 GUID，先返回最特定的 GUID。
	 * @example 如果当前应用的类名为 \app\demo，直接从 app 继承，则依次返回 ['app.demo', 'app']。
	 */
	public function guid(){}
	
	/**
	 * 当前应用的运行时文件管理器。
	 * @param string ... $args 可变参数，路径段。
	 * @return runtime|string
	 */
	public function runtime(...$args){}
	
	/**
	 * 配置管理器。
	 * @return IConfigProvider
	 */
	public function config(){}
	
	/**
	 * 是否支持指定的 SAPI 模式，一般包括 SAPI_WEB，SAPI_CGI, SAPI_CLI 三种之一。
	 * @param int $sapi SAPI 类型。
	 * @return bool 支持返回 true。
	 */
	public abstract function sapi($sapi) : bool;
	
	/**
	 * 调试信息。
	 * @return array
	 */
	public function debugInfo(){}
	
	/**
	 * 运行。
	 * @return void|int 返回非 0 值中止后续应用的运行，无返回值视为 0 值。
	 */
	protected function run(){}
	
	/**
	 * 引入脚本，不可继承。
	 * @param string $file 要加载的脚本文件。
	 * @param bool $once 可选，使用 require_once 或者 require 指令。
	 * @return mixed 返回脚本的返回值。
	 */
	protected final function require(){}
	
	/**
	 * 初始化。注意：不同于初始化事件。此方法仅在应用构造阶段调用。
	 */
	protected function initialize(){}
	
	/**
	 * 配置应用。
	 */
	protected function configure(){}
	
	/**
	 * 释放资源。
	 */
	protected function dispose(){}
	
	/**
	 * 获取 app 的实例。同类的 app 只会保存最后一个实例。
	 * @param string $type 可选，应用程序的类名。默认为首个应用。
	 * @return app
	 */
	public final static function instance(string $type = null){}
	
	/**
	 * 退出应用，中止（引发 TerminateException 异常），不可继承。
	 * @param int|string $exitcode 退出码或消息。web 环境忽略退出码。
	 * @throws TerminateException 引发中止异常。
	 */
	public final static function quit($exitcode = 0){}
}
