<?php


/**
 * 可中止的事件处理。
 * @author Max
 * 
 */
class BreakEventArgs extends EventArgs
{
	/**
	 * 是否中止后续事件处理器。当前事件处理器可以设置为 true 以取消后续事件处理。
	 * @var bool
	 */
	public $break;
}