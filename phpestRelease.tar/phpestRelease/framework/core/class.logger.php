<?php

/**
 * 日志记录器。
 * @author Max Wang
 * 
 */
class Logger implements ILogger, IEventHost
{
	use TEventHost;
	
	const EVENT = [
		'write' => '',
		'flush' => '',
	];
	
	public function write(ILog ... $logs){}
	
	public function msg(string ...$logs){}
	
	public function flush(){}
}