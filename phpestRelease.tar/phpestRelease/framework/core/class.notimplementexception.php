<?php

/**
 * 用于指示尚未实现的功能的异常。
 * @author Max
 * 
 */
class NotImplementException extends Exception
{
}