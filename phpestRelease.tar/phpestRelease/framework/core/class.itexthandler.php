<?php

/**
 * 文本处理器接口。
 * @author Max
 * 
 */
interface ITextHandler
{
	/**
	 * 获取文本的 MIME 类型名。
	 * @return string
	 */
	public function mime();
	
	/**
	 * 转换文本。
	 * @param string $text 文本。
	 * @param int $flag 可选，标记。
	 * @return string
	 */
	public function cast(string $text, int $flag = 0);
	/**
	 * 尝试转换文本。
	 * @param string $text 引用，文本。
	 * @param int $flag 可选，标记。
	 * @return bool
	 */
	public function try_cast(string & $text, int $flag = 0);
	
	/**
	 * 解析文本。
	 * @param string $text 源文本。
	 * @param int $flag 可选，标记。
	 * @return mixed 数据。
	 */
	public function parse(string $text, int $flag = 0);
	/**
	 * 尝试解析文本。
	 * @param string $text 源文本。
	 * @param mixed $data 引用，数据。
	 * @param int $flag 可选，标记。
	 * @return mixed 数据。
	 */
	public function try_parse(string $text, & $data = null, int $flag = 0);
	
	/**
	 * 连接文本。
	 * @param string... $text 可变参数，源文本段。
	 * @return string
	 */
	public function concat(string ... $text);
	/**
	 * 压缩文本。
	 * @param string $text 源文本。
	 * @return string
	 */
	public function minify(string $text);
	
	/**
	 * 转换、合并并输出。
	 * @param string... $text 源文本。
	 * @return ITextHandler $this
	 */
	public function merge(string ... $text);
	
	/**
	 * 读取文件，转换并压缩输出。
	 * @param string... $files 所有文件。
	 * @return ITextHandler $this
	 */
	public function read(string ... $files);
}