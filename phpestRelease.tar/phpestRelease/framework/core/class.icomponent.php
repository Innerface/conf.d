<?php

/**
 * 组件。
 * @author Max
 * 
 */
interface IComponent
{
}