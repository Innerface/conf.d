<?php

/**
 * 事件宿主。
 * 要使用事件处理，必须首先定义事件声明和事件参数类定义，方法为定义以 on_ 为前缀的事件名类常量，值为事件参数类名，
 * 例如 const on_error = 'ErrorEventArgs'。未指定事件参数类名则不使用参数。
 * 其次，附加事件处理程序，形式为：$host->on_event = function (object $sender, EventArgs $args = null){};
 * 事件处理器的签名为：void function (object $sender, EventArgs $args = null)
 * @version 1.0.0
 * @since 1.0.0
 */
interface IEventHost
{
	/**
	 * 附加事件处理器。
	 * @param string $event 事件名。
	 * @param callable $handler 事件处理器。签名为：bool function (object $sender, EventArgs $args=null);
	 * @param mixed $data 引用，可选，用户数据，调用时发回给注册到的事件处理器。存储在 $args 参数的 data 属性。
	 * @example attach('init', function ($sender, EventArgs $args = null){}, ['attachments']);
	 * @return IEventHost
	 */
	public function on(string $event, callable $handler, &$data=null);
	/**
	 * 解除事件处理器。
	 * @param string $event 事件名。
	 * @param callable $handler 可选，事件处理器，不提供则解除全部。签名为：bool function (object $sender, EventArgs $args=null);
	 * @return IEventHost
	 */
	public function un(string $event, callable $handler = null);
}
