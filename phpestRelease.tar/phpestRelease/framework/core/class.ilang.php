<?php

/**
 * 本地化字符串提供者。
 * @author Max
 * 
 */
interface ILang
{
	/**
	 * 获取指定语言包中指定的字符串。
	 * @param string $package 可选，包名。空的包名指代前置语言包。不指定则返回全部。
	 * @param int $start 可选，开始的位置索引号，注意：此处索引基于 0。可以为负值，表示从尾部倒数。不提供则返回全部。
	 * @param int $length 可选，数量，如果指定，则返回一批。可以为负值，表示到尾部截止。
	 * @return string|array 如果未指定 $length 则直接返回指定索引的字符串，否则返回字符串数组，如果未找到返回 null。
	 */
	public function bulk(string $package = null, int $start = null, int $length = null);
	
	/**
	 * 获取字符串。
	 * @param string $string 索引字符串。
	 * @param string... $strings 可变参数，其它的索引字符串。
	 * @return string 连接所有的字符串。
	 */
	public function string($string, ... $strings);
	
	/**
	 * 转换字符串。
	 * @param string $string 引用，将这个源字符串变量的文本直接转换为目标字符串。
	 * @return ILang $this
	 */
	public function cast(& $string);
	
	/**
	 * 输出本地化的字符串。
	 * @param string ...$string 可变参数，字符串。
	 * @return ILang $this
	 */
	public function echo(...$string);
	/**
	 * 输出本地化的字符串。
	 * @param string $string 字符串。
	 * @return ILang $this
	 */
	public function print($string);
	/**
	 * 格式化输出本地化的字符串。
	 * @param string $format 格式化字符串。
	 * @param mixed $args 可变参数。
	 * @return ILang $this
	 */
	public function printf($format, ... $args);
	/**
	 * 格式化输出本地化的字符串。
	 * @param string $format 本地化的格式字符串。
	 * @param array $args 参数表。
	 * @return ILang $this
	 */
	public function vprintf($format, array $args);
	/**
	 * 返回格式化的本地化字符串。
	 * @param string $format 格式字符串。
	 * @param mixed $args 可变参数。
	 * @return string
	 */
	public function sprintf($format, ... $args);
	/**
	 * 返回格式化的本地化字符串。
	 * @param string $format 格式字符串。
	 * @param array $args 参数表。
	 * @return string
	 */
	public function vsprintf($format, array $args);
	
	/**
	 * 切换目标区域。
	 * @param string $locale 目标语言包代码。
	 * @param string $index 可选，索引语言包代码。不指定此参数则仅切换目标语言代码。
	 * @return ILang 返回本地化字符串提供者本身 $this。
	 */
	public function locale(string $locale, string $index = null);
	/**
	 * 切换索引区域。
	 * @param string $locale 新的索引的区域。
	 * @return ILang 返回本地化字符串提供者本身 $this。
	 */
	public function index(string $locale);
	
	/**
	 * 获取指定包的语言相关文件路径。可变参数方法，两种调用形式：
	 * <ol>
	 * <li>使用一个参数，包名和文件名。形式为：string function (string $id)</li>
	 * <li>使用两个参数，第一个为包名，第二个文件名。形式为：string function (string $package, string $filename)</li>
	 * </ol>
	 * @param string $package 包名。
	 * @param string $filename 文件名。
	 * @return string 返回完整的文件名。如果文件不存在则返回 null。
	 */
	public function file($package, $filename = null);
}