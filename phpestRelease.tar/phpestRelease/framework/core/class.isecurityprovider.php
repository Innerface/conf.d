<?php

/**
 * 安全数据提供者，不要将安全数据以任何形式直接或间接存储，在计算时用完立即销毁。
 * @author Max Wang
 * 
 */
interface ISecurityProvider
{
	/**
	 * 初始向量。
	 */
	public function vi();
	/**
	 * 键。
	 * @param string $namespace 名字空间。
	 * @return string
	 */
	public function key(string $namespace);
	
	/**
	 * 获取公钥。
	 * @return string
	 */
	public function publicKey();
	/**
	 * 获取私钥。
	 * @return string
	 */
	public function privateKey();
}