<?php

/**
 * 插件接口。
 * @author Max
 */
interface IPlugIn
{
	/**
	 * 是否单例模式。
	 * @return bool
	 */
	public function isSingleton() : bool;
	/**
	 * 调试信息。
	 * @return array
	 */
	public function debugInfo();
}