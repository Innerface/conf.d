<?php

/**
 * 标量值（包括日期时间）范围类型。
 * 代表一系列标量值的范围，用于表示：<ol>
 * <li>区间（值可以进行 > , < 和 = 等比较运算的同类型值）。</li>
 * <li>列表，列举一组标量值。</li>
 * </ol>
 */
class range
{
	/**
	 * 区间。
	 * @var int
	 */
	const INTERVAL = 0;
	/**
	 * 列表。
	 * @var int
	 */
	const LIST = 1;
	
	/**
	 * 区间的类型。
	 * @return int 返回self::TYPE_RANGE或self::TYPE_LIST。
	 */
	public function type(){}
	
	/**
	 * 获取定义。
	 */
	public function define(){}
	
	/**
	 * 构造器，两种用法：<ol>
	 * <li>创建列表，签名为：__construct(array $array, $strict = false)，参数 $strict 表示是否严格测试，默认不进行严格测试。</li>
	 * <li>创建区间，签名为：__construct($min = null, $max = null, $strict = false, $includeMin = true, $includeMax = true)，
	 * $min表示最小值（null为负无限），$max表示最大值（null为正无限），
	 * $strict 表示是否严格测试（严格测试包括类型测试且最小值和最大值也必须是相同类型，如果最小值和最大值类型不同则此参数无效），
	 * 默认不进行严格测试，$includeMin表示是否包括最小值（左闭区间），默认包括，
	 * $includeMax表示是否包括最大值（右闭区间），默认包括。</li>
	 * </ol>
	 */
	public function __construct(){}
	
	/**
	 * 验证。
	 * @param mixed... $args 可变参数，任何可进行比较的数据。
	 * @return bool 返回验证结果，如果全部通过测试返回 true，否则返回 false。
	 */
	public function validate(... $args){}
	
	public function __toString(){}
	
	protected function equals($var1 = null, $var2 = null){}
	
	/**
	 * 创建列表范围。
	 * @param array $array 条目列表。
	 * @param bool $strict 可选，是否严格测试，即同时测试类型，默认不进行严格测试。
	 * @return range
	 */
	public static function list(array $array, $strict = false){}
	
	/**
	 * 创建区间。
	 * @param mixed $min 最小值。
	 * @param mixed $max 最大值。
	 * @param bool $strict 可选，是否严格测试，即同时测试类型，默认不进行严格测试。
	 * @param bool $includeMin 可选，是否包含最小值，默认包含。
	 * @param bool $includeMax 可选，最否包含最大值，默认包含。
	 * @return range
	 */
	public static function interval($min = null, $max = null, $strict = false, $includeMin = true, $includeMax = true){}
}
