<?php

/**
 * 设置器。
 * @author Max
 * 
 */
class setter
{
	protected $host;
	
	public function __construct(&$host = null){}
	
	public function __call(string $name, array $args = null){}
	
	public function & __invoke(callable $call = null){}
	
	public function __toString(){}
}