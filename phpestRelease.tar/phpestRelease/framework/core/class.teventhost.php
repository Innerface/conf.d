<?php

/**
 * 事件宿主处理。
 * <ol>
 * <li>事件宿主常量 EVENT array 定义提供的所有事件，键为事件名，值为事件参数的类名
 * ( null 表示默认参数类型 EventArgs)。</li>
 * <li>事件宿主使用 $this->raise('事件名', ... $args) 方法引发事件，$args 为引
 * 发事件的参数，会传递给事件参数的构造函数。</li>
 * <li>注册事件处理器 $host->on('事件名', function($sender, EventArgs $args){
 *   $args->data;// ... 事件处理
 * }, $data);
 * </li>
 * </ol>
 * @example
 * <pre>
 * $host->on('事件名', function ($sender, EventArgs $args)
 * {
 * 		// TODO 事件处理
 * }, $data)</pre>
 * @version 1.0.0
 * @since 1.0.0
 */
trait TEventHost
{
	/**
	 * 处理器。
	 * @var array
	 */
	protected $event_handlers;
	
	/**
	 * 宿主，默认为当前对象，可以设置为其它宿主。
	 * @var object
	 */
	protected $event_host;
	
	public function __set(string $name, $handler){}
	
	public function __unset(string $name){}
	
	/**
	 * 附加事件处理器。
	 * @param string $event 事件名。
	 * @param callable $handler 事件处理器。签名为：bool function (object $sender, EventArgs $args=null);
	 * @param mixed $data 引用，可选，用户数据，调用时发回给注册到的事件处理器。存储到 $args 参数的 data 属性。
	 * @return self
	 */
	public function on(string $event, callable $handler, & $data = null){}
	
	/**
	 * 解除事件处理器。事件处理器为 null 时解除附加的全部事件处理器。
	 * @param string $event 事件名。
	 * @param callable $handler 可选，事件处理器。签名为：bool function (object $sender, EventArgs $args=null);
	 * @return self
	 */
	public function un(string $event, callable $handler = null){}
	
	/**
	 * 引发事件，宿主必须实现了 IEventHost 接口。
	 * @param string $name 事件名。
	 * @param mixed... $args 可变参数，事件参数。将依次被转发给事件参数的构造函数。
	 * @return EventArgs 返回事件参数
	 */
	protected function raise(string $name, ... $args){}
	
	/**
	 * 事件处理魔术方法，仅在没有任何定义或附加任何事件处理器时使用。
	 * @param string $name 事件名。
	 * @param EventArgs $args 可选，事件参数。
	 * @return void
	 */
	protected function __raise(string $name,  EventArgs $args=null){}
	
	/**
	 * 检测事件是否声明并获取关联参数的类名。
	 * @param string $event 事件名。
	 * @param string $class 引用，可选，成功获取则输出事件参数类名。
	 * @return bool 是否定义。
	 */
	public function declared(string $event, string & $class = null) : bool{}
}