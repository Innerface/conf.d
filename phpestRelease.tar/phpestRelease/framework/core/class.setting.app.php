<?php

namespace Setting;

/**
 * 应用的配置。
 * @author Max Wang
 * @method self mode(int $mode) 应用模式。
 * @method self demo(int $state) 应用状态。
 */
class APP extends \Setting
{
	/**
	 * 运行模式：在线。
	 * @var int
	 */
	const ONLINE = 0;
	/**
	 * 运行模式：维护中。
	 * @var int
	 */
	const MAINTAIN = 1;
	/**
	 * 运行模式：离线。
	 * @var int
	 */
	const OFFLINE = 2;
	
	/**
	 * 调试。
	 * @var bool
	 */
	public $debug;
	/**
	 * 开启演示。
	 * @var bool
	 */
	public $demo;
	/**
	 * 运行模式。
	 * @var int
	 */
	public $mode;
	
	/**
	 * 启用调试，不设置此项则表示关闭调试。
	 * @param int $mode 启用模式：0 自动（默认），1 开启，2 根据 cookie 状态开启（设置了 debug），
	 * 3 根据查询字符串开启（设置了 debug）， 4 根据头请求开启（设置了 x-debug-mode）
	 * @return self
	 */
	public function debug(int $mode = 0){}
}