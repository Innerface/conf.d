<?php

/**
 * 可配置的路径提供者。
 * @author Max
 * 
 */
trait PathProvider
{
	/**
	 * 虚拟目录定义，即路径映射（关联数组）。
	 * <ol>
	 * <li>数组的键作为子目录名，字符串键作为名字，整数键作为索引号。</li>
	 * <li>数组的值作为子路径。注意：所有的目录不要以目录分隔符结束。</li>
	 * <li>支持虚拟目录或文件：子路径使用绝对路径（以目录分隔符开始或在 windows 下指定了类似 C:\ 的驱动器符）
	 * 可将子路径或文件映射到其它任意目录或文件。</li>
	 * <li>支持目录组或文件组，子路径定义为一维数组，按优先顺序排列。</li>
	 * </ol>
	 * @var array
	 * @example $this->path['data']=>APP . DS . 'data' 	// 映射虚拟子目录 data 到应用目录下的 data 目录
	 * @example $this->path['view']=>'/widget/views'	// 映射虚拟子目录 view 到 /widget/views
	 * @example $this->path['views']=>['themes/views', 'views'] // 映射子目录 views 到一组目录: themes/views 和 views
	 */
	protected $path;
	
	/**
	 * 获取路径，注意：子目录/文件可以被映射到其它任意目录/文件，未验证目录/文件是否存在或可读写。
	 * 只有首个目录/文件才会映射，后续路径段只是简单连接到映射后的路径。无参数调用返回根目录。
	 * @param integer|string $name 子目录名或索引，子目录/文件指示符（整形，映射到的子目录/文件）或子目录/文件名（字符串）。如果是子目录名，找不到时作为普通的路径段连接。
	 * @param mixed... $args 可变参数，路径段。注意：无效的路径段会被忽略。
	 * @return string|array 返回完整的物理路径，如果是目录组则返回数组，注意：结尾不包含目录分隔符。
	 * @example path('logs', '12/admin.log'); // logs 目录下 12/admin.log 文件
	 */
	public function path($name = null, ... $args){}
	
	/**
	 * 获取子目录（注意：目录可以被重定义，不一定在当前应用目录下）。
	 * @param int|string $name 可选，子目录名或索引。如果是子目录名，找不到时作为普通的路径段连接。
	 * @param bool $first 可选，返回最优先的。默认返回全部
	 * @return string|array 如果为目录组则返回数组，除非只要求返回最优先的。无定义返回 null。
	 */
	public function directory($name = null, bool $first = false){}
	
	/**
	 * 搜索文件或目录。
	 * @param int|string $directory 子目录名或索引。如果是子目录名，找不到时作为普通的路径段连接。
	 * @param string $pattern 文件名通配模式。
	 * @param bool $first 可选，返回最优先的。默认返回全部
	 * @param int $flag 可选，标记，glob 函数的标记均有效。
	 * @return string|array 返回找到的所有文件或目录的绝对路径，未找到返回 null。只返回最优先则返回字符串，否则返回数组。
	 */
	public function glob(string $directory, string $pattern, bool $first = false, int $flag = GLOB_NOSORT){}
	
	/**
	 * 当前提供者的根目录。一般只需要返回 __DIR__，即代码文件所在的目录即可。
	 * @return string 注意：不要以目录分隔符结束。
	 */
	protected abstract function __directory();
}
