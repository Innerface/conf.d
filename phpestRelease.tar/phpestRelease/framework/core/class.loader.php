<?php

/**
 * 加载器。
 * @author Max Wang
 * 
 */
class Loader
{
	/**
	 * 要加载的资源的名字。
	 * @var string
	 */
	public $name;
	/**
	 * 要加载的资源的文件路径。
	 * @var string
	 */
	public $file;
	/**
	 * 资源的宿主环境。
	 * @var object
	 */
	public $host;
	
	/**
	 * 资源的数据上下文。
	 * @var array
	 */
	protected $context;
	
	/**
	 * 构造器。
	 * @param string $name 资源名。
	 * @param string $file 资源文件。
	 * @param object $host 可选，资源宿主。
	 * @param array $context 可选，资源的上下文数据。
	 */
	public function __construct(string $name, string $file, $host = null, array $context = null){}
	
	public function __invoke(){}
}
