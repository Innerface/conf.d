<?php

/**
 * 属性获取器。数据转换器和过滤器可以配合设置器特性。
 * @author Max Wang
 * 
 */
trait TGetter
{
	public function __get(string $name){}
	
	public function __isset(string $name){}
	
	/**
	 * 属性获取器。
	 * @param string $name 属性名，不支持名字以下划线开始的属性。
	 * @return mixed|null
	 */
	protected function __getter(string $name){}
}