<?php

/**
 * 构造器。
 * @author Max Wang
 */
class Creator
{
	protected $type;
	protected $args;
	protected $properties;
	protected $events;
	protected $base;
	
	/**
	 * 构造器。
	 * @param string $type 类名。
	 * @param mixed... $args 参数，传递给要构造的对象的构造器的参数，注意：如果参数不匹配对象的构造函数会引发异常。
	 */
	public function __construct(string $type, ... $args){}
	
	/**
	 * 限定目标对象要实现的接口或基类。
	 * @param string... $type 可变参数，接口名或类名。
	 * @return self
	 */
	public function base(string ... $type){}
	
	/**
	 * 设置属性集。
	 * @param array $properties 属性数据。注意：仅为对象的已声明的公共属性赋值。
	 * @return self
	 */
	public function properties(array $properties){}
	
	/**
	 * 附加事件处理。
	 * @param string $name 事件名，注意：不要带事件前缀，并且仅为对象已声明的事件附加事件处理器。
	 * @param callable $handler 事件处理器回调。
	 * @param mixed $data 引用，可选，要附加的数据。
	 * @return self
	 */
	public function on(string $name, callable $handler, &$data = null){}
	
	/**
	 * 构造对象。注意：构造出错或参数不正确将引发异常。
	 * @param callable $factory 可选，代理构造器。使用代理构造器构造对象，签名：function(string $type, array $args = null):TYPE
	 * @return object 如果不是有效的类或不属于限定的基类的子类或未实现指定的接口返回 null
	 */
	public function __invoke(callable $factory = null){}
}