<?php

/**
 * 验证管理器，提供认证和授权服务。
 * @version 1.0
 * @since 1.0
 * @author Max
 */
interface IAuthManager
{
	/**
	 * 认证，验证当前令牌是否有效（一般指使用者是否获得访问令牌）。
	 * @param string|int $token 可选，指定的令牌，未指定则为当前令牌。
	 * @return bool 有效返回 true，无效返回 false。
	 */
	public function authenticate($token = null);
	/**
	 * 授权/批准，批准用户访问指定资源。
	 * @param string $entry 入口。
	 * @param string $token 可选，访问令牌。默认为当前用户的访问令牌。
	 * @return bool 允许返回 true，否则返回 false。
	 */
	public function authorize(string $entry, $token = null);
	/**
	 * 获取当前会话的访问令牌。
	 * @return string|int
	 */
	public function token();
	/**
	 * 获取用户信息。
	 * @param string|int $token 可选，指点的令牌，未指定则为当前令牌。
	 * @return IUser
	 */
	public function user($token = null);
	/**
	 * 当前令牌的超时时间，单位：秒。
	 * @param string|int $token 可选，指定的令牌，未指定则为当前令牌。
	 * @return int
	 */
	public function timeout($token = null);
	/**
	 * 刷新令牌时间。
	 * @param string|int $token 可选，指点的令牌，未指定则为当前令牌。
	 * @return bool
	 */
	public function refresh($token = null);
	/**
	 * 立即撤消令牌。
	 * @param string|int $token 可选，指定的令牌，未指定则为当前令牌。
	 * @return bool
	 */
	public function revoke($token = null);
	/**
	 * 临时授权。
	 * @param string|int $token 令牌。
	 * @param string $entry 入口。
	 * @param int $timeout 超时，如果令牌超时则临时授权也被同时取消。
	 * @return bool 授权成功返回 true
	 */
	public function grant($token, string $entry, int $timeout);
}
