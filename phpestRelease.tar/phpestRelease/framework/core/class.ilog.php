<?php

/**
 * 日志记录。
 * @author Max
 * 
 */
interface ILog
{
	/**
	 * 设置日志条目的类型。
	 * @param int $type 类型。
	 * @return ILog $this
	 */
	public function type(int $type);
	/**
	 * 设置日志的级别。
	 * @param int $level 级别。
	 * @return ILog $this
	 */
	public function level(int $level);
	/**
	 * 返回日志记录。
	 * @return ILog $this
	 */
	public function __invoke();
	public function __toString();
}
