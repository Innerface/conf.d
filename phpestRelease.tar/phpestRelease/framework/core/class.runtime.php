<?php

/**
 * 运行时文件管理器。
 * @author Max
 * @property string $cache 只读，缓存目录。
 * @property string $config 只读，配置目录。
 * @property string $data 只读，数据目录。
 * @property string $files 只读，文件目录。
 * @property string $logs 只读，日志目录。
 * @property string $plugins 只读，插件目录。
 * @property string $traces 只读，跟踪目录。
 * @method string cache(string $path, ... $args) 获取缓存文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string config(string $path, ... $args) 获取配置文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string data(string $path, ... $args) 获取数据文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string files(string $path, ... $args) 获取普通文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string logs(string $path, ... $args) 获取日志文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string plugins(string $path, ... $args) 获取插件文件或子目录。string $path 子路径，可变参数，支持多段路径。
 * @method string traces(string $path, ... $args) 获取跟踪文件或子目录。string $path 子路径，可变参数，支持多段路径。
 */
class runtime implements IPathProvider
{
	use PathProvider;
	
	/**
	 * 构造运行时。
	 * @param app $app 应用程序。
	 */
	public function __construct(app $app = null){}
	
	protected function __directory(){}
	
	public function __get($name){}
	
	public function __call($name, array $args = null){}
	
	public function __invoke(... $args){}
	
	public function __toString(){}
	
	/**
	 * 清除指定子路径下符合指定模式的全部文件。
	 * @param string $name 子目录。
	 * @param string $pattern 可选，正则表达式，要清除的文件名模式（匹配的文件被清除）。不指定则表示所有项目。
	 * @param string $excluded 可选，正则表达式，要排除的文件名模式（匹配的文件被忽略）。
	 * @return int 返回清除的数量。
	 */
	public function clear($name, $pattern=null, $excluded = null, $recursive = true){}
	
	/**
	 * 全局运行时文件路径。
	 * @return string
	 */
	public static function __callstatic($name, array $args = null){}
}