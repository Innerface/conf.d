<?php

/**
 * 日志记录器接口。
 * @author Max
 * 
 */
interface ILogger
{
	/**
	 * 写入日志。
	 * @param ILog... $logs 可变参数，日志记录。
	 * @return ILogger $this
	 */
	public function write(ILog ... $logs);
	
	/**
	 * 写入消息。
	 * @param string... $logs 可变参数，日志记录。
	 * @return ILogger $this
	 */
	public function msg(string ...$logs);
	
	/**
	 * 写入。
	 * @return ILogger $this
	 */
	public function flush();
}