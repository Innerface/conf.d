<?php

/**
 * 未找到的异常。
 * @author Max
 * 
 */
class NotFoundException extends Exception
{
}