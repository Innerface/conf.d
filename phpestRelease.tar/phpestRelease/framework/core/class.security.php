<?php

/**
 * 安全服务。
 * @author Max Wang
 * 
 */
class Security
{
	/**
	 * 安全信息提供者。
	 * @var ISecurityProvider
	 */
	protected $provider;
	
	public function __construct(ISecurityProvider $provider){}
	
	/**
	 * 使用默认的设置加密数据。
	 * @param string $plaintext 明文字符串。
	 * @param bool $raw 可选，是否返回原始字节流或编码字符串。默认为 BASE 64 编码的字符串。
	 * @return string|null
	 */
	public function encrypt(string $plaintext, bool $raw = false){}
	
	/**
	 * 使用默认的设置解密数据。
	 * @param string $ciphertext 密文字符串。
	 * @param bool $raw 可选，密文是原始的字节流还是已使用 BASE 64 编码的字符串，默认为 false，表示已编码。
	 * @return string|null
	 */
	public function decrypt(string $ciphertext, bool $raw = false){}
	
	/**
	 * 安全的比较字符串是否相等，防止时序攻击。注意字符串参数的顺序。
	 * @param string $knownString 已知的字符串。
	 * @param string $userString 要比较的字全字符串。
	 * @return boolean 如果相等返回 true.
	 */
	public function equals(string $knownString, string $userString){}
	
	public function hash(string $algo, string $data, bool $raw = false){}
	
	public function md5(string $data, bool $raw=false){}
	
	public function sha1(string $data, bool $raw = false){}
	
	public function crc32(string $data){}
	
	/**
	 * 创建安全的密码散列。
	 * @param string $password 密码原文。
	 * @param int $algo 可选，散列算法。
	 * 当前支持的算法：<ul>
	 * <li>PASSWORD_DEFAULT - 使用 bcrypt 算法 (PHP 5.5.0 默认)。 
	 * 注意，该常量会随着 PHP 加入更新更高强度的算法而改变。
	 * 所以，使用此常量生成结果的长度将在未来有变化。
	 * 因此，数据库里储存结果的列可超过60个字符（最好是255个字符）。</li>
	 * <li>PASSWORD_BCRYPT - 使用 CRYPT_BLOWFISH 算法创建哈希。 
	 * 这会产生兼容使用 "$2y$" 的 crypt()。 结果将会是 60 个字符的字符串， 
	 * 或者在失败时返回 FALSE。</li>
	 * </ul>
	 * @param int $cost 可选，算法复杂度，默认为 10，值介于 4~31 之间。
	 * @return string
	 */
	public function password(string $password, int $algo = null, int $cost = null){}
	
	/**
	 * 验证密码。
	 * @param string $password 用户密码原文。
	 * @param string $hash 使用 password 方法创建的散列值。
	 * @return bool
	 */
	public function verify(string $password, string $hash){}
	
	/**
	 * 生成随机的安全字符串。
	 * @param int $length 字符串长度。
	 * @return string
	 */
	public function randomBytes(int $length = 32){}
	
	/**
	 * 生成盐值。
	 * @param int $cost 复杂度，默认为 10.
	 * @throws InvalidArgumentException
	 * @return string
	 */
	protected function salt(int $cost = 10){}
}