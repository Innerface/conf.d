<?php

/**
 * 用户个人信息/档案。
 * @author Max
 * 
 */
abstract class ProfileBase
{
	/**
	 * 获取关联的用户。
	 * @return User
	 */
	public abstract function user();
}