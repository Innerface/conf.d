<?php

/**
 * 使用 openssl 扩展库实现的 RSA 非对称加密。
 * @author Max Wang
 * 
 */
class RSA
{
	/**
	 * 安全信息提供者。
	 * @var ISecurityProvider
	 */
	protected $provider;
	
	public function __construct(ISecurityProvider $provider){}
	
	/**
	 * 返回公钥。
	 * @return \RSA\PublicKey
	 */
	public function publicKey(){}
	
	/**
	 * 返回私钥。
	 * @return \RSA\PrivateKey
	 */
	public function privateKey(){}
	
	/**
	 * 生成自签署的证书。
	 * @param string $commonName 通用名，典型的使用域名。
	 * @param string $emailAddress 电邮地址。
	 * @param string $countryName 国家代码。标准的两位国家代码，如 CN。
	 * @param string $stateOrProvinceName 省或州。
	 * @param string $localityName 本地地址。
	 * @param string $organizationName 组织名称。
	 * @param string $organizationalUnitName 部门名称。
	 * @return array|null 返回 csr, cert 和 pkey 及 error 内容。
	 */
	public static function csr(string $commonName, string $emailAddress, string $countryName, string $stateOrProvinceName, string $localityName, string $organizationName = null, string $organizationalUnitName = null){}
	/**
	 * 创建密钥对。
	 * @param int $bits 私钥长度。
	 * @param string $algo 可选，摘要算法，默认为 SHA256，可用的摘要算法参考 openssl_get_md_methods 函数。
	 * @param string $passphrase 可选，口令。
	 * @param int $ciper 可选，口令加密算法，参考 OPENSSL_CIPHER_ 为前缀的一系列常量。
	 * @return string[]|null 返回包含两个字符串的数组，第一个字符串为私钥，第二个为公钥。出错返回 null。
	 * @link http://php.net/manual/zh/function.openssl-get-md-methods.php
	 */
	public static function keygen(int $bits, string $algo = 'SHA256', string $passphrase=null, int $ciper = OPENSSL_CIPHER_AES_128_CBC){}
}