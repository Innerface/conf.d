<?php

/**
 * 文件系统路径。
 * @author Max
 */
class path
{
	/**
	 * 路径的基目录。
	 * @var string
	 */
	protected $base;
	/**
	 * 子目录映射。
	 * @var array
	 */
	protected $directories;
	
	/**
	 * 构造路径管理器。
	 * @param string $base 基目录。
	 * @param string ... $args 可变参数，路径段。最末段如果为数组，则视作虚拟目录映射表。
	 * @example path('base', 'sub', 'directory', ['virtual directory 1'=>'path', 'virtual directory 2'=>'path', ...]);
	 */
	public function __construct(string $base, ... $args){}
	
	public function __set($name, $path){}
	
	public function __get($name){}
	
	public function __isset($name){}
	
	public function __unset($name){}
	
	public function __call($name, array $args){}
	
	public function __invoke(... $args){}
	
	public function __toString(){}
	
	/**
	 * 获取全局运行时文件路径。
	 * @param string ...$args 可变参数，路径段。
	 * @return path
	 */
	public static function runtime(... $args){}
	
	/**
	 * 获取代码包路径。
	 * @param string $name 包名。
	 * @param string ...$args 可变参数，路径段。
	 * @return path
	 */
	public static function package($name, ... $args){}
	
	/**
	 * 获取当前应用的路径。
	 * @param string ...$args 可变参数，路径段。
	 * @return path
	 */
	public static function app(... $args){}
}