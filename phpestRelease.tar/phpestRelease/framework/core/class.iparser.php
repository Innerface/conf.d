<?php

/**
 * 解析器。
 * @author Max
 * 
 */
interface IParser
{
	/**
	 * 解析。
	 * @param mixed $raw 源数据，通常为文本。
	 * @return mixed
	 */
	public function parse($raw);
	/**
	 * 尝试解析。
	 * @param mixed $raw 源数据，通常为文本。
	 * @param mixed $result 引用，可选，如果解析成功，此参数输出解析结果。
	 * @return boolean 成功解析返回 true。
	 */
	public function try_parse($raw, &$result = null);
}