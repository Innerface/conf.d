<?php

/**
 * 日志记录。
 * @author Max Wang
 * 
 */
class Log implements ILog
{
	const MESSAGE = 0;
	const NOTIFY = 1;
	const DEBUG = 2;
	const WARNING = 3;
	const ERROR = 4;
	const FATAL = 5;
	
	public $type;
	public $level;
	public $message;
	
	/**
	 * 构造日志。
	 * @param string $message 日志内容。
	 * @param int $type 可选，类型。
	 * @param int $level 可选，级别。
	 */
	public function __construct($message, int $type = self::MESSAGE, int $level = null){}
	
	public function type(int $type){}
	
	public function level(int $level){}
	
	/**
	 * 设置消息文本。
	 * @param string $message 消息。
	 * @return Log
	 */
	public function message($message){}
	
	public function __invoke(){}
	
	public function __toString(){}
}