<?php

/**
 * 事件宿主。
 * @author Max
 * 
 */
class EventHost implements IEventHost
{
	use TEventHost;
	
	/**
	 * 构造器。
	 * @param object $host 指定新的宿主。
	 */
	public function __construct($host = null){}
	
	public function __set($name, $handler = null){}
	
	public function __unset($name){}
}
