<?php

/**
 * 用户。
 * @author Max
 * 
 */
interface IUser
{
	/**
	 * 获取所在的全部名字空间。
	 * @return array 返回用户所在的全部名字空间。
	 */
	public function namespace();
	/**
	 * 获取当前名字空间下的全局唯一标识符。
	 * @return int|string
	 */
	public function guid();
	/**
	 * 获取当前名字空间下的称呼或称谓。
	 * @return string
	 */
	public function title();
	/**
	 * 获取当前名字空间下的用户角色。
	 * @return array
	 */
	public function role();
	/**
	 * 获取当前名字空间下的用户组。
	 * @return array
	 */
	public function group();
	/**
	 * 获取当前名字空间下的标签。
	 * @return array
	 */
	public function tags();
	/**
	 * 获取当前名字空间下的用户等级。
	 * @return int
	 */
	public function ranking();
	
	/**
	 * 获取当前名字空间下的访问控制列表定义。
	 * @return array
	 */
	public function acls();
	
	/**
	 * 用户账户。
	 * @return IAccount
	 */
	public function account();
	/**
	 * 获取当前名字空间下用户的个人信息。
	 * @return Profile
	 */
	public function profile();
	/**
	 * 获取当前名字空间下用户的个人设置。
	 * @return array
	 */
	public function settings();
	/**
	 * 当前用户的区域代码。
	 * @return string
	 */
	public function locale();
	
}