<?php

/**
 * 事件参数对象。
 * @author Max
 * 
 */
class EventArgs
{
	/**
	 * 引用，在附加到事件时由事件处理器提交的可选数据。
	 * @var mixed
	 */
	public $data;
}