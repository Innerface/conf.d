<?php

class_alias('app', 'application', true);


__halt_compiler();

/**
 * app 别名。
 * @author Max
 */
abstract class application extends app{}
