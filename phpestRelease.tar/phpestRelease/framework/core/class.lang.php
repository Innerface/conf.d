<?php


/**
 * 语言包管理器。
 * @author Max
 * @method string zh_cn(string ... $strings) 使用简体中文作为索引获取字符串。
 * @method string en_us(string ... $strings) 使用美式英文作为索引获取字符串。
 */
class lang implements ILang
{
	/**
	 * 定界符最大长度。
	 * @var int
	 */
	const DELIMITER_MAX_LENGTH = 20;
	
	/**
	 * 当前的区域代码。
	 * @var string
	 */
	protected $locale;
	/**
	 * 索引的区域代码。
	 * @var string
	 */
	protected $index;
	
	/**
	 * 索引表。
	 * @var array
	 */
	protected $indexes;
	/**
	 * 字符串表。
	 * @var array $text
	 */
	protected $text;
	
	/**
	 * 构造语言包管理器。
	 * @param string $index 索引文本使用的区域代码。
	 * @param string $locale 目标语言区域代码。
	 */
	public function __construct(string $index = null, string $locale = null){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * 尝试获取字符串。
	 * @param string $string 引用，索引字符串，成功获取后将被替换为目标字符串。
	 * @return bool 成功获取返回 true。
	 */
	public function try(& $string){}
	
	public function bulk(string $package = null, int $start = null, int $length = null){}
	
	public function echo(... $string){}
	
	public function print($string){}
	
	public function printf($string, ... $args){}
	
	public function vprintf($string, array $args){}
	
	public function string($string, ... $strings){}
	
	public function cast(& $string){}
	
	public function sprintf($string, ... $args){}
	
	public function vsprintf($string, array $args){}
	
	public function file($package, $filename = null){}
	
	public function locale(string $locale, string $index = null){}
	
	public function index(string $locale){}
	
	/**
	 * 遍历所有语言包。
	 * @return Generator 返回的生成器键为包名，其中 0 表示当前应用的全局语言包。返回的元素为关联数组，键为目录路径，值为包含的区域代码表。
	 */
	public static function all(){}
	
	/**
	 * 解析 lang 文件。
	 * @param string $file lang 文件名。
	 * @return array
	 */
	public static function parse(string $file){}
	
	/**
	 * 根据字符串表生成索引文件。
	 * @param string $file 字符串表文件路径。
	 * @param string $index 索引文件路径。
	 * @return int 写入的索引文件字节数。
	 */
	public static function indexes(string $file, string $index){}
	
	/**
	 * 是否就绪。
	 * @return bool
	 */
	protected function is_ready(){}
	
	/**
	 * 索引。
	 * @param string $locale 添加指定区域的语言包作为索引。
	 */
	protected function indexing(string $locale){}
	
	/**
	 * 加载索引文件。
	 * @param string $file 索引文件名。
	 * @param array $directories 语言包所在的目录。
	 * @param string $locale 区域。
	 * @param string $namespace 可选，名字空间（包名）。
	 */
	protected function load_index_file(string $file, $directories, string $locale, string $namespace = null){}
	
	/**
	 * 加载 lang 文件。
	 * @param array $directories 语言包目录及定义。
	 * @param string $locale 区域。
	 * @param string $namespace 名字空间，即包名。
	 */
	protected function load_lang_file(array $directories, string $locale, string $namespace = null){}
	
	/**
	 * 根据字符串表生成索引文件。
	 * @param string $lang 字符串表文件路径。
	 * @param string $index 索引文件路径。
	 * @param string $locale 区域。
	 * @param string $namespace 可选，名字空间，如果指定，同时加载索引。
	 */
	protected function create_index_file(string $lang, string $index, string $locale, string $namespace = null){}
	
}