<?php

/**
 * 数据库事务处理支持。
 * @author Max
 * 
 */
interface IDBTransaction extends IDBDriver
{
	/**
	 * 如果支持，开始事务。
	 * @return bool 事务是否启动，如果不支持事务，返回 false。
	 */
	public function begin();
	/**
	 * 如果支持，提交事务。
	 * @return bool 提交是否成功，如果不支持事务，返回 false。
	 */
	public function commit();
	/**
	 * 回滚事务。
	 * @return bool 回滚是否成功，如果不支持事务，返回 false。
	 */
	public function rollback();
	
	/**
	 * 快速事务处理。
	 * @param string|array|callable... $actions 一批 SQL 语句（字符串，或数组：首个元素为主 SQL，其它元素为参数）或操作（回调，当前驱动将作为参数传递，签名为：void function (IDBDriver $driver)）。
	 * @return bool 执行结果，成功提交返回 true，出错被回滚返回 false。
	 * @example transact('INSERT ...', ['UPDATE `[table]` SET `f1`=[?] WHERE ...', 1], 'DELETE ...', function (IDBDriver $driver){$driver->exec('...')}); // 执行一组 SQL 语句、SQL 宏语句或操作
	 */
	public function transact(... $actions);
}