<?php

/**
 * 将一组数组快速合并并且对象化访问。
 * 支持添加验证器和转化器。
 * <ol>
 * <li>数组的形式读取和设置原始值。</li>
 * <li>属性的形式读取验证并转化后的值。</li>
 * <li>属性赋值的形式增加验证器，例如：$obj->int = new Validator\Type('int');</li>
 * <li>属性赋值的形式增加转换器，例如：$obj->int = 'intval'; $obj->int = function($var){return intval($var);};</li>
 * </ol>
 * @author Max Wang
 * @property-write callable $oninit 初始化事件。 
 */
class obj implements ArrayAccess, Iterator, JsonSerializable
{
	/**
	 * 所有数据源。
	 * @var array
	 */
	protected $data = [[]];
	/**
	 * 键表。
	 * @var array
	 */
	protected $keys = [];
	/**
	 * 键的索引。
	 * @var array
	 */
	protected $indexes = [];
	/**
	 * 当前索引。
	 * @var integer
	 */
	protected $current = 0;
	
	protected $validators = [];
	protected $normalizers = [];
	
	/**
	 * 构造器。注意：数字索引的键将不可访问。
	 * @param array... $args 可变参数，附加的其它数据。 注意：数字索引的键将不可访问。
	 */
	public function __construct(array  ... $args){}
	
	public function __get(string $name){}
	public function __set(string $name, $var){}
	public function __isset(string $name){}
	public function __unset(string $name){}
	public function offsetExists($offset){}
	public function offsetGet($offset){}
	public function offsetSet($offset, $value){}
	public function offsetUnset($offset){}
	public function current(){}
	public function next(){}
	public function key(){}
	public function valid(){}
	public function rewind(){}
	
	/**
	 * 验证所有数据。
	 * @return array 验证出错返回错误信息，否则返回 null
	 */
	public function __invoke(){}
	
	/**
	 * 获取数组。
	 * @return array
	 */
	public function getArray(){}
	
	public function jsonSerialize(){}
	
	/**
	 * 初始化。
	 */
	protected function init(){}
}
