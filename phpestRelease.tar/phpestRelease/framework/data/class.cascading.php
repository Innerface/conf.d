<?php

abstract class Cascading extends Rowset
{
	
}