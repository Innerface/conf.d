<?php

use DB\Error;
use SQL\Writer;
use SQL\Builder;

/**
 * 数据库驱动接口。
 * @version 1.0
 * @since 1.0
 */
interface IDBDriver
{
	/**
	 * 获取数据库的设置信息。
	 * @return \Setting\DB
	 */
	public function setting();
	/**
	 * 获取状态。
	 * @return int
	 */
	public function status();
	/**
	 * 测试服务器是否正常连接。
	 * @return true
	 */
	public function ping();
	/**
	 * 驱动类型名。
	 * @return string 返回标准的名字，参考 DB 类常量。
	 * @see DB
	 * @see DB::MySQL
	 * @see DB::PostgreSQL
	 * @see DB::Orcale
	 */
	public function type();
	
	/**
	 * 获取数据库服务器的版本。
	 * @return string
	 */
	public function version();
	
	/**
	 * 实际使用的数据库内部驱动名。
	 * @return string
	 */
	public function engine();
	
	/**
	 * 获取驱动标识符，可以包含版本，格式类似于：name-v1.0.0。
	 * @return string|array 如果是一组标识符，则按顺序匹配标识符。
	 */
	public function guid();
	
	/**
	 * 获取原始连接。
	 * @return array|mixed 返回连接的引用，如果是一组连接则返回连接引用的数组。
	 */
	public function & connection();
	
	/**
	 * 执行 SQL。
	 * @param string|SQL 主语句。单语句，多语句返回错误。
	 * @return int SELECT 等返回结果集的行数，其它语句返回操作受影响的行数。
	 * 出错或无受影响的行数，或者结果集为空返回 0。
	 */
	public function exec($sql);
	
	/**
	 * 调用存储过程。
	 * @param string $name 存储过程名。
	 * @param mixed... $args 可变参数，调用参数。
	 * @return IDBDriver|int|array SELECT 等返回首个结果集，其它语句返回操作受影响的行数。
	 * 出错或无受影响的行数，或者结果集为空返回 0。
	 */
	public function call($name, ... $args);
	
	/**
	 * 获取最后的插入 ID。
	 * @return int
	 */
	public function lastInsertId();
	
	/**
	 * 分段查询。
	 * @param string $sql 查询 SQL 语句。
	 * @param string $count_sql 可选，补充的计数查询的 SQL 语句。如果主 SQL 查询提供记录总数则此 SQL 可被忽略。
	 * @param int $total 引用，输出未限定的记录总数。
	 * @return array
	 */
	public function section($sql, $count_sql = null, int & $total = 0);
	
	/**
	 * 简单获取计数。
	 * @param string $sql 可选，计数的 SQL 语句，一般使用 COUNT(*)。如果不指定则返回最后一次查询的计数值。
	 * @return int 正整数，错误返回 false。
	 */
	public function count($sql = null);
	
	/**
	 * 基本查询。
	 * @param string|SQL $sql SQL 语句。
	 * @param int $seek 可选，要跳过的行数。
	 * @param int $length 可选，行数，默认全部。
	 * @param int $type 可选，结果集类型：DB::NUM, DB::ASSOC, DB::BOTH, DB::OBJECT。
	 * @return int|array SELECT 语句返回查询结果，其它返回受影响的行数。
	 */
	public function query($sql, int $seek = 0, int $length = null, int $type = DB::ASSOC);
	
	/**
	 * 多结果集查询。
	 * @param string|SQL|array $sqls SQL 语句组。
	 * @param int $type 可选，结果集类型。
	 * @return array
	 */
	public function bulk($sqls, int $type = DB::ASSOC);
	
	/**
	 * 获取数据集：多个行集。
	 * @param string... $sqls SQL 语句集。
	 * @return array 返回三维数组。
	 */
	public function dataset(... $sqls);
	
	/**
	 * 获取行集。
	 * @param string $sql SQL 语句。
	 * @param int $seek 可选，要跳过的行数。
	 * @param int $length 可选，要提取的行数。默认为全部。
	 * @return array 返回二维数组。
	 */
	public function rowset($sql, int $seek = 0, int $length = null);
	
	/**
	 * 获取一行。
	 * @param string $sql SQL 语句。
	 * @param int $seek 可选，要跳过的行数。
	 * @return array 返回键值对数据。
	 */
	public function row($sql, int $seek = 0);
	
	/**
	 * 获取某个列。
	 * @param string $sql SQL 语句。
	 * @param int|string $index 可选，列号或列名。
	 * @return array
	 */
	public function column($sql, $index = 0);
	
	/**
	 * 获取首行首列。
	 * @param string $sql SQL 语句。
	 * @return scalar
	 */
	public function first($sql);
	
	/**
	 * 行列转置查询。
	 * @param string $sql SQL 语句。一般使用默认的键名（即使实际使用的字段跟默认的不同，也可以使用别名指定）。
	 * @param string $key_field 可选，键列字段名称。默认为 key。
	 * @param string $value_field 可选，值列字段名称。默认为 value。
	 * @param string $type_field 可选，类型定义列字段名称。默认为 type。
	 * @param string $namespace_field 可选，名字空间列字段名称。默认为 namespace。如果指定为 null，则忽略。
	 * @param string $comment_field 可选，注释列字段名称。默认为 comment。如果指定为 null，则忽略。
	 * @return array|Generator
	 */
	public function transpose($sql, string $key_field = 'key', string $value_field = 'value', string $type_field = 'type', string $namespace_field = 'namespace', string $comment_field='comment');
	
	/**
	 * 实体数据转置。
	 * @param string $sql SQL 语句。
	 * @param string $key_field 可选，键列字段名称。默认为 key。
	 * @param string $value_field 可选，值列字段名称。默认为 value。
	 * @return array|Generator
	 */
	public function entity($sql, string $key_field = 'key', string $value_field = 'value');
	
	/**
	 * 获取所有执行过的 SQL 语句（包括 SQL 语句，错误信息和执行时间）。
	 * @return array
	 */
	public function recent();
	
	/**
	 * 获取最后执行的 SQL 语句（包括 SQL 语句，错误信息和执行时间）。
	 * @return object 返回最后一次执行的SQL语句的历史记录。
	 */
	public function last();
	
	/**
	 * 测试当前驱动支持的 SQL 语句。
	 * @param string|array $statements 可选，语句名（大写），支持数组。
	 * @param string|array $schemes 可选，支持的逻辑架构名。
	 * @return bool 支持返回 true。
	 * @example support(['SELECT', 'UPDATE', 'DROP', 'CREATE TABLE'], ['db1', 'db2'])
	 */
	public function support($statements = null, $schemes = null);
	
	/**
	 * 返回最后的错误信息，包含的信息：level 错误级，error 错误号，message 错误信息，sql 错误的 SQL 语句。
	 * @return DB\Error 没有错误返回 null。
	 */
	public function error();
	/**
	 * 返回最后的警告信息。
	 * @return array 可能有多条。
	 */
	public function warnings();
	/**
	 * SQL 语句重写。
	 * @param string $sql SQL 语句。
	 * @param array $context 可选，数据上下文。
	 * @return string
	 */
	public function rewrite($sql, $context = null);
	
	/**
	 * 获取一个驱动默认的 SQL 编写器。
	 * @return SQL\Writer
	 */
	public function writer();
	/**
	 * 创建一个驱动默认的 SQL 构造器。
	 * @param string ... $sql 可变参数，SQL 语句。
	 * @return SQL\Builder
	 */
	public function builder();
	/**
	 * 设置上下文数据供查询转义使用。
	 * @return self
	 */
	public function context($context);
	/**
	 * 获取物理名字。
	 * @param string $name 逻辑名。
	 * @param array|object $context 可选，上下文数据。映射程序使用上下文数据推断要使用的物理名字。
	 * 如果此参数未设置则采用 self::context() 方法设置的数据上下文。
	 * @return string
	 */
	public function map(string $name, $context = null);
	/**
	 * 把逻辑标识符加上逻辑标识。
	 * @param string $name 逻辑名。禁止使用特殊字符：各种引号、括号、分隔符和控制字符。
	 * @return string
	 * @example name('name') // 返回 `[name]`
	 */
	public function name(string $name);
}
