<?php

/**
 * 数据集。
 * @author Max Wang
 * 
 */
abstract class DataSet
{
	
}