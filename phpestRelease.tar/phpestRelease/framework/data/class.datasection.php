<?php

/**
 * 分段的行集。
 * @author Max
 * 
 */
abstract class DataSection extends Rowset
{
	/**
	 * 获取总的记录数量（未分段的）。
	 * @return int
	 */
	public function total(){}
}