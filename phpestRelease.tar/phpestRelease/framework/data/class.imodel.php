<?php

/**
 * 数据模型。
 * @author Max
 * 
 */
interface IModel
{
	/**
	 * 验证。
	 * @param bool $integrated 可选，是否验证完整性，如果设置为 false
	 * 则忽略必要性验证和数据中未包含的项目，仅检查已设置（isset）的数据项。 
	 * @param array $error 引用，可选，输出错误信息。
	 * @return bool
	 */
	public function validate($integrated = true, array & $error = null);
	/**
	 * 规范化数据，以使数据符合期望。
	 * 注意：不符合验证规则的数据将被规范化为初始值或默认值。
	 * @param bool $integrated 可选，完整性，是否包含全部项目，为 true 
	 * 时如果提供的数据不符合验证规则或预期则初始化为默认值。否则仅规范化已设置（isset）的数据项。
	 * @return void
	 */
	public function normalize($integrated = true);
}