<?php

namespace Setting;

/**
 * 模块的设置。
 * @author Max Wang
 * @property array $db 数据库映射配置。
 * @property array $services 服务的配置。
 * @property array $args 模块的构造参数。
 * @method self db(array $db) 设置数据库映射，键为模块内部数据驱动名，值为应用定义的驱动名。
 * @method self services(array $services) 服务的设置。
 */
class Module extends \Setting
{
	protected $db;
	protected $services;
	
	/**
	 * 构造模块设置。
	 * @param array $db 数据库配置。
	 */
	public function __construct(array $db = null, ...$args){}
	
	/**
	 * 服务的设置。
	 * @param string $name 服务名。
	 * @param array $args 服务的构造参数。
	 * @param array $properties 服务的属性。
	 * @return self
	 */
	public function service(string $name, array $args, array $properties = null){}
}