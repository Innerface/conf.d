<?php

/**
 * 数据提供者。
 * @author Max Wang
 */
trait DataProvider
{
	/**
	 * 获取数据源。
	 * @param string $name 数据源名。
	 * @return IDataSource|null
	 */
	public function data(string $name){}
	
	/**
	 * 加载定义。
	 * @param string $name 名字。
	 * @param string $type 类型。
	 * @return IDataSource
	 */
	abstract protected function load(string $name, string $type);
}