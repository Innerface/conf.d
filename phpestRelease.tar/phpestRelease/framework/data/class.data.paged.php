<?php

namespace Data;

/**
 * 分页数据包。
 * @author Max Wang
 * 
 */
class Paged extends Pack
{
	/**
	 * 页号。
	 * @var int
	 */
	public $number;
	/**
	 * 每页的记录数量。
	 * @var int
	 */
	public $size;
	/**
	 * 结果集总记录数。
	 * @var int
	 */
	public $total;
	
	/**
	 * 分页数据包。
	 * @param mixed $data 源数据。
	 * @param string $type 可选，数据类型。不指定则自动探测源数据的类型。
	 * @param int $number 页号，基于 1 的页号。
	 * @param int $total 可选，总记录数。
	 * @param int $size 可选，页容量，默认为 10。
	 */
	public function __construct($data, string $type = null, int $number = null, int $total = null, int $size = null){}
	
	/**
	 * 设置页号。
	 * @param int $number 页号。
	 * @return self
	 */
	public function number(int $number){}
	
	/**
	 * 设置总记录数。
	 * @param int $total 总记录数。
	 * @return self
	 */
	public function total(int $total){}
	
	/**
	 * 设置页容量。
	 * @param int $size 页容量。
	 * @return self
	 */
	public function size(int $size){}
}
