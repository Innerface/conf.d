<?php

/**
 * 数据库行集。
 * @author Max Wang
 * 
 */
class Row implements ArrayAccess, Countable, IteratorAggregate, JsonSerializable
{
	protected $data;
	
	public function __construct(array $data = null){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	/**
	 * 返回源数据的引用。
	 * @return array
	 */
	public function & __invoke(){}
	
	public function count(){}
	
	public function offsetExists($offset){}
	
	public function offsetGet($offset){}

	public function offsetSet($offset, $value){}
	
	public function offsetUnset($offset){}
	
	/**
	 * 获取原始数据。
	 * @return array
	 */
	public function data(){}
	
	public function jsonSerialize(){}
	
	public function getIterator(){}
}