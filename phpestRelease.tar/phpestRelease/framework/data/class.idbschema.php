<?php

/**
 * 数据架构及信息提供者。
 * @author Max
 * 
 */
interface IDBSchema extends IDBDriver
{
	/**
	 * 数据信息。
	 * @param string $name 实体名（逻辑表名）。
	 * @return array 键为列名，值为列定义，列的定义包括通用属性和类型相关扩展属性，通用属性包括：<ol>
	 * <li>default SQL 默认值，SQL 表达式。</li>
	 * <li>nullable bool 是否可为空。</li>
	 * <li>primary_key bool 是否为主键。</li>
	 * <li>uniqued bool 是否为唯一键。</li>
	 * <li>required bool 是否必要项：必须是自动项，或有输入值，或有默认值。</li>
	 * <li>auto bool 是否为自动计算的列。</li>
	 * <li>label string 标签。</li>
	 * <li>hint string 键入或输入内容相关的提示文本，怎样输入，例如：仅限字母数字和下划线。</li>
	 * <li>description string 实际的数据用途说明文本，业务用途，例如：用户名。</li>
	 * <li>groupable bool 支持分组。</li>
	 * <li>sortable bool 支持排序。</li>
	 * <li>ignored bool 忽略，不要处理。</li>
	 * <li>filter string 筛选规则。</li>
	 * <li>type string 数据类型，可用值：bool, bit, int, float, decimal, year, time, date, datetime, timestamp, string, text, json, binary, enum, set。
	 * </li>
	 * </ol>
	 * 类型相关扩展属性如下：<ol>
	 * <li>type=bool，布尔，扩展的定义为：text: array('false', 'true')</li>
	 * <li>type=bit，位域，扩展的定义为：length: int, options: array(bit1, bit2, bit3, ...), text: array(text1, text2, text3, ...)</li>
	 * <li>type=int，整型，扩展的定义为：length, min, max, unsigned</li>
	 * <li>type=float，浮点，扩展的定义为：length, precision, min, max, unsigned</li>
	 * <li>type=decimal，定点小数，扩展的定义为：length, precision, min, max, unsigned</li>
	 * <li>type=year，无扩展的定义</li>
	 * <li>type=time，无扩展的定义</li>
	 * <li>type=date，无扩展的定义</li>
	 * <li>type=datetime，无扩展的定义</li>
	 * <li>type=timestamp，无扩展的定义</li>
	 * <li>type=enum，扩展的定义为：options: array(e1, e2, e3, e4, ...), text: array(text1, text2, text3, ...)，文本为字符串标识号。</li>
	 * <li>type=set，扩展的定义为：options: array(e1, e2, e3, e4, ... max-length=64/32), text: array(text1, text2, text3, etc.)，文本为字符串标识号。</li>
	 * <li>type=json，扩展的定义：class: 类名，无类名解析为stdClass，未指定解析为数组。</li>
	 * <li>type=string，短文本扩展定义：secure: bool 加密的, hashed: bool 散列处理的, indexed: bool 索引的 , locale: string 适用到的本地区域代码，
	 * length: int 定义的长度, min,max: int（限定的最短和最长长度），pattern: string 模式名或正则表达式（首字符为~表示正则表达式）。</li>
	 * <li>type=text，长文本扩展定义：locale: string 适用到的本地区域代码，format: string [plain|xml|html|json|phpx|csv|ini|css|js|qs|etc.]，
	 * phpx 表示序列化的 PHP 数据，qs 表示编码的 URL 查询字符串，如果是 MIME (如：text/javascript)则尝试查找相关的解码器处理。</li>
	 * <li>type=binary，扩展的定义为：length:int（0 表示不限长度），mime: string[任意mime]</li>
	 * </ol>
	 */
	public function desc($name);
	
	/**
	 * 获取数据库架构。
	 * @param string $scheme 逻辑架构名。
	 * @return \data\Schema
	 */
	public function schema(string $schema);
}