<?php

namespace Data;

/**
 * 数据包。
 * @author Max Wang
 * 
 */
class Pack implements \IDataPack
{
	protected $_;
	protected $__;
	
	/**
	 * 分页数据包。
	 * @param mixed $data 源数据。
	 * @param string $type 可选，数据类型。不指定则自动探测源数据的类型。
	 */
	public function __construct($data, string $type = null){}
	
	/**
	 * 数据。
	 * @return mixed
	 */
	public function data(){}
	
	public function setData($data, string $type = null){}
	
	/**
	 * 获取数据的类型。
	 * @return string|null
	 */
	public function type(){}
	
	public function __call(string $name, array $args = null){}
}
