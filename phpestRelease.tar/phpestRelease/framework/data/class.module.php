<?php

/**
 * 模块。以属性的方式获取或配置服务。
 * @example $service = $module->service; // 获取名为 service 的服务
 * @example $module->service = ['Demo', ...]; // 设置名为 $service 的服务
 * @author Max Wang
 */
abstract class Module
{
	/**
	 * 服务表。
	 * 键值对，键为服务名，值为服务类名。
	 * 未提供服务名则将服务类名转为驼峰命名样式。
	 * @var array 
	 * @example ['Module\\Name\\Demo'] Module\Name\Demo 服务名为 moduleNameDemo
	 * @example ['demo'=> 'Module\\Name\\Demo'] Module\Name\Demo 服务名为 demo
	 */
	const SERVICEs = null;
	/**
	 * 默认的数据库内部驱动名。
	 * @var string
	 */
	const DEFAULT = 'default';
	
	/**
	 * 定义模块的应用。
	 * @var app
	 */
	protected $app;
	/**
	 * 数据库驱动的映射。
	 * @var array
	 */
	protected $db = [];
	/**
	 * 服务。
	 * @var array
	 */
	protected $services;
	
	/**
	 * 构建服务管理器。
	 * @param app $app 当前应用。
	 * @param array $db 可选，数据库配置的映射（键为当前模块内部使用的数据库驱动名，值为实际的数据库驱动名，由全局的数据库管理器管理）。
	 * @param array $services 可选，服务的设置。
	 * @param mixed ... $args 其它参数。
	 */
	public final function __construct(app $app, array $db = null, array $services = null, ... $args){}
	
	public function __get(string $name){}
	
	public function __isset(string $name){}
	
	/**
	 * 是否存在指定的数据库驱动。
	 * @param string $name 驱动名。
	 * @return boolean
	 */
	public function has(string $name = null){}
	
	/**
	 * 获取数据库驱动。
	 * @param string $name 模块内部的数据库驱动名。
	 * @throws NotFoundException 未找到指定的数据库驱动。
	 * @return IDBDriver
	 */
	public function db(string $name = null){}
	
	/**
	 * APP
	 * @return app
	 */
	public function app(){}
	
	/**
	 * 初始化模块。
	 * @param mixed ... $args 可变参数，配置参数。除数据库、服务配置数据外的其它构造参数依序传递到此方法。
	 */
	protected function init(...$args){}
	
	/**
	 * 加载服务。
	 * @param string $name
	 * @return IService|null
	 */
	protected function service(string $name){}
}
