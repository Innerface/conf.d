<?php

/**
 * 数据源。
 * @author Max
 * 
 */
interface IDataSource
{
}