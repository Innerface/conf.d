<?php

/**
 * 行集：二维数据表。
 * @author Max
 * 
 */
class Rowset implements ArrayAccess, Countable, Iterator, JsonSerializable
{
	/**
	 * 数据总数量。
	 * @var int
	 */
	public $total;
	/**
	 * 页容量。
	 * @var int
	 */
	public $size;
	/**
	 * 当前页号，基于 1。
	 * @var int
	 */
	public $page;
	
	protected $_;
	protected $__;
	protected $___ = 0;
	
	/**
	 * 构造行集。
	 * @param array $data 数据。
	 * @param int $total 可选，行集总数。
	 * @param int $size 可选，如果是分页查询的结果集，可选的设置分页尺寸。
	 */
	public function __construct(array $data = null, int $total = null, int $size = null, int $page = null){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	/**
	 * 返回源数据的引用。
	 * @return array
	 */
	public function & __invoke(){}
	
	/**
	 * 数据记录数量。
	 * @return int
	 */
	public function count() : int{}
	
	/**
	 * 获取记录总数量。
	 * @return int
	 */
	public function total() : int{}
	
	public function offsetExists($offset){}
	
	public function & offsetGet($offset){}
	
	public function offsetSet($offset, $value){}
	
	public function offsetUnset($offset){}
	
	public function current(){}
	
	public function next(){}
	
	public function key(){}
	
	public function valid(){}
	
	public function rewind(){}
	
	public function append($row){}
	
	/**
	 * 获取原始数据。
	 * @return array
	 */
	public function data(){}
	
	public function jsonSerialize(){}
}