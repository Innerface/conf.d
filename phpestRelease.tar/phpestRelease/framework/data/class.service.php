<?php

/**
 * 服务基类。服务提供这样的特性：
 * <ol>
 * <li>数据架构定义，以独立的类文件定义。</li>
 * <li>获取数据源和数据操作。
 * 	<ol>
 * 		<li>使用常量 DIRECTORY 定义数据操作所在的子目录名。</li>
 * 		<li>使用常量 MANIFEST 定义数据操作清单及映射使用的数据库驱动名（在服务中定义的）。</li>
 * 		<li>在数据操作目录中定义操作加载器(*.php)，通过操作加载器返回数据操作项或数据。</li>
 * 		<li>操作加载器直接返回数据，或者返回闭包，再通过闭包加载数据操作或 SQL 对象。</li>
 * 	</ol>
 * </li>
 * </ol>
 * @author Max Wang
 */
abstract class Service implements IService, IPathProvider
{
	use PathProvider;
	
	/**
	 * 功能目录名。
	 * @var string
	 */
	const DIRECTORY = 'data';
	/**
	 * 清单：定义数据源和映射。
	 * @var array 键为字符串，表示操作或数据源名，值为字符串，表示使用的数据库驱动。
	 */
	const MANIFEST = null;
	
	/**
	 * 操作的数据。
	 * @var array
	 */
	protected $data;
	
	/**
	 * 清单。
	 * @var array
	 */
	protected $manifest;
	
	/**
	 * 服务所属的模块。
	 * @var Module
	 */
	protected $module;
	
	/**
	 * 构造服务。
	 * @param Module $module 服务所属的模块。
	 * @param mixed ... $args 构造参数。
	 */
	public final function __construct(Module $module, ... $args){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	public function __call(string $name, array $args = null){}
	
	public function __invoke() : Module{}
	
	/**
	 * 初始化。
	 * @param mixed ... $args 配置的构造参数。
	 */
	protected function _init(...$args){}
	
	/**
	 * 加载操作。
	 * @param string $name 操作名。
	 * @param array $data 可选，键值对数据。
	 * @param array $args 可选，参数数据。
	 * @return mixed
	 */
	protected function _(string $name, array $data = null, array $args = null){}
}
