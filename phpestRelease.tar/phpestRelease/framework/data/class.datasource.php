<?php

/**
 * 数据源基类。
 * @author Max
 * 
 */
abstract class DataSource implements IDataSource
{
	use TSetter, TGetter;
	
	protected $_;
	
	public abstract function __invoke();
}