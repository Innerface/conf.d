<?php

/**
 * 数据包装类。
 * @author Max Wang
 * 
 */
interface IDataPack
{
	/**
	 * 数据。
	 * @return mixed
	 */
	public function data();
	/**
	 * 设置数据。
	 * @param mixed $data 数据。
	 * @param string $type 可选，指定类型。
	 */
	public function setData($data, string $type = null);
}