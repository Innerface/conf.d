<?php

namespace Service;

use IService;
use IDBDriver;

/**
 * 服务操作行为加载器。	
 * @author Max Wang
 * 
 */
class Loader extends \Loader
{
	/**
	 * 数据库驱动。
	 * @var \IDBDriver
	 */
	public $driver;
	/**
	 * 调用的入口参数。
	 * @var array
	 */
	public $args;
	
	public function __construct(string $name, string $file, IService $service, IDBDriver $driver = null, array $context = null){}
}