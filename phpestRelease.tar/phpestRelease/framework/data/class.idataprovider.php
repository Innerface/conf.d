<?php

/**
 * 数据源提供者。
 * @author Max
 * 
 */
interface IDataProvider
{
	/**
	 * 获取数据源。
	 * @param string|int $name 数据源名字。
	 * @return IDataSource
	 */
	public function data(string $names);
}
