<?php

/**
 * 批量执行支持。
 * @author Max
 * 
 */
interface IDBBatch extends IDBDriver
{
	/**
	 * 启动批量操作模式，合并大批 SQL 操作一次性提交，节约连接资源。
	 * @return bool 支持批量操作返回 true，否则返回 false。
	 */
	public function start();
	
	/**
	 * 快速批量执行。
	 * @param string... $sqls 要批量执行的所有 SQL 语句。
	 * @return IDBBatch $this 使用驱动的 error 方法获取错误。
	 */
	public function batch(... $sqls);
	/**
	 * 提交批量执行。
	 * @return bool
	 */
	public function submit();
}
