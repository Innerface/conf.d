<?php

/**
 * 数据模型基类。
 * @author Max
 * 
 */
abstract class Model implements IModel
{
	/**
	 * 构造模型。
	 */
	public function __construct(){}
	
	public function __clone(){}
	
	protected function init(){}
	
	public function validate($integrated = true, array & $error = null){}
	
	public function normalize($integrated = true){}
	
	public function schema(){}
}