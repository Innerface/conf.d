<?php

/**
 * 服务。
 * @author Max
 * 
 */
interface IService
{
	/**
	 * 返回所属的模块。
	 * @return Module
	 */
	public function __invoke() : Module;
}