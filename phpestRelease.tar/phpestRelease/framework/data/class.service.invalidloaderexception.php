<?php

namespace Service;

class InvalidLoaderException extends \Exception
{
	/**
	 * 服务。
	 * @var \IService
	 */
	public $service;
	/**
	 * 加载器文件路径。
	 * @var string
	 */
	public $file;
	/**
	 * 加载器名。
	 * @var string
	 */
	public $name;
	
	public function __construct(string $file = null, $name = null, \IService $service = null, $message = null, $code = null, $previous = null){}
}