<?php

/**
 * 数据库驱动管理器。可以直接使用属性获取或设置命名的连接或别名，
 * 比如 $db->test 获取名字为 test 的数据库连接驱动，不存在则为 null。
 * 数据库可以分组使用。
 * @author Max
 * @example 使用属性定义别名：$db->demo = 'test'; // demo 是 test 的别名。可以使用 unset($db->demo) 删除这个别名。
 * @example 使用属性定义别名：$db->demo = new MySQL(); // demo 是一个新的 MySQL 数据库驱动。
 * @example 使用属性定义别名：$db->demo = ['MySQL', 'localhost', 'user', 'xxxxx']; // demo 是一个新的 MySQL 数据库驱动。
 * @example 获取连接信息：$conn = $db->demo; // 获取连接信息
 * @property Setting\DB $default 默认的驱动配置。
 */
class DB implements IPlugIn
{
	const MySQL = 'mysql';
	const PostgreSQL = 'pgsql';
	const Oracle = 'oracle';
	const MSSQL = 'mssql';
	const SQLite = 'sqlite';
	const DB2 = 'db2';
	const Informix = 'informix';
	const Sybase = 'sybase';
	const MSAccess = 'access';
	
	/**
	 * 数据结果集类型：多行集数据集带关系定义。
	 * @var array
	 */
	const DATASET = 0;
	/**
	 * 数据结果集类型：行集（仅取首个结果集）。
	 * @var array
	 */
	const ROWSET = 0;
	/**
	 * 数据结果集类型：首行（仅取首个结果集的首行）。
	 * @var array
	 */
	const ROW = 1;
	/**
	 * 数据结果集类型：首列（仅取首个结果集的首列）。
	 * @var scalar
	 */
	const COLUMN = 2;
	/**
	 * 数据结果集类型：首行首列（仅取首个结果集的首行首列）。
	 * @var scalar
	 */
	const FIRST = 3;
	
	/**
	 * 结果集键类型：文本关联。
	 * @var int
	 */
	const ASSOC = 0;
	/**
	 * 结果集键类型：整数。
	 * @var int
	 */
	const NUM = 1;
	/**
	 * 结果集键类型：两种皆有。
	 * @var int
	 */
	const BOTH = 2;
	/**
	 * 结果集键类型：对象属性，也可以使用数组形式访问。
	 * @var int
	 */
	const OBJECT = 3;
	
	/**
	 * 驱动状态：关闭。
	 * @var int
	 */
	const CLOSE = 0;
	/**
	 * 驱动状态：就绪。
	 * @var int
	 */
	const READY = 1;
	/**
	 * 驱动状态：事务处理中。
	 * @var int
	 */
	const PENDING = 2;
	/**
	 * 驱动状态：批处理状态。
	 * @var int
	 */
	const BULK = 4;
	/**
	 * 驱动状态：故障，本次操作发生错误或警告，但服务器仍可接受继续操作。
	 * @var int
	 */
	const FAILED = 0x100;
	/**
	 * 驱动状态：故障，服务器发生错误不能继续，必须处理后才能继续。
	 * @var int
	 */
	const FAULT = 0x200;
	/**
	 * 驱动状态：故障，出错连接不上。
	 * @var int
	 */
	const GONE = 0x400;
	
	/**
	 * 错误级别：错误，执行失败。
	 * @var int
	 */
	const ERROR = 1;
	/**
	 * 错误级别：警告，执行成功，但是有问题。
	 * @var int
	 */
	const WARNING = 2;	
	
	/**
	 * 不能连接到 MySQL 服务器时的处理方式：引发运行时异常。
	 * @var int
	 */
	const GONE_EXCEPTION = 0;
	/**
	 * 不能连接到 MySQL 服务器时的处理方式：记录错误并退出流程。
	 * @var int
	 */
	const GONE_QUIT = 1;
	/**
	 * 不能连接到 MySQL 服务器时的处理方式：记录错误并返回 false。
	 * @var int
	 */
	const GONE_FALSE = 2;
	
	/**
	 * 默认驱动名。
	 * @var string
	 */
	const DEFAULT = 'default';
	/**
	 * 默认驱动类型。
	 * @var string
	 */
	const DRIVER = 'MySQL\\Driver';
	
	/**
	 * 全部数据库连接，包括别名。
	 * @var array
	 */
	protected $conns;
	
	/**
	 * 构造数据库管理器。
	 * @param array $conns 可选，连接配置。如果不提供则自动从配置文件加载。
	 */
	public function __construct(array $conns = null){}
	
	public function __get(string $name){}
	
	public function __set(string $name, $value){}
	
	public function __isset($name){}
	
	public function __unset($name){}
	
	/**
	 * 返回数据库驱动器，注意：仅有一个驱动器时始终返回它。
	 * @param string $name 可选，连接名。不指定连接名则返回默认连接（default）或首个连接（default 不存在时）。
	 * @return IDBDriver 返回数据库连接的引用。
	 */
	public function driver($name = null){}
	
	public function & __invoke($name = null){}
	
	public function isSingleton(): bool{}
	
	public function debugInfo(){}
	
	/**
	 * 创建驱动。
	 * @param Setting\DB|array $setting 驱动配置。
	 * @return IDBDriver|null
	 */
	protected function create($setting){}
	
	/**
	 * 创建数据库设置。
	 * @param array $setting 可选，数据库设置。
	 * @return DB\Setting
	 */
	public static function setting(array $setting = null){}
}
