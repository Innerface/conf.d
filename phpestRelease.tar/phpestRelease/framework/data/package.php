<?php

/**
 * 将一组数组快速组合并并且对象化访问。
 * 支持添加验证器和转化器。
 * <ol>
 * <li>数组的形式读取和设置原始值。</li>
 * <li>属性的形式读取验证并转化后的值。</li>
 * <li>属性赋值的形式增加验证器，例如：$obj->int = new Validator\Type('int');</li>
 * <li>属性赋值的形式增加转换器，例如：$obj->int = 'intval'; $obj->int = function($var){return intval($var);};</li>
 * </ol>
 * @param array... $data 引用，可变参数，附加的其它数据。 注意：数字索引的键将不可访问。
 * @return obj
 */
function obj(array & ... $data){}
