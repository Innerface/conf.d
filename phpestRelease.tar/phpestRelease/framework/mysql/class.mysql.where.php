<?php

namespace MySQL;

/**
 * WHERE 语句。
 * @author Max
 * 
 */
class WHERE extends \MySQL
{
	
}