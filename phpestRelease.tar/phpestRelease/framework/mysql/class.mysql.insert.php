<?php

namespace MySQL;

use MySQL;

/**
 * MySQL 插入语句。
 * @author Max Wang
 * 
 */
class INSERT extends MySQL
{
	const PRIORITY = 0;
	const IGNORE = 1;
	
	const DATA = 9;
	
	const SYNTAX = [
		'INSERT' => '',
		self::PRIORITY => null,
		self::IGNORE => null,
		'INTO' => null,
		'PARTITION' => null,
		self::DATA => true,
		'ON DUPLICATE KEY UPDATE' => null,
	];
	
	/**
	 * MySQL 插入语句构建工具。
	 * @param string $table 逻辑表名。
	 */
	public function __construct(string $table = null){}
	
	/**
	 * 设置语句的执行优先级：低优先级。
	 * @return \MySQL\INSERT
	 */
	public function LOW_PRIORITY(){}
	
	/**
	 * 设置语句的执行优先级：延迟。
	 * @return \MySQL\INSERT
	 */
	public function DELAYED(){}
	
	/**
	 * 设置语句的执行优先级：高优先级。
	 * @return \MySQL\INSERT
	 */
	public function HIGH_PRIORITY(){}
	
	/**
	 * 当数据已存在时忽略。
	 * @return \MySQL\INSERT
	 */
	public function IGNORE(){}
	
	/**
	 * 目标表名。
	 * @param string $table 表名。注意：为逻辑表名，不需要加定界符。
	 * @param bool $escaped 可选，表名是否已转为物理名。
	 * @return \MySQL\INSERT
	 * @example INTO('tablename PARTITION 1,2,3,4')
	 */
	public function INTO(string $table){}
	
	/**
	 * 设置要插入的数据分布分区。
	 * @param mixed... $partition 分区表。
	 * @return \MySQL\INSERT
	 */
	public function PARTITION(...$partition){}
	
	/**
	 * 数据包装为 SET 形式。
	 * @param array $data 源数据。
	 * @return \MySQL\INSERT
	 */
	public function SET(array $data){}
	
	/**
	 * 数据包装为来自于 SELECT 语句源。 
	 * @param string|array $fields 字段。
	 * @param string|SELECT $select SELECT 语句。
	 * @return \MySQL\INSERT
	 */
	public function SELECT($fields, $select){}
	
	/**
	 * 数据包装为 INSERT 的 VALUES 形式。
	 * @param array|object $data 数组。
	 * @return \MySQL\INSERT
	 */
	public function VALUES($data){}
	
	/**
	 * 扩展语句：ON DUPLICATE KEY UPDATE
	 * @param array $data 
	 * @return \MySQL\INSERT
	 */
	public function ON_DUPLICATE_KEY_UPDATE($data){}
}