<?php

namespace MySQL;

/**
 * MySQL DELETE 语句编写器。
 * @author Max Wang
 * 
 */
class DELETE extends \MySQL
{
	
}