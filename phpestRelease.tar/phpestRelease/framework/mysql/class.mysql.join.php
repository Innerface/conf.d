<?php

namespace MySQL;

/**
 * JOIN 连接语句。
 * @author Max
 *
 */
class JOIN extends \MySQL
{
	protected $main;
	
	public function __construct(\MySQL $main){}
}