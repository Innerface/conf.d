<?php

namespace MySQL;

/**
 * SELECT 语句。
 * @author Max
 * 
 */
class SELECT extends \MySQL
{
	const JOIN = 1;
	const LAST = 99;
	
	const SYNTAX = [
		'SELECT' => '*',
		'FROM' => null,
		'PARTITION' => null,
		self::JOIN => null,
		'WHERE' => null,
		'GROUP BY' => null,
		'HAVING' => null,
		'ORDER BY' => null,
		'LIMIT' => null,
		self::LAST => null,
		'UNION' => null,
	];
	
	/**
	 * 语句锚。
	 * @var WHERE
	 */
	protected $_anchor;
	
	/**
	 * 构造器。
	 * @param string|array $fields 字段表。
	 * @param bool $sqlCalcFoundRows 可选，计算找到的行数。
	 * @param string $distinct 可选，DISTINCT 选项，可选值：ALL(null), DISTINCT(true) 和 DISTINCTROW(false).可以使用对应的 bool 值。
	 * @param bool $highPriority 可选，高优先级。
	 * @param int $maxStatementTime 可选，最大语句执行超时时间，单位：毫秒。
	 * @param bool $straightJoin 可选，强制优化 JOIN 策略。 
	 * @param bool $sqlSmallResult 可选，小结果集优化。
	 * @param bool $sqlBigResult 可选，大结果集优化。
	 * @param bool $sqlBufferResult 可选，强制结果集放入临时表，释放表锁。
	 * @param bool $sqlCache 可选，查询缓存是否开启。
	 */
	public function __construct($fields, $sqlCalcFoundRows = null, $distinct = null, $highPriority = null, int $maxStatementTime = 0, $straightJoin = null, $sqlSmallResult = null, $sqlBigResult = null, $sqlBufferResult = null, $sqlCache = null){}
	
	public function __call(string $name, array $args = null){}
	
	/**
	 * FROM 子句。
	 * @param string $from 表引用，注意，此处要使用逻辑表名。
	 * @param string $alias 可选，别名。
	 * @return self
	 */
	public function FROM(string $from, string $alias = null){}
	
	/**
	 * 设置要插入的数据分布分区。
	 * @param mixed... $partition 分区表。
	 * @return self
	 */
	public function PARTITION(...$partition){}
	
	public function JOIN($direction, $outer){}
	
	public function CROSS_JOIN($table_factor, $conditional_expr_or_column_list = null){}
	
	public function INNER_JOIN($table_factor, $conditional_expr_or_column_list = null){}
	
	/**
	 * 直接连接。
	 * @param string $table_factor 表引用。
	 * @param on $conditional_expr 可选，条件表达式。
	 * @return self
	 */
	public function STRAIGHT_JOIN($table_factor, $conditional_expr = null){}
	
	/**
	 * WHERE 子句。
	 * @param array $args 可变参数，宏表达式。当参数为普通字符串时直接连接，如果为数组，则视为宏语句组。
	 * 宏语句组的首个元素为宏表达式，参考 SQL::format 方法。其它元素为参数表。如果参数表为空则该语句组将被忽略。
	 * @return self
	 * @see \SQL::format
	 * @example WHERE('`id`=1', ['AND', '`id`=[?]', $this->id]])
	 */
	public function WHERE(... $args){}
	
	/**
	 * 联合。
	 * @param string|SELECT $select 其它 MySQL SELECT 语句，如果是字符串，则为宏表达式。
	 * @param array $args 可选，宏变量。
	 * @return self
	 */
	public function UNION($select, array $args = null){}
	
	/**
	 * GROUP BY 子句。
	 * @param string|array $expression 宏表达式。
	 * @param array 可选，宏参数。
	 * @return self
	 */
	public function GROUP_BY($expression, array $args = null){}
	
	/**
	 * HAVING 子句。
	 * @param string $expression 条件子句。
	 * @param array $args 可选，宏参数。
	 * @return self
	 */
	public function HAVING(string $expression, array $args = null){}
	
	/**
	 * ORDER BY 子句。
	 * @param string|\SQL ...$expressions 可变参数，排序表达式。
	 * @example ORDER_BY('`age` DESC', '`rate` ASC')
	 * @return self
	 */
	public function ORDER_BY(...$expressions){}
	
	/**
	 * LIMIT 子句。
	 * @param int $row_count 限定的结果集行数。
	 * @param int $offset 可选，偏移的行号。
	 * @return self
	 */
	public function LIMIT(int $row_count, int $offset = 0){}
	
	/**
	 * 扩展语句：FOR UPDATE
	 * @return self
	 */
	public function FOR_UPDATE(){}
	
	/**
	 * 扩展语句：LOCK IN SHARE MODE
	 * @param bool $unset 可选，如果为 true 则表示移除锁表。
	 * @return self
	 */
	public function LOCK(bool $unset = false){}
}