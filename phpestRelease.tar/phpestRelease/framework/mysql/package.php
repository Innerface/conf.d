<?php

namespace
{
	use MySQL\SELECT;
	use MySQL\INSERT;
  use MySQL\_;
	
	return [
		'use' => ['system.db'],
	];
	
	/**
	 * SELECT 构造器。
	 * @param string|array $fields 字段表。
	 * @param bool $sqlCalcFoundRows 可选，计算找到的行数。
	 * @param string $distinct 可选，DISTINCT 选项，可选值：ALL(null), DISTINCT(true) 和 DISTINCTROW(false).可以使用对应的 bool 值。
	 * @param bool $highPriority 可选，高优先级。
	 * @param int $maxStatementTime 可选，最大语句执行超时时间，单位：毫秒。
	 * @param bool $straightJoin 可选，强制优化 JOIN 策略。
	 * @param bool $sqlSmallResult 可选，小结果集优化。
	 * @param bool $sqlBigResult 可选，大结果集优化。
	 * @param bool $sqlBufferResult 可选，强制结果集放入临时表，释放表锁。
	 * @param bool $sqlCache 可选，查询缓存是否开启。
	 * @return MySQL\SELECT
	 */
	function SELECT($fields, $sqlCalcFoundRows = null, $distinct = null, $highPriority = null, int $maxStatementTime = 0, $straightJoin = null, $sqlSmallResult = null, $sqlBigResult = null, $sqlBufferResult = null, $sqlCache = null){}
	
	/**
	 * MySQL 插入语句。
	 * @param string $table 要插入的逻辑表名。
	 * @return \MySQL\INSERT
	 */
	function INSERT(string $table){}
	
	/**
	 * 创建 SQL 语句或表达式。
	 * @param string $expression SQL 语句或表达式。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * 基于参数位置引用，模式“[?基于 1 的参数序号|type]”，注意：序号从 1 开始，不存在的参数默认为 NULL 值。参数位置跟参数位置相同可以省略序号。
	 * @param mixed ...$args 可选参数，将被代入 SQL 语句中。使用 pack 方法包装。
	 * @return \MySQL SQL 表达式
	 * @see \SQL::format
	 * @example sql('SELECT * FROM `[table]` WHERE `id`=[?] AND `code`=[?]', 1, 'string');
	 * @example sql('SELECT * FROM `[table]` WHERE `code`=[?2] AND `id`=[?1]', 1, 'string');
	 */
	function sql(string $expression = null, ... $args){}
	
	/**
	 * 简单查询：首行首列。
	 * @param string $sql SELECT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param mixed... $args 可变参数，要代入到 SQL 语句中的变量。
	 * @return scalar
	 */
	function first($sql, ... $args){}
	
	/**
	 * 简单查询：首列。
	 * @param string $sql SELECT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param mixed... $args 可变参数，要代入到 SQL 语句中的变量。
	 * @return array
	 */
	function column($sql, ... $args){}
	
	/**
	 * 简单查询：行集。
	 * @param string $sql SELECT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param mixed... $args 可变参数，要代入到 SQL 语句中的变量。
	 * @return array 全部结果集中的第一个。
	 */
	function rowset($sql, ... $args){}
	
	/**
	 * 简单查询：行集和总数。
	 * @param string $sql SELECT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param string $countSql 可选， COUNT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param int $total 引用，可选，非限定数据的总量。
	 * @param mixed... $args 可变参数，要代入到 SQL 语句中的变量。
	 * @return array 全部结果集中的第一个。
	 */
	function total($sql, $countSql = null, & $total = 0, ... $args){}
	
	/**
	 * 简单查询：获取单行数据。
	 * @param string $sql SELECT SQL 宏语句，可以使用宏引用 [?index|type]。
	 * @param mixed... $args 可变参数，将被代入 SQL 语句的变量。
	 * @return array 结果集中的一行。
	 */
	function row($sql, ... $args){}
	
	/**
	 * 查询：获取所有结果集。
	 * @param string $sql SELECT SQL 宏语句或语句组，可以使用宏引用 [?index|type]。
	 * @param mixed... $args 可变参数，将被代入 SQL 语句的变量。
	 * @return array 多个结果集，每个元素为一个结果集。
	 */
	function query($sql, ... $args){}
	
	/**
	 * 将参数带入并自动格式化 SQL 语句。
	 * @param string $sql SQL 语句。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * <ol>
	 * <li>基于参数位置引用，模式“[?基于 1 的参数序号|type]”，注意：序号从 1 开始，不存在的参数默认为 NULL 值。参数位置跟参数位置相同可以省略序号。</li>
	 * <li>基于参数名称引用，模式“[?键名|type]”，键名中不得包含 ] 括号，竖线和控制字符，不存在的参数默认为 NULL 值。</li>
	 * <li>
	 * 自动识别数据类型，也可以使用 type 强制类型转换，可用的 type （不区分大上写）如下：
	 * <ol type="A">
	 * <li>_, sql                             SQL 表达式，<strong>注意：慎用，要做好 SQL 注入检查</strong>，对应的参数必须能转换为字符串，无效时转换为 NULL。预置，不可覆盖或重定义。</li>
	 * <li>i, int, integer                 整数</li>
	 * <li>u, unsign, unsigned       正整数</li>
	 * <li>c, f, r, real, float, double, currency, decimal 浮点数/货币</li>
	 * <li>d, date                          日期</li>
	 * <li>t, time                           时间</li>
	 * <li>dt, datetime                  日期时间</li>
	 * <li>ts, timestamp                时间戳，正整数表示的时间值。</li>
	 * <li>j, json                            JSON 编码</li>
	 * <li>任何数值                      表示限定最大长度的字符串，超长将被截短，任何 html 标记将被移除。
	 * 预置（格式化器名为 cut），格式化器: string cut(string $var, int $length)。</li>
	 * <li>s, string                         字符串。</li>
	 * <li>b, bool, boolean            布尔值</li>
	 * <li>n, null, nil, none             空值</li>
	 * <li>任何可用的系统或自定义函数名，签名为 mixed function(mixed $var)，例如：trim, strtolower, md5, serialize, base64_encode, strip_tags, etc.</li>
	 * <li>未指定或格式化器未找到	自动识别</li>
	 * <li>也可以自定义格式化处理器，注册到 SQL::$formatters 静态属性，例如：SQL::$formatters['handlers']['my']=function($var){return do($var);}</li>
	 * <li>支持多个格式化处理器，以逗号分隔，顺序执行。</li>
	 * <li>注意，长度被截断时保存的数据跟提交的数据不一致。</li>
	 * </ol>
	 * </li>
	 * </ol>
	 * @param array $args 可选，参数表，子元素将被代入 SQL 语句中。子元素：A. 是 SQL 表达式，直接代入，等同于 sql 标志。B. 是数组类型将被使用 JSON 编码。C. 是对象将尝试转换为字符串，不能转换时作为 NULL 使用。D. 使用 pack 方法包装。
	 * @return string
	 * @example sqlprintf('SELECT * FROM `[table]` WHERE `id`=[?] AND `code`=[?] AND `password`=[?|20,md5]', [1, 'string', '********']); // password 最长 20 个，使用 md5 作散列处理
	 * @example sqlprintf('SELECT * FROM `[table]` WHERE `code`=[?2] AND `id`=[?1]', [1, 'string']);
	 * @example sqlprintf('SELECT * FROM `[table]` WHERE `code`=[?code] AND `id`=[?id]', ['id'=>1, 'code'=>'string']);
	 * @example sqlprintf('UPDATE `[table]` SET `data`=[?|json] WHERE `code`=[?code|32] AND `id`=[?id|unsigned]', [array('demo'=>true), 'id'=>1, 'code'=>'string']);
	 */
	function sqlprintf($sql, array $args = null){}
	
	/**
	 * 获取预定义 SQL 语句的查询结果。是否缓存及缓存时间取决于 SQL 定义。
	 * @param string $id 查询标识符，注意：仅支持 SELECT 类型查询。
	 * @param array $args 可选，传入的参数。
	 * @param int $total 引用，可选，如果存在，则输出未限定的结果集的数量。一般用于分页时获取分页前 SQL 查询的总记录数量。
	 * @return scalar|array 根据查询的定义返回相应的数据。无效定义或错误返回 null。
	 */
	function fetch($id, array $args = null, &$total = 0){}
}

namespace mysql
{
	/**
	 * 包装数据，使其可以直接连接进 SQL 语句（使用默认数据库驱动）。
	 * 多用途方法：
	 * <ol>
	 * <li>
	 * sqlPack(array $fields, int $mode)  将根据第二个参数的类型决定结果字符串的组装方式。见例子。
	 * </li>
	 * <li>
	 * sqlPack(scalar $var, string $key = null)  包装单个值。见例子。
	 * </li>
	 * </ol>
	 * @param mixed $fields 字段表（数组）或值。注意：如果是字段表，将会忽略非字符串的键。多级数组将被使用 JSON 编码。
	 * @param int|string $_ 可选，字段表时此参数必须为整数，表示字段表的包装类型。其它情况下此参数必须指定为字符串，表示键名。
	 * @return string
	 * @example sqlPack(array('k1'=>0, 'k2'=>null, 'k3'=>'string'), SQL::PAIR)		=> `k1`=0, `k2`=NULL, `k3`='string'
	 * @example sqlPack(array('k1'=>0, 'k2'=>null, 'k3'=>'string'), SQL::MAP)		=> (`k1`, `k2`, `k3`) VALUES (0, NULL, 'string')
	 * @example sqlPack(array('k1'=>0, 'k2'=>null, 'k3'=>'string'), SQL::VALUES)	=> 0, NULL, 'string'
	 * @example sqlPack(0, 'key')	=> `key`=0
	 * @example sqlPack('string', 'key')	=> `key`='string'
	 * @example sqlPack(null)	=> NULL
	 * @example sqlPack(99, 'key')	=> `key`=99
	 * @example sqlPack("I'm max")	=> 'I\'m max'
	 */
	function pack(... $args){}
	
	/**
	 * MYSQL 转义字符串（使用默认数据库驱动）。
	 * @param string $var 源字串。
	 * @return string
	 */
	function escape($var){}
	
	/**
	 * 将参数带入并自动格式化 SQL 语句。
	 * @param string $sql SQL 语句。支持宏引用，此处的宏为基于位置的引用，形式为：
	 * <ol>
	 * <li>基于参数位置引用，模式“[?基于 1 的参数序号|type]”，注意：序号从 1 开始，不存在的参数默认为 NULL 值。参数位置跟参数位置相同可以省略序号。</li>
	 * <li>基于参数名称引用，模式“[?键名|type]”，键名中不得包含 ] 括号，竖线和控制字符，不存在的参数默认为 NULL 值。</li>
	 * <li>
	 * 自动识别数据类型，也可以使用 type 强制类型转换，可用的 type （不区分大上写）如下：
	 * <ol type="A">
	 * <li>_, sql                             SQL 表达式，<strong>注意：慎用，要做好 SQL 注入检查</strong>，对应的参数必须能转换为字符串，无效时转换为 NULL。预置，不可覆盖或重定义。</li>
	 * <li>i, int, integer                 整数</li>
	 * <li>u, unsign, unsigned       正整数</li>
	 * <li>c, f, r, real, float, double, currency, decimal 浮点数/货币</li>
	 * <li>d, date                          日期</li>
	 * <li>t, time                           时间</li>
	 * <li>dt, datetime                  日期时间</li>
	 * <li>ts, timestamp                时间戳，正整数表示的时间值。</li>
	 * <li>j, json                            JSON 编码</li>
	 * <li>任何数值                      表示限定最大长度的字符串，超长将被截短，任何 html 标记将被移除。
	 * 预置（格式化器名为 cut），格式化器: string cut(string $var, int $length)。</li>
	 * <li>s, string                         字符串。</li>
	 * <li>b, bool, boolean            布尔值</li>
	 * <li>n, null, nil, none             空值</li>
	 * <li>任何可用的系统或自定义函数名，签名为 mixed function(mixed $var)，例如：trim, strtolower, md5, serialize, base64_encode, strip_tags, etc.</li>
	 * <li>未指定或格式化器未找到	自动识别</li>
	 * <li>也可以自定义格式化处理器，注册到 SQL::$formatters 静态属性，例如：SQL::$formatters['handlers']['my']=function($var){return do($var);}</li>
	 * <li>支持多个格式化处理器，以逗号分隔，顺序执行。</li>
	 * <li>注意，长度被截断时保存的数据跟提交的数据不一致。</li>
	 * </ol>
	 * </li>
	 * </ol>
	 * @param array $args 可选，参数表，子元素将被代入 SQL 语句中。子元素：A. 是 SQL 表达式，直接代入，等同于 sql 标志。B. 是数组类型将被使用 JSON 编码。C. 是对象将尝试转换为字符串，不能转换时作为 NULL 使用。D. 使用 pack 方法包装。
	 * @return string
	 * @example sprintf('SELECT * FROM `[table]` WHERE `id`=[?] AND `code`=[?] AND `password`=[?|20,md5]', [1, 'string', '********']); // password 最长 20 个，使用 md5 作散列处理
	 * @example sprintf('SELECT * FROM `[table]` WHERE `code`=[?2] AND `id`=[?1]', [1, 'string']);
	 * @example sprintf('SELECT * FROM `[table]` WHERE `code`=[?code] AND `id`=[?id]', ['id'=>1, 'code'=>'string']);
	 * @example sprintf('UPDATE `[table]` SET `data`=[?|json] WHERE `code`=[?code|32] AND `id`=[?id|unsigned]', [array('demo'=>true), 'id'=>1, 'code'=>'string']);
	 */
	function sprintf($sql, array $args = null){}
}
