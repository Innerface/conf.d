<?php

namespace MySQL;

use DB;
use SQL;
use MySQL;
use IDBDriver;
use IDBTransaction;

/**
 * MySQL 数据库驱动，使用 mysqli。
 * 
 * @version 1.0.0
 * @since 1.0.0
 */
class Driver implements IDBDriver, IDBTransaction
{
	/**
	 * 驱动的类型。
	 * @var string
	 * @see \DB
	 * @see \DB::MySQL
	 * @see \DB::Oracle
	 * @see \DB::PostgreSQL
	 * @see \DB::DB2
	 */
	const TYPE = DB::MySQL;
	
	/**
	 * 内部实际使用的扩展。
	 * @var string
	 */
	const ENGINE = 'mysqli';
	
	/**
	 * 连接信息。
	 * @var \Setting\DB
	 */
	protected $setting;
	
	/**
	 * 最后连接的时间。
	 * @var float
	 */
	protected $latest;
	/**
	 * 最后一次获取的计数值。
	 * @var int
	 */
	protected $count;
	
	/**
	 * 要批量执行的 SQL 语句。
	 * @var array
	 */
	protected $sqls;
	
	/**
	 * 原始连接。
	 * @var mysqli
	 */
	protected $connection;
	/**
	 * 最后的错误信息，完整的错误信息在 $recent 属性中。
	 * @var array $error
	 */
	protected $error;
	protected $warnings;
	/**
	 * 执行过的 SQL 语句的集合。
	 * @var array
	 */
	protected $recent;
	/**
	 * 当前的状态。ready 为准备好等待指令，wait 正在执行中，transaction 事务过程中，gone 关闭状态。
	 * @var int
	 */
	protected $status;
	/**
	 * SQL 编写器。
	 * @var \MySQL\Writer
	 */
	protected $writer;
	/**
	 * 上下文数据。
	 * @var array|object
	 */
	protected $context;
	
	/**
	 * 构造 MySQL 数据库驱动。
	 * @param array|\Setting\DB $setting 连接配置。
	 * @throws \InvalidArgumentException 连接配置无效。
	 */
	public function __construct(\Setting\DB $setting){}
	
	public function setting(){}
	
	public function __clone(){}
	
	public function __destruct(){}
	
	public function ping(){}
	
	public function type(){}
	
	public function version(){}
	
	public function engine(){}
	
	public function guid(){}
	
	public function & connection(){}
	
	public function status(){}
	
	public function begin(){}
	
	public function commit(){}
	
	public function rollback(){}
	
	public function transact(...$actions){}
	
	public function exec($sql){}
	
	public function call($name, ... $args){}
	
	public function lastInsertId(){}
	
	public function dataset(... $sqls){}
	
	public function rowset($sql, int $seek = 0, int $length = null){}
	
	public function row($sql, int $seek = 0){}
	
	public function column($sql, $index = 0){}
	
	public function first($sql){}
	
	public function count($sql = null){}
	
	public function query($sql, int $seek = 0, int $length = null, int $type = DB::ASSOC){}
	
	public function bulk($sqls, int $type = DB::ASSOC){}
	
	/**
	 * $sql 语句可以使用 SQL_CALC_FOUND_ROWS 标志。则可以省略 $count_sql 语句。 
	 * {@inheritDoc}
	 * @see IDBDriver::section()
	 */
	public function section($sql, $count_sql = null,  int &$total = 0){}
	
	public function transpose($sql, string $key_field = 'key', string $value_field = 'value', string $type_field = 'type', string $namespace_field = 'namespace', string $comment_field='comment'){}
	
	public function entity($sql, string $key_field = 'key', string $value_field = 'value'){}
	
	public function support($statements = null, $schemes = null){}
	
	public function recent(){}
	
	public function last(){}
	
	public function error(){}
	
	public function warnings(){}
	
	public function rewrite($sql, $context = null){}
	
	public function map(string $name, $context = null){}
	
	public function name(string $name){}
	
	public function context($context){}
	
	public function writer(){}
	
	public function builder(... $sql){}
	
	/**
	 * 是否离线状态。
	 * @return bool
	 */
	protected function hasGoneAway(){}
	
	/**
	 * 连接是否就绪，未就绪则连接。
	 * @return bool
	 */
	protected function ready(){}
	
	/**
	 * 如果最后的操作执行时连接被中止则尝试重连。
	 * @return bool 离线重连成功返回 true，无法重连或非连接故障返回 false。
	 */
	protected function retry(){}
	
	/**
	 * 连接。
	 * @return bool 连接可用或重连成功返回 true，不可用则返回 false。
	 */
	protected function conn(){}
	
	/**
	 * 重置查询。
	 * @param mysqli_result $rs 要重置的查询结果。
	 * @return array 返回上一次查询未处理的错误信息。
	 */
	protected function reset($rs = null){}
	
	/**
	 * 连接初始化。
	 * @return void
	 */
	protected function initialize(){}
	
	/**
	 * 当前驱动的初始化。
	 * @return void
	 */
	protected function init(){}
	
	protected function dispose(){}
}
