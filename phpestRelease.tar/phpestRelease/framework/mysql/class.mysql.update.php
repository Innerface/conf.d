<?php

namespace MySQL;

abstract class UPDATE extends \SQL
{
	
}