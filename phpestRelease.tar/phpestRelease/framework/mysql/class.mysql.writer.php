<?php

namespace MySQL;

/**
 * MySQL 编写器。
 * @author Max
 * 
 */
class Writer extends \SQL\Writer
{
	/**
	 * 标识符引号字符。
	 * @var string
	 */
	const ID_QUOTE_CHAR = '`';
	
	public function builder(... $sql) : \SQL\Builder{}
	
	public function datetime($var, $type = \SQL\TIMESTAMP){}
	
	public function escape($var){}
	
	public function name($id, int $type = 0){}
	
	public function quote(string $id){}
	
	public function id($id){}
	
	public function pairs(array $var){}
	
	public function pack($var, string $key = null, int $options = 0){}
	public function map(array $var){}
	public function fields(array $var, bool $alias = false){}
	public function values(array $var){}
}