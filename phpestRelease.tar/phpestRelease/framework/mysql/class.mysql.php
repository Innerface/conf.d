<?php

/**
 * MySQL 表达式或语句。
 * @author Max
 * 
 */
class MySQL extends SQL
{
	protected function _writer() : \SQL\Writer{}
	
	/**
	 * 获取一个快捷的副本。
	 * @return MySQL
	 */
	public static function shortcut(){}
}