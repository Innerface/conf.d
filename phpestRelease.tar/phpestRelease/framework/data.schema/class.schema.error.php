<?php

namespace Schema;

/**
 * 架构验证错误。
 * @author Max Wang
 * 
 */
class Error
{
	const TYPE = 0;
	const REQUIRED = 1;
	const LENGTH = 2;
	const VALIDATE = 3;
	/**
	 * 类型。
	 * @var int
	 */
	public $type;
	/**
	 * 错误码。
	 * @var int
	 */
	public $code;
	public $message;
	public $details;
}