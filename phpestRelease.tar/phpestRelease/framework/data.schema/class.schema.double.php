<?php

namespace Schema;

/**
 * 浮点数。
 * @author Max Wang
 * 
 */
class Double extends Numeric
{
	public function validate($var, int $options = 0, array & $error = null){}
	public function cast($var, int $options = 0){}
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	public function __toString(){}
	public function jsonSerialize(){}
}