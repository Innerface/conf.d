<?php

namespace Schema;

/**
 * 无符号整数。
 * @author Max Wang
 * 
 */
class Unsigned extends Integer
{
	public function cast($var, int $options = 0){}
	public function validate($var, int $options = 0, array & $error = null){}
	public function format($var, string $format = null){}
	public function __toString(){}
	public function jsonSerialize(){}
}