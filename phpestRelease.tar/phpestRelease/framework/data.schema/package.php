<?php

return [
	'use' => ['system.data.validation'],
];

/**
 * 单行文本，如果是多行文本则返回首行。
 * @param string $str 文本。
 * @return string
 */
function line(string $str){}