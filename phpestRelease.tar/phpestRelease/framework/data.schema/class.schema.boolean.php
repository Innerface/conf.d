<?php

namespace Schema;

/**
 * 布尔值。
 * @author Max Wang
 * 
 */
class Boolean extends Scalar
{
	/**
	 * 默认值。
	 * @var bool
	 */
	public $default = false;
	
	protected $true;
	
	public function __construct($true = null){}
	public function validate($var, int $options = 0){}
	public function cast($var, int $options = 0){}
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	public function default(){}
	public function __toString(){}
	public function jsonSerialize(){}
}