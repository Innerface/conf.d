<?php

namespace Schema;

/**
 * 时间。
 * @author Max Wang
 * 
 */
class Time extends DateTime
{
	const FORMATs = [
		'24h' => 'H:i:s',
		'24h.ms' => 'H:i:s.v',
		'12h' => 'h:i:s a',
		'12h.ms' => 'h:i:s.v a',
		'12H' => 'h:i:s A',
		'12H.ms' => 'h:i:s.v A',
	];
	
	public function __toString(){}
	
	/**
	 * 从数组中获取日期时间。
	 * @param array $datetime 可选，空值代表当前时间。可以使用键定义或顺序定义，但只能使用一种。
	 * @return stdClass 根据请求返回包含 hour, minute, second 和 microsecond 属性的对象。未正确获取返回 null。
	 */
	protected function fetch(array $datetime = null){}
}