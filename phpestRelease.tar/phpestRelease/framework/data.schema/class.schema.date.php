<?php

namespace Schema;

/**
 * 日期。
 * @author Max Wang
 * 
 */
class Date extends DateTime
{
	const FORMATs = [
		'human' => 'Y-n-j',
		'normal' => 'Y-m-d',
		'cookie' => 'l, d-M-Y',
		'iso8601' => 'Y-m-d',
		'rfc822' => 'D, d M y',
		'rfc850' => 'l, d-M-y',
		'rfc1036' => 'D, d M y',
		'rfc1123' => 'D, d M Y',
		'rfc2822' => 'D, d M Y',
		'rfc3339' => 'Y-m-d',
		'rss' => 'D, d M Y',
		'w3c' => 'Y-m-d',
	];
	
	public function __toString(){}
	
	/**
	 * 从数组中获取日期时间。
	 * @param array $datetime 可选，空值代表当前时间。可以使用键定义或顺序定义，但只能使用一种。
	 * @return stdClass 根据请求返回包含 year, month, day 属性的对象。未正确获取返回 null。
	 */
	protected function fetch(array $datetime = null){}
}