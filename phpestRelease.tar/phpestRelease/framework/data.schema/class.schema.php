<?php

/**
 * 单值（标量），集合（数组），结构 
 * name(ext, ext, ext...)[required, validator, ...]{cast, strtolower}<format, ''>
 * scalar
 * numeric
 * int
 * unsigned
 * float
 * bool
 * string
 * date
 * time
 * datetime[iso8611]
 * set
 * enum
 * struct
 * array(scalar)[required, 5~100, ]
 * array(User)[]{}
 * string()[]{}
 * string()[~/^\w+$/us] # 标签
 * string(~/aaaa/gi, 20~100) # 必看
 * text[markdown](required, 5-20, email, ){line, strip, clean} # 标签
 * string(, )
 * file(image/*, text/*, application/json)
 * User(username, password, age, title, role)[required, optional, ]{} # 用户
 * Account.User(username, password, age, title, role)[required, optional, ]{} # 用户
 */

/**
 * 数据架构工具特性。
 * 数据架构提供这样的特性：
 * <ol>
 * <li>定义数据的逻辑结构。</li>
 * <li>定义数据验证规则。</li>
 * <li>定义数据转化规则。</li>
 * <li>辅助生成查询语句。</li>
 * <li>定义名字映射。</li>
 * </ol>
 * @author Max Wang
 */
abstract class Schema implements ISchema, ArrayAccess
{
	/**
	 * 架构类型名。
	 * @var array
	 */
	const TYPE = [
		'scalar'			=> '\Schema\Scalar',
		'numeric'		=> '\Schema\Numeric',
		'int'				=> '\Schema\Integer',
		'unsigned'		=> '\Schema\Unsigned',
		'float' 			=> '\Schema\Double',
		'bool' 			=> '\Schema\Boolean',
		'string' 		=> '\Schema\Str',
		'date' 			=> '\Schema\Date',
		'time' 			=> '\Schema\Time',
		'datetime' 	=> '\Schema\DateTime',
		'set' 				=> '\Schema\Set',
		'enum' 			=> '\Schema\Enum',
		'array' 			=> '\Schema\Collection',
		'struct' 		=> '\Schema\Struct',
	];
	
	/**
	 * 类型别名。
	 * @var array
	 */
	const ALIASES = [
		'timestamp' 	=> 'datetime',
		'text' 			=> 'string',
		'number'			=> 'numeric',
		'decimal'		=> 'float',
	];
	
	/**
	 * 忽略完整性验证。
	 * @var integer
	 */
	const IgnoreRequired = 1;
	/**
	 * 忽略未设置的项目。
	 * @var integer
	 */
	const IgnoreUnset = 2;
	/**
	 * 强制对象使用数组访问。
	 * @var integer
	 */
	const ArrayAccess = 4;
	
	public function __construct(){}
	
	abstract public function struct();
	
	public function validate($var, int $options = 0, array & $error = null){}
	
	public function cast(&$var, int $options = 0){}
	
	public function format($var){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2){}
	
	public function __toString(){}
	
	public function jsonSerialize(){}
	
	public function offsetExists($offset){}
	
	public function offsetGet($offset){}
	
	public function offsetSet($offset, $value){}
	
	public function offsetUnset($offset){}
	
	/**
	 * 设置特性。
	 * @param string $name 名字。
	 * @param string|\Schema\Attribute|array $definition 特性定义。
	 * @return bool
	 */
	protected function set(string $name, $definition){}
	
	/**
	 * 初始化方法。
	 * @return void
	 */
	protected function _init(){}
	
	/**
	 * 根据声明创建指定数据架构。
	 * @param string $schema 架构声明。
	 * @return ISchema|null
	 */
	public static function create(string $schema){}
	
	/**
	 * 解析。
	 * @param string $schema 数据架构的定义。
	 * @return stdClass|null 有效的架构定义返回包含 name, exts, validators, cast 属性的 stdClass，
	 * 无效的架构定义返回 null.
	 */
	public static function parse(string $schema){}
	
	/**
	 * 获取类型定义。
	 * @param string $name 类型名。
	 * @return ISchema
	 */
	public static function type(string $name){}
	
	/**
	 * 基本验证之空值（null，0 长度字符串，无元素的数组，注意：0 或 '0' 是非空值）判断。
	 * @param mixed $var 值。
	 * @return bool 是空值返回 true，否则返回 false。
	 */
	public static function empty($var){}
}
