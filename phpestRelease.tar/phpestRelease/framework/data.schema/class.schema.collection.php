<?php

namespace Schema;

/**
 * 集合架构。
 * @author Max Wang
 * 
 */
abstract class Collection implements \ISchema
{
	public $default = [];
	
	/**
	 * 元素类型。
	 * @var \ISchema
	 */
	protected $type;
	
	/**
	 * 构造集合。
	 * @param \ISchema|string $type 子类型或类型名。
	 */
	public function __construct(\ISchema $type = null){}
	public function validate($var, int $options = 0, array & $error = null){}
	public function cast($var, int $options = 0){}
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	public function default(){}
	public function __toString(){}
	
	public function jsonSerialize(){}
}
