<?php

namespace Schema;

/**
 * 属性集定义。
 * @author Max Wang
 */
class Attributes implements \IteratorAggregate, \Countable
{
	protected $_;
	
	public function __get(string $name){}
	
	public function __set(string $name, $var){}
	
	public function __isset(string $name){}
	
	public function __unset(string $name){}
	
	/**
	 * 获取全部键名。
	 * @return array|null
	 */
	public function keys(){}
	
	public function count(){}
	
	public function getIterator(){}
}