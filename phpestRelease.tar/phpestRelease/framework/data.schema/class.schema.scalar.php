<?php

namespace Schema;

use Validator;

/**
 * 标量。
 * @author Max Wang
 * 
 */
class Scalar implements \ISchema
{
	const ERROR = [
		null,
		'type',
	];
	
	const OK = 0;
	const FAILED = 1;
	
	/**
	 * 默认值。
	 * @var scalar
	 */
	public $default;
	
	protected $error;
	
	protected $validators = [
		1 => 'is_scalar',
	];
	
	protected $normalizers;
	
	public function __construct(){}
	
	public function error(){}
	
	/**
	 * 添加验证器或转换器。注意，同类的验证器只能添加一次。
	 * @param \Validator|callable ... $handlers 可变参数，验证器或转换器。
	 * @return self
	 */
	public function add(... $handlers){}
	
	public function validate($var, int $options = 0){}
	public function cast($var, int $options = 0){}
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	public function default(){}
	public function __toString(){}
	public function jsonSerialize(){}
	
	/**
	 * 设置错误。
	 * @param bool $result
	 * @param int $error
	 * @return \Schema\bool
	 */
	protected function setError(bool $result, int $error = 1){}
	protected function init(){}
}
