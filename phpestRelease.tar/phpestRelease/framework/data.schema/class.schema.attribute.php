<?php

namespace Schema;

/**
 * 架构特性定义。	
 * @author Max Wang
 */
class Attribute
{
	/**
	 * 类型。
	 * @var string|array
	 */
	public $type;
	/**
	 * 是否必须。
	 * @var bool
	 */
	public $required;
	/**
	 * 简短的标签。
	 * @var string
	 */
	public $label;
	/**
	 * 详细说明。
	 * @var string
	 */
	public $description;
	/**
	 * 开发提示。
	 * @var string
	 */
	public $hint;
	/**
	 * 映射到的物理字段名。
	 * @var string
	 */
	public $name;
	/**
	 * 格式化。
	 * @var string|array
	 */
	public $format;
	/**
	 * 表达式。
	 * @var SQL|callable
	 */
	public $expression;
	/**
	 * 选项集。
	 * @var array
	 */
	public $options;
	/**
	 * 文本集。
	 * @var array
	 */
	public $text;
	/**
	 * 前缀。
	 * @var string
	 */
	public $prefix;
	/**
	 * 后缀。
	 * @var string
	 */
	public $suffix;
	
	public $validators;
	public $normalizers;
	
	/**
	 * 构造器。
	 * @param string $type 类型。
	 * @param bool $required 可选，是否必须。
	 * @param string $name 可选，内部名字。
	 * @param string $label 可选，标签。
	 * @param string $description 可选，描述。
	 * @param string $hint 可选，输入提示。
	 */
	public function __construct(string $type = null, bool $required = false, string $name = null, string $label = null, string $description = null, string $hint = null){}
	
	public function __toString(){}
	
	/**
	 * 设置简短的标签。
	 * @param string $label 标签。长度不要超过10个字符。
	 * @return self
	 */
	public function label(string $label){}
	
	/**
	 * 设置必要项。
	 * @param bool $required 是否为必要项。
	 * @return self
	 */
	public function required(bool $required){}
	
	/**
	 * 设置选项集。
	 * @param array $var 选项集。键为选项的整型值，值为选项的文本值。
	 * @return self
	 */
	public function options(array $var = null){}
	
	/**
	 * 设置选项的文本项。
	 * @param array $var 文本项。键为选项的文本值，值为显示给终端用户看的文本。
	 * @return self
	 */
	public function text(array $var = null){}
	
	/**
	 * 设置名字前缀。
	 * @param string $var 名字前缀。
	 * @return self
	 */
	public function prefix(string $var = null){}
	
	/**
	 * 设置名字后缀。
	 * @param string $var 名字后缀。
	 * @return self
	 */
	public function suffix(string $var = null){}
	
	/**
	 * 设置类型。
	 * @param string $var 业务描述内容。
	 * @return self
	 */
	public function type(string $var = null){}
	
	/**
	 * 设置映射的内部名。
	 * @param string $var 名字。
	 * @return self
	 */
	public function name(string $var = null){}
	
	/**
	 * 设置业务描述。
	 * @param string $var 业务描述内容。
	 * @return self
	 */
	public function desc(string $var = null){}
	
	/**
	 * 设置业务描述。
	 * @param string $var 业务描述内容。
	 * @return self
	 */
	public function description(string $var = null){}
	
	/**
	 * 设置输入提示。
	 * @param string $var 输入提示内容。
	 * @return self
	 */
	public function hint(string $var = null){}
	
	/**
	 * 设置格式串。
	 * @param string $var 适用于 sprintf 的格式串。
	 * @return self
	 */
	public function format(string $var = null){}
	
	/**
	 * 设置 SQL 表达式。
	 * @param \SQL|string $sql 如果是字符串，将被包装为 mysql 表达式。
	 * @return self
	 */
	public function sql($sql = null){}
	
	/**
	 * 设置表达式。
	 * @param \SQL|callable $expression 表达式。
	 * @return self
	 */
	public function expression($expression){}
	
	/**
	 * 添加验证器或转换器。注意，同类的验证器只能添加一次。
	 * @param \Validator|callable ... $handlers 可变参数，验证器或转换器。
	 * @return self
	 */
	public function add(... $handlers){}
	
	/**
	 * 解析类型定义。
	 * @param string|array $definition 类型定义。
	 * @return self
	 */
	public static function parse($definition){}
}