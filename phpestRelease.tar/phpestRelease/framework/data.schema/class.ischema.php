<?php

/**
 * 数据架构。
 * 数据架构提供这样的特性：
 * <ol>
 * <li>定义数据类型和结构，包括标准数据类型和结构。</li>
 * <li>定义数据验证规则。</li>
 * <li>定义数据转化规则。</li>
 * </ol>
 * @author Max Wang
 */
interface ISchema extends JsonSerializable
{
	/**
	 * 验证外部输入的数据。通过 error 方法获取错误信息。
	 * @param mixed $var 数据。
	 * @param int $options 可选，位域选项。参考 Schema 类的常量定义。
	 * @see Schema::IgnoreRequired
	 * @see Schema::IgnoreUnset
	 * @see Schema::ArrayAccess
	 * @return bool 如果验证通过返回 true
	 */
	public function validate($var, int $options = 0);
	/**
	 * 获取验证的错误信息，如果最后一次验证通过则返回 0。
	 * @return int
	 */
	public function error();
	/**
	 * 转换和规范化为内部数据格式。
	 * @param object|array $var 要转换或规范化的数据。
	 * @param int $options 可选，位域选项。参考 Schema 类的常量定义。
	 * @see Schema::IgnoreRequired
	 * @see Schema::IgnoreUnset
	 * @see Schema::AsArray
	 * @return mixed
	 */
	public function cast($var, int $options = 0);
	/**
	 * 格式化为输出的数据格式。
	 * @param mixed $var 变量。
	 * @param string $format 可选，格式。
	 * @return mixed
	 */
	public function format($var, string $format = null);
	/**
	 * 用一个变量为另一个变量赋值。注意：如果源数据不能赋值给目标变量则忽略。
	 * @param object|array $var 引用，要赋值的对象，直接修改。
	 * @param object|array $data 源数据。
	 * @param int $options 选项，ASSIGN_ 前缀的常量都有效。
	 * @return self
	 */
	public function assign(&$var, $data, int $options = 0);
	/**
	 * 比较两个数据是否为相同的架构。
	 * @param object|array $var1 数据一。
	 * @param object|array $var2 数据二。
	 * @param bool $strict 可选，严格相同。默认为 true
	 * @return bool
	 */
	public function equals($var1, $var2, bool $strict = true);
	/**
	 * 获取默认值。
	 * @return mixed
	 */
	public function default();
	public function __toString();
}
