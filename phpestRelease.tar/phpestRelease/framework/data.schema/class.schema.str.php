<?php

namespace Schema;

/**
 * 字符串。
 * @author Max Wang
 * 
 */
class Str extends Scalar
{
	const EXTRA = [
		'json',
		'html',
		'xml',
		'plain',
		'markdown',
		'ubb',
	];
	
	protected $extra;
	
	public function __construct(string $extra = null){}
	public function validate($var, int $options = 0, array & $error = null){}
	public function cast($var, int $options = 0){}
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	
	public function __toString(){}
	public function jsonSerialize(){}
}