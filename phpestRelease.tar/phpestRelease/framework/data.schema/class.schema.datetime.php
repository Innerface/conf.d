<?php

namespace Schema;

/**
 * 日期时间。
 * @author Max Wang
 * 
 */
class DateTime extends Scalar
{
	const FORMATs = [
		'human' => 'Y-m-d H:i:s T',
		'atom' => 'Y-m-d\TH:i:sP',
		'cookie' => 'l, d-M-Y H:i:s T',
		'iso8601' => 'Y-m-d\TH:i:sP',
		'rfc822' => 'D, d M y H:i:s O',
		'rfc850' => 'l, d-M-y H:i:s T',
		'rfc1036' => 'D, d M y H:i:s O',
		'rfc1123' => 'D, d M Y H:i:s O',
		'rfc2822' => 'D, d M Y H:i:s O',
		'rfc3339' => 'Y-m-d\TH:i:sP',
		'rfc3339_extended' => 'Y-m-d\TH:i:s.vP',
		'rss' => 'D, d M Y H:i:s O',
		'w3c' => 'Y-m-d\TH:i:sP',
	];
	
	protected $format;
	
	public function __construct(string $format = null){}
	
	public function cast($var, int $options = 0){}
	public function validate($var, int $options = 0, array & $error = null){}
	public function format($var, string $format = null){}
	
	public function __toString(){}
	public function jsonSerialize(){}
	
	/**
	 * 时间戳。
	 * @param mixed $var 时间值。
	 * @return int|null
	 */
	protected function timestamp($var){}
	
	/**
	 * 从数组中获取日期时间。
	 * @param array $datetime 可选，空值代表当前时间。可以使用键定义或顺序定义，但只能使用一种。
	 * @return stdClass 根据请求返回包含 year, month, day, hour, minute, second 和 microsecond 属性的对象。未正确获取返回 null。
	 */
	protected function fetch(array $datetime = null){}
	
	/**
	 * 解析时间。
	 * @param int $time 时间戳。
	 * @return \stdClass 返回包含 
	 */
	public static function parse(int $time){}
	
	/**
	 * 是否为闰年。
	 * @param int $year 年份。
	 * @return boolean
	 */
	public static function isLeafYear(int $year){}
}