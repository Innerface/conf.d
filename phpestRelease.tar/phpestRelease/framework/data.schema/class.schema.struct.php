<?php

namespace Schema;

/**
 * 结构化数据架构。
 * @author Max Wang
 * 
 */
class Struct implements \ISchema
{
	protected $_;
	
	public function __construct(){}
	/**
	 * 属性集。
	 * @return \Schema\Attributes
	 */
	public function attributes(){}
	
	public function validate($var, int $options = 0, array & $error = null){}
	
	public function cast(&$var, int $options = 0){}
	
	public function format($var, string $format = null){}
	public function assign(&$var, $data, int $options = 0){}
	public function equals($var1, $var2, bool $strict = true){}
	
	public function __toString(){}
	
	public function jsonSerialize(){}
	
	public function default(){}
	
	public function error(){}

}