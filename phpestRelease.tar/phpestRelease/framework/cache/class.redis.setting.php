<?php

namespace Redis;

class Setting extends \Setting
{
	
}