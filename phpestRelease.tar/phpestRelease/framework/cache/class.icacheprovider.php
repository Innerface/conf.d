<?php

/**
 * 缓存提供者接口。
* 
* @version 1.0
* @since 1.0
*/
interface ICacheProvider extends ArrayAccess
{
	/**
	 * 切换当前的名字空间。
	 * @param string $namespace 名字空间。不提供仅返回当前的名字空间，空值重置为默认名字空间。
	 * @return string 返回当前的名字空间。
	 */
	public function namespace($namespace = null);
	
	/**
	 * 设置或获取当前的名字前缀，名字前缀自动附加到标识符前。
	 * @param string $prefix 可选，前缀。不提供仅返回当前的名字前缀，空值清除前缀。
	 * @return string 返回当前的名字前缀。
	 */
	public function prefix($prefix = null);
	
	/**
	 * 一个值是否存在。
	 * @param string $id 名字或标识符。
	 * @return mixed
	*/
	public function exists($id);
	/**
	 * 读取一个值。
	 * @param string $id 名字或标识符。
	 * @return mixed
	*/
	public function get($id);
	/**
	 * 获取物理引擎实际使用的键名。
	 * @param string $id 名字或标识符（逻辑标识符）。
	 * @return mixed
	*/
	public function key($id);
	
	/**
	 * 获取或调整一个值的生存期。
	 * @param string $id 名字或标识符。
	 * @param int $ttl 可选，新的生存期。不提供此参数则仅返回 TTL。
	 * @return int
	*/
	public function ttl($id, $ttl = null);
	/**
	 * 读取一个值并赋值给指定的变量。
	 * @param string $id 名字或标识符。
	 * @param mixed $var 引用，输出的变量。
	 * @return ICacheProvider $this
	*/
	public function assign($id, &$var=null);
	/**
	 * 设置一个值。
	 * @param string $id 名字或标识符。
	 * @param mixed $value 值，注意：非标题的值必须能序列化。
	 * @param int $ttl 可选，存活期，单位：秒。
	 * @param callable $refresh 可选，刷新回调。当值过期或无效时调用。
	 * @return ICacheProvider $this
	*/
	public function set($id, $value, $ttl = null, callable $refresh = null);
	/**
	 * 移除。
	 * @param string $id 名字或标识符。
	 * @return ICacheProvider
	*/
	public function remove($id);
	/**
	 * 批量设置。
	 * @param array $data 数据。
	 * @return ICacheProvider
	*/
	public function mass(array $data);
	/**
	 * 刷新当前名字空间下所有的状态值（如果过期）。
	 * @return ICacheProvider
	*/
	public function refresh();
	/**
	 * 重置。
	 * @return ICacheProvider
	*/
	public function reset();
	/**
	 * 清空并重置，包括移除全部刷新回调。
	 * @return ICacheProvider
	*/
	public function clear();
	/**
	 * 回收，释放不再使用的资源。
	 * @return ICacheProvider $this
	*/
	public function gc();
	/**
	 * 返回原始连接/驱动的引用。
	 * @return mixed 
	 */
	public function & driver();
}