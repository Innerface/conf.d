<?php

return [
	'use' => ['system.config'],
];