<?php

namespace Http\Client;

/**
 * HTTP POST 请求。
 * @author Max
 * 
 */
class POST extends Request
{
	/**
	 * 要提交的数据字段。
	 * @var array|object
	 */
	public $fields;
	/**
	 * 要上传的文件。
	 * @var array|object
	 */
	public $files;
	
	/**
	 * 进度回调：mixed function (resource $curl_conn, int $content_length, int $current, int $upload_length, int $upload_current)。返回非 0 则中止进度。
	 * @var callable
	 */
	public $progress_callback;
	
	public function __construct($url, array $fields = null, $files = null){}
	
	protected function merge(){}
	
	public function options(\IHttpClient $client){}
}