<?php

/**
 * HTTP 客户端接口。
 * @author Max
 * 
 */
interface IHttpClient
{
	/**
	 * 发送请求。
	 * @param \Http\Client\Request $request 要发送的请求。
	 * @param int $options 可选，响应内容选项。参见 \Http\Client\Response 常量定义。
	 * @return \Http\Client\Response 返回响应内容。请求失败返回 null 或 false。
	 */
	public function send(\Http\Client\Request $request, int $options = 0);
	
	/**
	 * 快速 GET 连接。
	 * @param string $url 链接。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function GET(string $url, array $headers = null);
	
	/**
	 * 快速 POST 连接。
	 * @param string $url 链接。
	 * @param array|string $data 要提交的数据。如果是数组，则自动视作传统的表单数据。
	 * 如果是字符串需要设置 $content_type 提供内容类型。
	 * @param string $content_type 可选，提交数据的 MIME 类型及字符集，如果 $data 
	 * 参数不为字符串此参数无效。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function POST(string $url, $data, string $content_type = null, array $headers = null);
	
	/**
	 * 快速 PUT 连接。
	 * @param string $url 链接。
	 * @param string $data 要提交的数据。
	 * @param string $content_type 可选，提交数据的 MIME 类型及字符集。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function PUT(string $url, string $data, string $content_type, array $headers = null);
	
	/**
	 * 快速 PATCH 连接。
	 * @param string $url 链接。
	 * @param string $data 要提交的数据。
	 * @param string $content_type 可选，提交数据的 MIME 类型及字符集。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function PATCH(string $url, string $data, string $content_type, array $headers = null);
	
	/**
	 * 快速 DELETE 连接。
	 * @param string $url 链接。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function DELETE(string $url, array $headers = null);
	
	/**
	 * 快速 HEAD 连接。
	 * @param string $url 链接。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function HEAD(string $url, array $headers = null);
	
	/**
	 * 快速 OPTIONS 连接。
	 * @param string $url 链接。
	 * @param array $headers 可选，要设置的请求头。
	 * @return \Http\Client\Response
	 */
	public function OPTIONS(string $url, array $headers = null);
	
	/**
	 * 重载最新的请求。
	 * @return \Http\Client\Response
	 */
	public function reload();
}