<?php

namespace Http\Client;

class Proxy
{
	/**
	 * 获取其它选项。
	 * @param IHttpClient $client 调用的 HTTP 客户端。
	 * @return ITraceable
	 */
	public function options(\IHttpClient $client){}
}