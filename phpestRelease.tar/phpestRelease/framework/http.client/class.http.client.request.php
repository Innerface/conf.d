<?php

namespace Http\Client;

/**
 * HTTP 请求。
 * @author Max
 * 
 */
abstract class Request
{
	const METHOD = 'GET';
	
	/**
	 * 连接模式：重用连接池中的连接。
	 * @var int
	 */
	const CONNECT_REUSE = 0;
	/**
	 * 连接模式：建立新连接。
	 * @var int
	 */
	const CONNECT_FRESH = 1;
	/**
	 * 连接模式：完成连接立即关闭，不放到连接池。
	 * @var int
	 */
	const CONNECT_FORBID_REUSE = 2;
	
	/**
	 * 用户代理，不设置则使用 \HttpClient 的设置。
	 * @var string
	 */
	public $useragent;
	
	/**
	 * 请求超时时间，单位：秒。注意，不同于连接超时。
	 * @var int
	 */
	public $timeout;
	/**
	 * 请求超时时间，单位：毫秒。如果设置这个参数，则忽略 timeout。注意，不同于连接超时。
	 * @var int
	 */
	public $timeout_ms;
	
	/**
	 * 请求头。
	 * @var array 每一个元素为一个请求头定义，格式为是 name: content。
	 */
	public $headers;
	/**
	 * 设定来源链接。未设置则取决于 HttpClient 的设定。
	 * @var string
	 */
	public $referer;
	/**
	 * 编码：HTTP请求头中"Accept-Encoding: "的值。支持的编码有"identity"，"deflate"和"gzip"，多个编码用逗号分隔。
	 * 如果为空字符串""，会发送所有支持的编码类型。
	 * @var string
	 */
	public $encoding;
	/**
	 * 使用的网络接口（当有多个网络接口时）：发送的网络接口（interface），可以是一个接口名、IP 地址或者是一个主机名。 。
	 * @var sting
	 */
	public $interface;
	/**
	 * 基本验证的内容：传递一个连接中需要的用户名和密码，格式为："[username]:[password]"。 
	 * @var string
	 */
	public $auth;
	
	/**
	 * 请求的链接，链接缺失的部分使用 \HttpClient 当前的链接补齐（包括协议，域名和路径）。
	 * @var string
	 */
	public $url;
	/**
	 * HTTP 协议的版本，默认为系统自动选择。
	 * @var string
	 */
	public $version;
	/**
	 * 是否暴露当前的 \HttpClient，即附加 X-Requested-With 头定义。
	 * @var bool
	 */
	public $expose;
	
	/**
	 * 连接选项：强制获取新连接 \Http\Client\Request::CONNECT_REFRESH，连接完成立即关闭不放入连接池 \Http\Client\Request::CONNECT_FORBID_REUSE。
	 * @var int
	 */
	public $connect;
	
	/**
	 * 是否启用新的会话。
	 * @var bool
	 */
	public $session;
	/**
	 * 是否尝试获取文件时间。
	 * @var bool
	 */
	public $filetime;
	
	/**
	 * 构造 HTTP 请求。
	 * @param string $url 链接。
	 */
	public function __construct($url){}
	
	/**
	 * 获取其它选项。
	 * @param IHttpClient $client 调用的 HTTP 客户端。
	 * @return ITraceable
	 */
	public function options(\IHttpClient $client){}
	
	/**
	 * 获取请求的资源链接。
	 * @return \Uri
	 */
	public function uri(){}
	
	/**
	 * 获取请求链接。
	 * @return string
	 */
	public function __toString(){}
}