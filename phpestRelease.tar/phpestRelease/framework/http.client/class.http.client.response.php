<?php

namespace Http\Client;

/**
 * HTTP 响应。
 * @author Max
 * 
 */
class Response
{
	const HTML = 'html';
	const CSS = 'css';
	const JS = 'js';
	const JSON = 'json';
	const JPG = 'jpg';
	const PNG = 'png';
	const GIF = 'gif';
	
	/**
	 * 选项：仅正文。
	 * @var int
	 */
	const ONLY_BODY = 1;
	/**
	 * 选项：不获取正文。
	 * @var int
	 */
	const NOBODY = 2;
	/**
	 * 选项：获取头信息。
	 * @var int
	 */
	const HEADERS = 4;
	/**
	 * 选项：获取连接信息。
	 * @var int
	 */
	const INFO = 4;
	
	/**
	 * 当前连接。
	 * @var array
	 */
	public $url;
	/**
	 * 响应正文。
	 * @var string
	 */
	public $body;
	/**
	 * 响应状态码。
	 * @var int
	 */
	public $status;
	/**
	 * HTTP 协议版本。
	 * @var string
	 */
	public $version;
	/**
	 * 响应头信息。
	 * @var array
	 */
	public $headers;
	/**
	 * 错误信息。
	 * @var array
	 */
	public $error;
	/**
	 * COOKIE 信息。
	 * @var array
	 */
	public $cookie;
	/**
	 * 连接信息。
	 * @var array
	 */
	public $info;
	/**
	 * 内容类型。
	 * @var string
	 */
	public $content_type;
	/**
	 * 如果是文本内容，使用的字符集。
	 * @var string
	 */
	public $charset;
	
}
