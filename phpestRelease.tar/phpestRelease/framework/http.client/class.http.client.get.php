<?php

namespace Http\Client;

/**
 * HTTP GET 请求。
 * @author Max
 * 
 */
class GET extends Request
{
	/**
	 * 查询数据。
	 * @var string|array|object
	 */
	public $querystring;
	/**
	 * 片段名。
	 * @var string
	 */
	public $fragment;
	
	public function __construct($url, $querystring = null, $fragment = null){}
	
	public function __toString(){}
	
}