<?php

/**
 * HTTP 客户端模拟。
 * @author Max
 * 
 */
class HttpClient implements IHttpClient
{
	const VERSION = '0.1.0';
	const USER_ARENT = 'phpest/httpclient v0.1.0';
	
	/**
	 * 是否根据要求自动重定向。
	 * @var bool
	 */
	public $follow = true;
	/**
	 * 自动设定来源链接。
	 * @var bool
	 */
	public $autoReferer = true;
	/**
	 * 循环重定向的最大次数。
	 * @var int
	 */
	public $maxRedirectCount = 10;
	/**
	 * 使用的网络接口（当有多个网络接口时）：发送的网络接口（interface），可以是一个接口名、IP 地址或者是一个主机名。 。
	 * @var sting
	 */
	public $interface;
	/**
	 * 连接超时时间，单位：秒。
	 * @var int
	 */
	public $timeout;
	/**
	 * 连接超时时间，单位：毫秒。
	 * @var int
	 */
	public $timeoutMs;
	
	/**
	 * 请求头。示例：array('User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0', 'Accept-Encoding' => 'gzip, deflate')。也可以使用键值对。
	 * @var array
	 */
	public $headers;
	/**
	 * 用户代理。
	 * @var string
	 */
	public $useragent = self::USER_ARENT;
	/**
	 * COOKIE 内容。
	 * @var array
	 */
	public $cookie;
	/**
	 * 是否自动更新 COOKIE。
	 * @var bool
	 */
	public $cookieAutoUpdate = true;
	/**
	 * 使用全局 DNS 缓存。
	 * @var bool
	 */
	public $useGlobalDnsCache;
	/**
	 * DNS 缓存超时时间，单位：秒。
	 * @var int
	 */
	public $dnsCacheTimeout;
	
	/**
	 * 设置 X-Requested-With 头。
	 * @var bool
	 */
	public $xRequestedWith;
	public $proxy;
	
	public $SSL = [
		CURLOPT_SSL_VERIFYPEER	=> false,
		CURLOPT_SSL_VERIFYHOST	=> false,
		CURLOPT_SSLVERSION		=> CURL_SSLVERSION_TLSv1,
	];
	
	/**
	 * 历史请求。
	 * @var array
	 */
	protected $recent;
	
	/**
	 * 基本设置，所有请求方法共同使用。
	 * @param resource $conn cURL 连接资源。
	 * @param Http\Client\Request $request 请求。
	 * @return HttpClient $this
	 */
	protected function setup(&$conn, Http\Client\Request $request){}
	
	public function reload(){}
	
	public function send(\Http\Client\Request $request, int $options = 0){}
	
	public function GET(string $url, array $headers = null){}
	public function POST(string $url, $data, array $headers = null){}
	public function PUT(string $url, string $data, string $content_type, array $headers = null){}
	public function PATCH(string $url, string $data, string $content_type, array $headers = null){}
	public function DELETE(string $url, array $headers = null){}
	public function HEAD(string $url, array $headers = null){}
	public function OPTIONS(string $url, array $headers = null){}
}