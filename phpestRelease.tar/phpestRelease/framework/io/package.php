<?php

/**
 * 移除文件或目录。
 * @param string $path 路径。
 * @param bool $recursive 可选，是否递归删除子目录及文件。默认为 true。
 * @param bool $ignoreError 可选，是否忽略错误的文件继续下一个。默认 false。
 * @return bool 是否成功完成。如果失败，有可能已经成功删除部分文件。
 */
function rm(string $path, bool $recursive = true, bool $ignoreError = false){}