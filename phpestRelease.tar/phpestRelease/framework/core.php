<?php

if (defined('FRAMEWORK'))
{
	return;
}

/**
 * 框架目录。注意，不以目录分隔符结束。
 * @var string
 */
define('FRAMEWORK', __DIR__);

/**
 * 基库目录。注意，不以目录分隔符结束。
 * @var string
 */
defined('BASE') or define('BASE', dirname(FRAMEWORK));

/**
 * 全局运行时目录。注意，不以目录分隔符结束。
 * @var string
 */
define('RUNTIME', BASE . DIRECTORY_SEPARATOR . 'runtime');

/**
 * 框架版本。
 * @var string
 */
define('FRAMEWORK_VERSION', '0.6.5');
/**
 * 框架发行版本。
 * @var string
 */
define('FRAMEWORK_RELEASE', 'phpest');
/**
 * 框架依赖的 PHP 引擎最小版本。
 * @var string
 */
define('ENGINE_VERSION', '7.0.0');



