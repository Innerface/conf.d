<?php

/**
 * 测试字符串是否含有指定前缀。
 * @param string $str 源字符串。
 * @param string $prefix 前缀。
 * @param bool $ignoreCase 可选，是否忽略大小写。默认忽略。
 * @return bool 注意：如果源字符串为空字符串则结果始终为 false，如果前缀为空字符串则结果始终为 true。
 */
function startswith($str, $prefix, $ignoreCase = true){}

/**
 * 测试字符串是否含有指定后缀。
 * @param string $str 源字符串。
 * @param string $suffix 后缀。
 * @param bool $ignoreCase 可选，是否忽略大小写。默认忽略。
 * @return bool
 */
function endswith($str, $suffix, $ignoreCase = true){}

/**
 * 确保变量为字符串。
 * @param mixed $var 变量。
 * @param string $fallback 可选，备选值，当变量不能转换为字符串时使用。
 * @return string
 */
function stringify($var, $fallback = ''){}

/**
 * 检测字符串是否有效的 UTF-8 字符集编码。
 * @param string $str 字符串。
 * @return bool
 */
function is_utf8(string $str) : bool{}

/**
 * 根据UTF8代码返回字符。
 * @param int $cp UTF 8 代码。
 * @param int $_ 可变参数，其它UTF 8 代码。
 * @return string 返回字符。
 */
function utf8_char($cp){}

/**
 * 根据UTF8代码返回字符。
 * @param int $cp UTF 8 代码。
 * @return string 返回字符。
 */
function chr_utf8($cp){}

/**
 * 按长度或分隔符取字符串前缀。
 * @param string $string 源字符串。
 * @param int|string $indicator 前缀长度（正整数）或分隔符。
 * @param string $fallback 可选，备用后缀。默认为 null。
 * @return string 参数不合法或无效，或无法获取后缀返回 $fallback。
 * @example prefix('pre_name', 3); // 返回 pre
 * @example prefix('pre_name', '_'); // 返回 pre
 */
function prefix($string, $indicator, $fallback = null){}

/**
 * 按长度或分隔符取字符串后缀。
 * @param string $string 源字符串。
 * @param int|string $indicator 后缀长度（正整数）或分隔符。
 * @param string $fallback 可选，备用后缀。默认为 null。
 * @return string 参数不合法或无效，或无法获取后缀返回 $fallback。
 * @example suffix('pre_name', 4); // 返回 name
 * @example suffix('pre_name', '_'); // 返回 name
 */
function suffix($string, $indicator, $fallback = null){}

/**
 * 连接字符串。与 implode 不同，此函数仅连接非空字符串（字符串长度大于0），子数组将连接后使用，支持多维数组。
 * @param string $separator 分隔符。
 * @param string $_ 可变参数，字符串片段。支持多维数组，将忽略不可转换为字符串的元素或字符串长度为 0 的元素。
 * 注意：仅检查字符串的长度，空白字符（空格，换行，回车，制表符等）组成的字符串视为有效。
 * @return string
 * @example echo concat(', ',  0, ['x', 'y', 'z'], 2, null, 3, 4); // 输出：0, 'x', 'y', 'z', 2, 3, 4
 */
function concat($separator, ... $_) : string{}

/**
 * 条件追加。
 * @param string $str 引用，源字符串。
 * @param string $_ 成对的字符串组，要连接进源字符串的字符串，仅当双数位置的字符串非空时合并其前一个位置的字符串后
 * 再追加到源字符串。如果是非字符串则尝试转换为字符串，不能转换则视为空字符串，如果是数组则尝试连接（使用 concat）为字符串。
 * 注意：仅检查字符串的长度，空白字符（空格，换行，回车，制表符等）组成的字符串视为有效。
 * @example follow($sql, ' WHERE ', '`age`>18', ' AND ', '`gender`=0')
 */
function follow(string & $str, ... $_){}

/**
 * 条件连接。
 * @param string $_ 可变参数，成对的字符串组，仅当双数位置的字符串非空时合并其前一个位置的字符串
 * 如果是非字符串则尝试转换为字符串，不能转换则视为空字符串，如果是数组则尝试连接（使用 concat）为字符串。
 * 注意：仅检查字符串的长度，空白字符（空格，换行，回车，制表符等）组成的字符串视为有效。
 * @example concat_with(' WHERE ', '`age`>18', ' AND ', '`gender`=0')
 * @return string
 */
function concat_with(... $_){}
