
CHANGELOG
=========

Change action:

 - Bug fixed: 
 - Feature: new feature added.
 - Added: same as feature.
 - Removed
 - Deprecated

### 0.2.0 (2009-01-01)



### 0.1.0 (2008-03-11)

 - First tagged release
